@echo off
REM ============================================================
REM  YTAgent - First-time setup (Windows)
REM ============================================================
echo.
echo === YTAgent setup ===
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found on PATH. Install Python 3.11+ from https://www.python.org/downloads/
    pause
    exit /b 1
)

where ffmpeg >nul 2>nul
if errorlevel 1 (
    echo [WARNING] ffmpeg was not found on PATH.
    echo           Download from https://www.gyan.dev/ffmpeg/builds/ and add its /bin folder to PATH,
    echo           or set FFMPEG_PATH in backend\.env to the full path of ffmpeg.exe
)

echo.
echo Creating Python virtual environment in backend\.venv ...
cd backend
python -m venv .venv
call .venv\Scripts\activate.bat

echo.
echo Installing Python dependencies (this can take several minutes)...
python -m pip install --upgrade pip
pip install -r requirements.txt

echo.
if not exist .env (
    copy .env.example .env
    echo Created backend\.env from .env.example -- edit it now to add your API keys.
) else (
    echo backend\.env already exists, leaving it untouched.
)

cd ..

echo.
echo Installing frontend dependencies...
cd frontend
call npm install
cd ..

echo.
echo === Setup complete ===
echo Next steps:
echo   1. Edit backend\.env and set PEXELS_API_KEY (and YouTube credentials if you want upload).
echo   2. Make sure "ollama serve" is running and qwen3:8b is pulled.
echo   3. Run start.bat to launch the backend, worker, and dashboard.
pause
