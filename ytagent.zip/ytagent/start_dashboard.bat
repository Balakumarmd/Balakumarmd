@echo off
cd %~dp0frontend
call npm run dev
