@echo off
cd %~dp0backend
call .venv\Scripts\activate.bat
python run_worker.py
