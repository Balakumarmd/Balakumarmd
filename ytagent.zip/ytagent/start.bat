@echo off
REM ============================================================
REM  YTAgent - Start everything (backend + worker + dashboard)
REM ============================================================
echo Starting backend API on http://127.0.0.1:8000 ...
start "YTAgent Backend" cmd /k "%~dp0start_backend.bat"

timeout /t 3 /nobreak >nul

echo Starting worker ...
start "YTAgent Worker" cmd /k "%~dp0start_worker.bat"

timeout /t 2 /nobreak >nul

echo Starting dashboard on http://127.0.0.1:5173 ...
start "YTAgent Dashboard" cmd /k "%~dp0start_dashboard.bat"

timeout /t 3 /nobreak >nul
start http://127.0.0.1:5173

echo.
echo All three services are starting in separate windows.
echo Close those windows (or Ctrl+C inside them) to stop YTAgent.
