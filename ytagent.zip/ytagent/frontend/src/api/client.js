const BASE = "/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || JSON.stringify(body);
    } catch (_) {
      /* ignore */
    }
    throw new Error(detail);
  }
  const contentType = res.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return res.json();
  }
  return res;
}

export const api = {
  health: () => request("/health"),
  systemStatus: () => request("/system/status"),
  workers: () => request("/system/workers"),

  createJob: (payload) => request("/jobs", { method: "POST", body: JSON.stringify(payload) }),
  listJobs: (status) => request(`/jobs${status ? `?status=${status}` : ""}`),
  getJob: (id) => request(`/jobs/${id}`),
  cancelJob: (id) => request(`/jobs/${id}/cancel`, { method: "POST" }),
  retryJob: (id) => request(`/jobs/${id}/retry`, { method: "POST" }),

  listVideos: () => request("/videos"),
  getVideo: (id) => request(`/videos/${id}`),
  videoFileUrl: (id) => `${BASE}/videos/${id}/file`,
  videoThumbUrl: (id) => `${BASE}/videos/${id}/thumbnail`,

  listProjects: () => request("/projects"),
  createProject: (payload) => request("/projects", { method: "POST", body: JSON.stringify(payload) }),

  getSettings: () => request("/settings"),
  updateSettings: (values) => request("/settings", { method: "PUT", body: JSON.stringify({ values }) }),

  youtubeConnect: () => request("/youtube/connect", { method: "POST" }),
  youtubeStatus: () => request("/youtube/status"),
  youtubeUpload: (videoId) => request(`/youtube/upload/${videoId}`, { method: "POST" }),
};
