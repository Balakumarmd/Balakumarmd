import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";

export default function Settings() {
  const [values, setValues] = useState({});
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState(null);

  const [provider, setProvider] = useState("groq");
  const [credentials, setCredentials] = useState([]);
  const [credentialSecret, setCredentialSecret] = useState("");
  const [credentialName, setCredentialName] = useState("");
  const [credentialSaved, setCredentialSaved] = useState(false);

  useEffect(() => {
    api.getSettings().then(setValues).catch((e) => setError(e.message));
    loadCredentials("groq");
  }, []);

  function update(key, value) {
    setValues((v) => ({ ...v, [key]: value }));
    setSaved(false);
  }

  async function handleSave() {
    try {
      await api.updateSettings(values);
      setSaved(true);
    } catch (e) {
      setError(e.message);
    }
  }

  async function loadCredentials(providerName) {
  try {
    setError(null);

    const data = await api.listProviderCredentials(
      "llm",
      providerName
    );

    setCredentials(data.credentials || []);
  } catch (e) {
    setError(e.message);
  }
}

  async function addCredential() {
  if (!credentialSecret.trim()) {
    setError("API key is required.");
    return;
  }

  try {
    setError(null);
    setCredentialSaved(false);

    await api.addProviderCredential({
      category: "llm",
      provider_name: provider,
      credential_type: "api_key",
      display_name: credentialName.trim() || null,
      secret: credentialSecret.trim(),
    });

    setCredentialSecret("");
    setCredentialName("");
    setCredentialSaved(true);

    await loadCredentials(provider);
  } catch (e) {
    setError(e.message);
  }
}

  async function changeProvider(event) {
    const providerName = event.target.value;

    setProvider(providerName);
    setCredentialSaved(false);

    await loadCredentials(providerName);
  }

  return (
    <div>
      <div className="page-header">
        <h1>Settings</h1>
        <p>
          Application preferences and provider configuration.
        </p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="panel">
        <div className="panel-title">Defaults</div>

        <div className="field">
          <label>Default niche</label>
          <input
            type="text"
            value={values.default_niche || ""}
            onChange={(e) =>
              update("default_niche", e.target.value)
            }
            placeholder="Education"
          />
        </div>

        <div className="field">
          <label>Default voice</label>
          <input
            type="text"
            value={values.default_voice || ""}
            onChange={(e) =>
              update("default_voice", e.target.value)
            }
            placeholder="af_heart"
          />
        </div>

        <div className="checkbox-row">
          <input
            type="checkbox"
            id="cleanup"
            checked={values.auto_cleanup_temp === "true"}
            onChange={(e) =>
              update(
                "auto_cleanup_temp",
                e.target.checked ? "true" : "false"
              )
            }
          />

          <label htmlFor="cleanup" style={{ margin: 0 }}>
            Automatically clean up intermediate render files after
            completion
          </label>
        </div>

        <button
          className="btn btn-primary"
          onClick={handleSave}
        >
          Save settings
        </button>

        {saved && (
          <span
            style={{
              marginLeft: 12,
              color: "var(--success)",
              fontSize: 13,
            }}
          >
            Saved.
          </span>
        )}
      </div>

      <div className="panel">
        <div className="panel-title">
          LLM Provider Credentials
        </div>

        <p className="field-hint">
          API keys are encrypted before being stored in the database.
          The actual secret is never displayed after saving.
        </p>

        <div className="field">
          <label>Provider</label>

          <select
            value={provider}
            onChange={changeProvider}
          >
            <option value="groq">Groq</option>
            <option value="gemini">Gemini</option>
            <option value="ollama">Ollama</option>
          </select>
        </div>

        <div className="field">
          <label>Key name</label>

          <input
            type="text"
            value={credentialName}
            onChange={(e) =>
              setCredentialName(e.target.value)
            }
            placeholder="Groq Key 1"
          />
        </div>

        <div className="field">
          <label>API key</label>

          <input
            type="password"
            value={credentialSecret}
            onChange={(e) =>
              setCredentialSecret(e.target.value)
            }
            placeholder={`Enter ${provider} API key`}
          />
        </div>

        <button
          className="btn btn-primary"
          onClick={addCredential}
        >
          Add API key
        </button>

        {credentialSaved && (
          <span
            style={{
              marginLeft: 12,
              color: "var(--success)",
              fontSize: 13,
            }}
          >
            API key saved.
          </span>
        )}

        <div style={{ marginTop: 20 }}>
          <div className="panel-title">
            Stored {provider} keys
          </div>

          {credentials.length === 0 ? (
            <p className="field-hint">
              No API keys stored for this provider.
            </p>
          ) : (
            credentials.map((credential) => (
              <div
                key={credential.id}
                className="checkbox-row"
                style={{ marginBottom: 8 }}
              >
                <span>
                  {credential.display_name ||
                    `${provider} API key`}
                </span>

                <span
                  style={{
                    marginLeft: "auto",
                    fontSize: 12,
                    opacity: 0.7,
                  }}
                >
                  {credential.is_exhausted
                    ? "Exhausted"
                    : credential.is_active
                      ? "Active"
                      : "Inactive"}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}