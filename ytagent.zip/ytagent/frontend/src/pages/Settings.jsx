import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";

export default function Settings() {
  const [values, setValues] = useState({});
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.getSettings().then(setValues).catch((e) => setError(e.message));
  }, []);

  function update(key, value) {
    setValues((v) => ({ ...v, [key]: value }));
    setSaved(false);
  }

  async function handleSave() {
    try {
      await api.updateSettings(values);
      setSaved(true);
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Settings</h1>
        <p>Application-level preferences. Secrets like API keys live in your .env file, not here.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="panel">
        <div className="panel-title">Defaults</div>
        <div className="field">
          <label>Default niche</label>
          <input type="text" value={values.default_niche || ""} onChange={(e) => update("default_niche", e.target.value)} placeholder="Education" />
        </div>
        <div className="field">
          <label>Default voice</label>
          <input type="text" value={values.default_voice || ""} onChange={(e) => update("default_voice", e.target.value)} placeholder="af_heart" />
        </div>
        <div className="checkbox-row">
          <input
            type="checkbox"
            id="cleanup"
            checked={values.auto_cleanup_temp === "true"}
            onChange={(e) => update("auto_cleanup_temp", e.target.checked ? "true" : "false")}
          />
          <label htmlFor="cleanup" style={{ margin: 0 }}>Automatically clean up intermediate render files after completion</label>
        </div>
        <button className="btn btn-primary" onClick={handleSave}>Save settings</button>
        {saved && <span style={{ marginLeft: 12, color: "var(--success)", fontSize: 13 }}>Saved.</span>}
      </div>

      <div className="panel">
        <div className="panel-title">Secrets & provider config (.env)</div>
        <p className="field-hint">
          OLLAMA_MODEL, PEXELS_API_KEY, YOUTUBE_CLIENT_ID/SECRET, DATA_DIR, FFMPEG_PATH, and all other
          provider keys are configured in your backend's <code>.env</code> file and are never exposed
          through this dashboard. Edit .env and restart the backend/worker to apply changes.
        </p>
      </div>
    </div>
  );
}
