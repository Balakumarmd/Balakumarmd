import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";

function StatusValue({ value }) {
  const ok = ["ok", "configured", "connected"].includes(value);
  const bad = ["unavailable", "error", "not_configured", "not_connected"].includes(value);
  const cls = ok ? "ok" : bad ? "bad" : "warn";
  return <span className={`stat-value ${cls}`} style={{ fontSize: 15 }}>{value}</span>;
}

export default function SystemStatus() {
  const [status, setStatus] = useState(null);
  const [workers, setWorkers] = useState([]);
  const [error, setError] = useState(null);

  async function load() {
    try {
      const [s, w] = await Promise.all([api.systemStatus(), api.workers()]);
      setStatus(s);
      setWorkers(w);
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, []);

  const rows = status
    ? [
        ["FastAPI backend", status.api],
        ["SQLite database", status.database],
        [`Ollama (${status.ollama_model})`, status.ollama],
        ["FFmpeg", status.ffmpeg],
        ["Kokoro TTS", status.tts],
        ["faster-whisper", status.whisper],
        ["Pexels", status.pexels],
        ["YouTube", status.youtube],
      ]
    : [];

  return (
    <div>
      <div className="page-header">
        <h1>System status</h1>
        <p>Live health of every local dependency the pipeline needs.</p>
      </div>

      {error && <div className="error-box">Could not reach the backend: {error}</div>}

      <div className="panel">
        <div className="panel-title">Dependencies</div>
        {rows.map(([label, value]) => (
          <div key={label} className="job-row" style={{ gridTemplateColumns: "1fr 160px" }}>
            <div className="job-topic">{label}</div>
            <StatusValue value={value} />
          </div>
        ))}
      </div>

      <div className="grid-3">
        <div className="stat-card">
          <div className="stat-label">CPU</div>
          <div className="stat-value" style={{ fontSize: 14 }}>{status?.cpu || "…"}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">MEMORY</div>
          <div className="stat-value" style={{ fontSize: 14 }}>{status?.memory || "…"}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">GPU</div>
          <div className="stat-value" style={{ fontSize: 14 }}>{status?.gpu || "…"}</div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">Workers</div>
        {workers.length === 0 ? (
          <div className="empty-state">
            <div className="headline">No worker has registered yet</div>
            <p>Run start_worker.bat (or python run_worker.py) to bring a worker online.</p>
          </div>
        ) : (
          workers.map((w) => (
            <div key={w.id} className="job-row" style={{ gridTemplateColumns: "1fr 100px 1fr" }}>
              <div>
                <div className="job-topic">{w.hostname}</div>
                <div className="job-meta">{w.id.slice(0, 8)}</div>
              </div>
              <span className={`tag ${w.status === "online" ? "tag-completed" : w.status === "busy" ? "tag-running" : "tag-cancelled"}`}>
                {w.status}
              </span>
              <div className="job-meta">{w.cpu_info} · {w.gpu_info}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
