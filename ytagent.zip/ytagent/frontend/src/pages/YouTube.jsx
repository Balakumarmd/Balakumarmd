import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";

export default function YouTube() {
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState(null);
  const [connecting, setConnecting] = useState(false);

  async function load() {
    try {
      const s = await api.youtubeStatus();
      setConnected(s.connected);
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleConnect() {
    setConnecting(true);
    setError(null);
    try {
      const { authorization_url } = await api.youtubeConnect();
      window.open(authorization_url, "_blank");
    } catch (e) {
      setError(e.message);
    } finally {
      setConnecting(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>YouTube</h1>
        <p>Connect your channel with OAuth — YTAgent never asks for your password, and never publishes without your say-so.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="panel">
        <div className="panel-title">Connection status</div>
        <div className="stat-value" style={{ color: connected ? "var(--success)" : "var(--text-dim)", marginBottom: 14 }}>
          {connected ? "Connected" : "Not connected"}
        </div>
        {!connected && (
          <>
            <p className="field-hint" style={{ marginBottom: 12 }}>
              This opens Google's sign-in page in a new tab. After approving access, come back here —
              your channel will show as connected. You'll need YOUTUBE_CLIENT_ID / YOUTUBE_CLIENT_SECRET
              configured in .env first (see README "YouTube OAuth setup").
            </p>
            <button className="btn btn-primary" onClick={handleConnect} disabled={connecting}>
              {connecting ? "Opening…" : "Connect YouTube account"}
            </button>
          </>
        )}
        {connected && (
          <button className="btn" onClick={load}>Refresh status</button>
        )}
      </div>
    </div>
  );
}
