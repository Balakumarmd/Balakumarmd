import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";

export default function VideoLibrary() {
  const [videos, setVideos] = useState([]);
  const [error, setError] = useState(null);
  const [uploading, setUploading] = useState(null);

  async function load() {
    try {
      setVideos(await api.listVideos());
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleUpload(videoId) {
    setUploading(videoId);
    try {
      await api.youtubeUpload(videoId);
      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setUploading(null);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Video library</h1>
        <p>Every finished video, ready to preview, download, or publish to YouTube.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      {videos.length === 0 ? (
        <div className="empty-state">
          <div className="headline">No finished videos yet</div>
          <p>Completed videos from the Create Video page will appear here.</p>
        </div>
      ) : (
        <div className="video-grid">
          {videos.map((v) => (
            <div className="video-card" key={v.id}>
              <img className="video-thumb" src={api.videoThumbUrl(v.id)} alt={v.title || "thumbnail"} onError={(e) => (e.target.style.display = "none")} />
              <div className="video-card-body">
                <div className="video-card-title">{v.title || "Untitled"}</div>
                <div className="job-meta" style={{ marginBottom: 10 }}>
                  {v.content_type?.toUpperCase()} · {v.duration_seconds ? `${Math.round(v.duration_seconds)}s` : "—"}
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <a className="btn btn-sm" href={api.videoFileUrl(v.id)} target="_blank" rel="noreferrer">Preview</a>
                  <a className="btn btn-sm" href={api.videoFileUrl(v.id)} download>Download</a>
                </div>
                {v.youtube_url ? (
                  <a className="btn btn-sm" style={{ marginTop: 8, width: "100%" }} href={v.youtube_url} target="_blank" rel="noreferrer">
                    View on YouTube
                  </a>
                ) : (
                  <button className="btn btn-sm" style={{ marginTop: 8, width: "100%" }} disabled={uploading === v.id} onClick={() => handleUpload(v.id)}>
                    {uploading === v.id ? "Uploading…" : "Upload to YouTube (private)"}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
