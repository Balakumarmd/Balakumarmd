# YTAgent — Local AI YouTube Automation Agent (V1)

A fully local, Windows-first application that turns a topic into a finished,
narrated, captioned YouTube video (Short or long-form) using a local LLM
(Ollama), local TTS (Kokoro), local transcription (faster-whisper), stock
footage (Pexels), and FFmpeg — then optionally uploads it to YouTube via
OAuth. No cloud backend, no Docker, no Kubernetes required for V1.

---

## 1. What this application does

1. You open a dashboard, enter a topic, and pick Short or Long-form.
2. A local worker process:
   - generates a structured script with Ollama (qwen3:8b by default),
   - synthesizes narration with Kokoro TTS,
   - gets word-level timestamps with faster-whisper,
   - finds and downloads matching stock footage from Pexels,
   - renders the final MP4 with FFmpeg (scaled/cropped visuals, dynamic
     word-level captions, optional background music),
   - generates a thumbnail and a YouTube title/description/tags,
   - optionally uploads the result to YouTube as **private** by default.
3. You watch real progress on the dashboard and find the finished video in
   your local Video Library.

Every step above is a real, working local process — nothing here is a
mock or a placeholder.

---

## 2. Architecture

```
Browser (React dashboard, Vite dev server, port 5173)
    |
    v
FastAPI control plane (port 8000) ---- SQLite (WAL mode) ---- Standalone worker process
                                                                    |
                                                                    +--> Ollama (qwen3:8b)      [LLM]
                                                                    +--> Kokoro                  [TTS]
                                                                    +--> faster-whisper          [word timestamps]
                                                                    +--> Pexels API              [stock footage]
                                                                    +--> FFmpeg                  [render]
                                                                    +--> Pillow                  [thumbnail]
                                                                    +--> YouTube Data API v3      [upload]
```

The API process only ever *creates* jobs in SQLite; it never runs a
video-generation task inside an HTTP request. The worker is a separate
process that polls SQLite, atomically claims one job at a time (race-safe,
tested under concurrent load — see `backend/tests/test_atomic_claim.py`),
and runs it end-to-end, updating progress as it goes.

Every external capability (LLM, TTS, transcription, stock media, YouTube)
sits behind an abstract provider interface in `backend/app/providers/base.py`.
Concrete providers are chosen in one place — `backend/app/providers/factory.py`
— so swapping Ollama → OpenAI, Kokoro → ElevenLabs, or Pexels → Pixabay later
means writing one new provider class and changing one line in the factory,
not touching the pipeline.

---

## 3. Requirements

- **Windows 10/11**
- **Python 3.11+**
- **Node.js 18+** (for the dashboard)
- **FFmpeg** (with `ffmpeg`/`ffprobe` on PATH, or set `FFMPEG_PATH`/`FFPROBE_PATH`)
- **Ollama**, already running with `qwen3:8b` pulled (you said this is already
  set up, with models stored at `D:\OllamaModels` — nothing further needed
  here; the app just talks to `http://localhost:11434`)
- **espeak-ng** (a dependency of Kokoro TTS's phoneme fallback)
- A free stock-footage API key — **either** Pexels (https://www.pexels.com/api/)
  **or** Pixabay (https://pixabay.com/api/docs/). Pixabay is the default in
  `.env.example` because, as of writing, Pexels has temporarily paused
  issuing new API keys; Pixabay's has no such approval step. Both are fully
  implemented and interchangeable via `MEDIA_PROVIDER` — see section 4.8.
- *(optional)* A **Google Cloud OAuth client** if you want YouTube upload
- *(optional)* An NVIDIA GPU — detected automatically and used by
  faster-whisper (and Kokoro, if `torch` with CUDA is installed); everything
  also works on CPU only.

---

## 4. Windows installation (step by step)

### 4.1 Python
Install Python 3.11+ from https://www.python.org/downloads/ and make sure
"Add python.exe to PATH" is checked during install.

### 4.2 FFmpeg
Download a build from https://www.gyan.dev/ffmpeg/builds/ ("release full"),
extract it, and add the `bin` folder (containing `ffmpeg.exe`/`ffprobe.exe`)
to your PATH. Verify with:
```
ffmpeg -version
```

### 4.3 Ollama + Qwen3
You already have this working (Ollama 0.34.4, `qwen3:8b` pulled, models at
`D:\OllamaModels`). Just make sure `ollama serve` is running (Ollama usually
runs as a background service after install — check with `ollama list`).

### 4.4 espeak-ng (required by Kokoro TTS)
Download and install from
https://github.com/espeak-ng/espeak-ng/releases (the Windows `.msi`).

### 4.5 Clone/copy this project
Place the `ytagent` folder wherever you like, e.g. `C:\Apps\ytagent`.

### 4.6 Run the setup script
Double-click `setup.bat` in the project root. It will:
- create a Python virtual environment in `backend\.venv`,
- install all Python dependencies from `backend\requirements.txt`,
- copy `backend\.env.example` to `backend\.env` (if it doesn't exist yet),
- install the frontend's npm dependencies.

### 4.7 GPU acceleration (optional, you have an RTX 3050 Laptop GPU)
`torch` is intentionally **not** pinned in `requirements.txt` because the
correct wheel depends on your CUDA setup. After `setup.bat` finishes,
activate the venv and install the CUDA build:
```
backend\.venv\Scripts\activate
pip install torch --index-url https://download.pytorch.org/whl/cu121
```
With this installed, `faster-whisper` (and Kokoro, if it also uses torch)
will automatically use your GPU (`WHISPER_DEVICE=auto` in `.env`). If you
skip this, everything still works on CPU — just somewhat slower.

### 4.8 Configure `.env`
Open `backend\.env` and set at minimum one stock-media provider:
```
MEDIA_PROVIDER=pixabay
PIXABAY_API_KEY=your_key_here
```
To get a Pixabay key: log in at https://pixabay.com, then open
https://pixabay.com/api/docs/ — your personal key is shown inline at the
top of that page (no application/approval step, unlike Pexels right now).

If Pexels key creation reopens and you'd rather use it instead, switch to:
```
MEDIA_PROVIDER=pexels
PEXELS_API_KEY=your_key_here
```
No code changes needed either way — `MEDIA_PROVIDER` is read by
`app/providers/factory.py`, the one place the concrete provider is chosen.
`DATA_DIR` is already set to `D:\YTAgentData` as you requested — that's
where jobs, rendered videos, logs, the music library, and the SQLite
database will live.

---

## 5. Running the application

Double-click **`start.bat`** in the project root. It opens three windows:
1. **Backend** — FastAPI on http://127.0.0.1:8000 (Swagger docs at `/docs`)
2. **Worker** — polls for jobs and processes them
3. **Dashboard** — Vite dev server on http://127.0.0.1:5173, opened
   automatically in your browser

You can also start each piece individually with `start_backend.bat`,
`start_worker.bat`, and `start_dashboard.bat` — useful when you want to
watch one component's logs in isolation.

To stop everything, close the three windows (or Ctrl+C inside each).

---

## 6. Creating your first video

1. Open http://127.0.0.1:5173 (opens automatically via `start.bat`).
2. Go to **Create video**.
3. Enter a topic, e.g. `5 AI tools students should know`.
4. Leave format as **YouTube Short**.
5. Click **Generate video**.
6. Watch the progress bar — it reflects real backend job state (Research →
   Script → Scene planning → Audio → Transcription → Media → Render →
   Thumbnail → Metadata → Ready).
7. When it reaches **Ready/Completed**, go to **Video library** to preview
   and download the MP4.

Output for a given job lives at:
```
D:\YTAgentData\jobs\<job_id>\
    script.json
    narration.txt
    audio.wav
    transcript.json
    media\
    captions\captions.ass
    thumbnail.png
    metadata.json
    final.mp4
    logs\job.log
```

## 7. Uploading your first video to YouTube

1. Go to **Settings → YouTube OAuth setup** below to create credentials.
2. Put `YOUTUBE_CLIENT_ID` / `YOUTUBE_CLIENT_SECRET` in `backend\.env` and
   restart the backend.
3. Go to the **YouTube** page in the dashboard and click
   **Connect YouTube account**. Approve access in the tab that opens.
4. Go to **Video library** and click **Upload to YouTube (private)** on any
   finished video. The video, title, description, and tags all come from
   the pipeline's generated metadata. It uploads as **private** by
   default — nothing you generate here is ever made public automatically.
5. After upload, the video's YouTube ID and URL are stored in SQLite and
   shown on the video card.

### YouTube OAuth setup (Google Cloud Console)
1. Go to https://console.cloud.google.com/ and create a new project.
2. Enable **"YouTube Data API v3"** (APIs & Services → Library).
3. Go to APIs & Services → OAuth consent screen. Choose "External", fill in
   the required fields, and add your own Google account as a **test user**
   (you can leave the app in "Testing" mode — no Google review needed for
   personal use).
4. Go to APIs & Services → Credentials → Create Credentials → OAuth client
   ID → Application type: **Web application**.
5. Add an **Authorized redirect URI** of
   `http://localhost:8000/api/youtube/oauth2callback` (or whatever you set
   `YOUTUBE_OAUTH_REDIRECT_URI` to in `.env`).
6. Copy the generated **Client ID** and **Client secret** into
   `backend\.env` as `YOUTUBE_CLIENT_ID` / `YOUTUBE_CLIENT_SECRET`.

---

## 8. Environment variables (`backend\.env`)

See `backend\.env.example` for the full, commented list. Highlights:

| Variable | Purpose |
|---|---|
| `DATA_DIR` | Where all jobs, videos, logs, music, and the DB live |
| `OLLAMA_BASE_URL`, `OLLAMA_MODEL` | Local LLM connection + model name |
| `TTS_PROVIDER`, `KOKORO_VOICE`, `KOKORO_SPEED` | Local TTS settings |
| `WHISPER_MODEL`, `WHISPER_DEVICE`, `WHISPER_COMPUTE_TYPE` | Transcription settings (`WHISPER_DEVICE=auto` uses your GPU if present) |
| `MEDIA_PROVIDER`, `PEXELS_API_KEY` | Stock footage provider |
| `SERPER_API_KEY` | Optional web-research provider (leave blank to skip) |
| `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, `YOUTUBE_OAUTH_REDIRECT_URI` | YouTube OAuth |
| `FFMPEG_PATH`, `FFPROBE_PATH` | Only needed if not on PATH |
| `API_HOST`, `API_PORT` | Backend bind address |
| `WORKER_POLL_INTERVAL_SECONDS`, `WORKER_MAX_RETRIES` | Worker tuning |

Never commit your real `.env` file — it's already excluded via `.gitignore`.

---

## 9. Storage management

Everything lives under `DATA_DIR` (`D:\YTAgentData` by default):
```
D:\YTAgentData\
    ytagent.db          <- SQLite database (jobs, projects, videos, workers, settings)
    jobs\<job_id>\...   <- one folder per job, see section 6 above
    music\              <- drop your own royalty-free tracks here
    logs\               <- app.log / worker.log (rotating, 5MB x 3 backups)
```
Before each render, the worker checks that at least 2 GB of free disk space
is available and fails the job cleanly with `INSUFFICIENT_STORAGE` if not.
Intermediate per-scene clips are deleted automatically after a successful
render; `final.mp4` and all pipeline JSON artifacts are kept for your review.

To reclaim space, you can safely delete any `jobs\<job_id>` folder whose
job is `COMPLETED`/`FAILED` and whose video you no longer need — this does
not affect the database's video *record*, only the files, so keep that in
mind if you want to re-download something later.

---

## 10. Logs

- `DATA_DIR\logs\app.log` — FastAPI backend
- `DATA_DIR\logs\worker.log` — worker process
- `DATA_DIR\jobs\<job_id>\logs\job.log` — everything that happened to one
  specific job, in one place, for easy debugging

---

## 11. Development mode

- Backend: `backend\.venv\Scripts\activate && python run_backend.py` (add
  `--reload` behavior by running `uvicorn app.main:app --reload` directly
  if you're actively editing backend code)
- Frontend: `cd frontend && npm run dev` (Vite hot-reloads on save)
- Tests: `cd backend && .venv\Scripts\activate && pytest -v`

The fast unit test suite (`pytest`) needs no external services at all — it
uses a temporary SQLite DB and never calls Ollama/Kokoro/Pexels/YouTube.
The one true end-to-end test (`tests/test_e2e_pipeline.py`) is skipped
unless you explicitly run it with `RUN_E2E_TEST=1`, since it genuinely
exercises your local Ollama, Kokoro, faster-whisper, FFmpeg, and Pexels key.

---

## 12. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| Dashboard shows "Could not reach the backend" | `start_backend.bat` isn't running, or crashed — check its console window / `app.log` |
| System status page shows Ollama "unavailable" | `ollama serve` isn't running, or `qwen3:8b` isn't pulled (`ollama pull qwen3:8b`) |
| Job fails with `TTS_FAILED` | Kokoro isn't installed correctly, or espeak-ng is missing — see section 4.4 |
| Job fails with `WHISPER_FAILED` | faster-whisper model failed to load — check `WHISPER_MODEL` name and available disk/RAM |
| Job fails with `MEDIA_PROVIDER_FAILED` | Whichever key matches `MEDIA_PROVIDER` (`PEXELS_API_KEY` or `PIXABAY_API_KEY`) is missing/invalid, or there's no internet connection |
| Job fails with `FFMPEG_FAILED` | FFmpeg isn't on PATH — set `FFMPEG_PATH`/`FFPROBE_PATH` in `.env` |
| Job fails with `INSUFFICIENT_STORAGE` | Free up space on the `DATA_DIR` drive (2 GB minimum headroom) |
| YouTube upload fails with `YOUTUBE_AUTH_FAILED` | Reconnect your account from the YouTube page |
| A job is stuck in `CLAIMED` after a crash | Restart the worker; you can also manually re-queue via `POST /api/jobs/{id}/retry` after cancelling, or edit the row in `ytagent.db` |

Every failure updates the job's `error_code`/`error_message` in the
dashboard and writes full detail (including the real traceback) to that
job's `logs/job.log` — you never have to guess what happened.

---

## 13. Known V1 limitations (by design, not oversights)

- English-only TTS voice (Kokoro's US/UK English voices); additional
  languages need a different TTS voice model swapped in via `KOKORO_LANG`.
- Long-form videos are tuned for 2–5 minutes; longer videos work but are
  not yet specifically optimized for pacing.
- Automated web research is optional and off by default; without a
  `SERPER_API_KEY`, the script generator relies solely on the topic itself
  and any notes you provide, and is explicitly instructed not to present
  invented facts as researched facts.
- Single active worker process is expected for V1 (SQLite + WAL supports
  more, and the atomic-claim logic is tested for it, but one worker is the
  validated, supported configuration).

## 14. What comes after this (explicitly out of scope for now)

Per your instructions, this V1 stops here. Cloud architecture — VPS
workers, a cloud control plane, remote dashboard access, PostgreSQL,
Redis, object storage, licensing, multi-user auth, and commercial
packaging — will be designed separately, based on this working local
application, only when you ask for it.
