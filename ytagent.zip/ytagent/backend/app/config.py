"""
Central application configuration.

All configuration is loaded from environment variables / a local .env file.
Nothing here is hardcoded as a secret. See .env.example for the full list
of variables the application understands.
"""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=Path(__file__).resolve().parents[1] / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ---- Core paths -----------------------------------------------------
    DATA_DIR: str = Field(default=str(Path.home() / "YTAgentData"))
    FFMPEG_PATH: str = Field(default="ffmpeg")
    FFPROBE_PATH: str = Field(default="ffprobe")

    # ---- Database ---------------------------------------------------------
    DATABASE_URL: Optional[str] = None  # if unset, derived from DATA_DIR

    # ---- Ollama / LLM ------------------------------------------------------
    # ---- Ollama / LLM ------------------------------------------------------
    LLM_PROVIDER: str = Field(default="ollama")

    OLLAMA_BASE_URL: str = Field(default="http://localhost:11434")
    OLLAMA_MODEL: str = Field(default="qwen3:8b")
    OLLAMA_TIMEOUT_SECONDS: int = Field(default=600)

    gemini_api_key: str | None = None
    gemini_api_keys: str | None = None
    gemini_model: str = "gemini-3.8-flash"

    groq_api_key: str | None = None
    groq_api_keys: str | None = None
    groq_model: str = "llama-3.3-70b-versatile"

    yt_agent_encryption_key: str | None = None

    # ---- TTS (Kokoro) -------------------------------------------------------
    TTS_PROVIDER: str = Field(default="kokoro")
    KOKORO_VOICE: str = Field(default="af_heart")
    KOKORO_LANG: str = Field(default="en-us")
    KOKORO_MODEL_PATH: Optional[str] = None
    KOKORO_VOICES_PATH: Optional[str] = None
    KOKORO_SPEED: float = Field(default=1.0)

    # ---- Whisper -------------------------------------------------------------
    WHISPER_MODEL: str = Field(default="base.en")
    WHISPER_DEVICE: str = Field(default="auto")  # auto|cpu|cuda
    WHISPER_COMPUTE_TYPE: str = Field(default="auto")

    # ---- Media provider (Pexels) ---------------------------------------------
    MEDIA_PROVIDER: str = Field(default="pexels")
    PEXELS_API_KEY: Optional[str] = None
    PIXABAY_API_KEY: Optional[str] = None

    # ---- Optional research provider -------------------------------------------
    SERPER_API_KEY: Optional[str] = None

    # ---- YouTube --------------------------------------------------------------
    YOUTUBE_CLIENT_ID: Optional[str] = None
    YOUTUBE_CLIENT_SECRET: Optional[str] = None
    YOUTUBE_OAUTH_REDIRECT_URI: str = Field(default="http://localhost:8000/api/youtube/oauth2callback")
    YOUTUBE_DEFAULT_PRIVACY: str = Field(default="private")

    # ---- API server -----------------------------------------------------------
    API_HOST: str = Field(default="127.0.0.1")
    API_PORT: int = Field(default=8000)

    # ---- Worker -----------------------------------------------------------------
    WORKER_POLL_INTERVAL_SECONDS: float = Field(default=2.0)
    WORKER_MAX_RETRIES: int = Field(default=2)
    WORKER_ID: Optional[str] = None

    # ---- Language / voice defaults --------------------------------------------
    DEFAULT_LANGUAGE: str = Field(default="en")

    LOG_LEVEL: str = Field(default="INFO")

    # ------------------------------------------------------------------------
    @property
    def data_dir_path(self) -> Path:
        p = Path(self.DATA_DIR)
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def jobs_dir(self) -> Path:
        p = self.data_dir_path / "jobs"
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def music_dir(self) -> Path:
        # Music library is a project-relative folder the user can drop files into.
        candidate = self.data_dir_path / "music"
        candidate.mkdir(parents=True, exist_ok=True)
        return candidate

    @property
    def database_url(self) -> str:
        if self.DATABASE_URL:
            return self.DATABASE_URL
        db_path = self.data_dir_path / "ytagent.db"
        return f"sqlite:///{db_path}"

    @property
    def logs_dir(self) -> Path:
        p = self.data_dir_path / "logs"
        p.mkdir(parents=True, exist_ok=True)
        return p


@lru_cache
def get_settings() -> Settings:
    return Settings()
