"""
FastAPI application entrypoint.

Run with:  python run_backend.py   (or run_backend.bat on Windows)
Docs available at:  http://127.0.0.1:8000/docs
"""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.database import init_db
from app.routes import health, jobs, projects, settings_routes, system, videos, youtube
from app.utils.logging_config import configure_logging
from app.utils.system_info import get_cpu_info, get_disk_info, get_gpu_info, get_memory_info
from app.utils.ffmpeg_utils import check_ffmpeg_available
from app.routes.providers import router as providers_router

app = FastAPI(
    title="AI YouTube Automation Agent",
    description="Local-first AI pipeline for generating and uploading YouTube videos.",
    version="1.0.0",
)

# The React dev server (Vite) runs on a different port during development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(system.router)
app.include_router(jobs.router)
app.include_router(projects.router)
app.include_router(videos.router)
app.include_router(settings_routes.router)
app.include_router(youtube.router)
app.include_router(providers_router)


@app.on_event("startup")
def on_startup() -> None:
    logger = configure_logging(component="app")
    settings = get_settings()
    init_db()

    logger.info("=" * 70)
    logger.info("AI YouTube Automation Agent - starting up")
    logger.info("Data directory: %s", settings.data_dir_path)
    logger.info("Database:       %s", settings.database_url)
    logger.info("Ollama model:   %s @ %s", settings.OLLAMA_MODEL, settings.OLLAMA_BASE_URL)
    logger.info("CPU: %s | RAM: %s | GPU: %s", get_cpu_info(), get_memory_info(), get_gpu_info())
    logger.info("Disk: %s", get_disk_info(str(settings.data_dir_path)))

    ffmpeg_ok = check_ffmpeg_available()
    logger.info("FFmpeg available: %s", ffmpeg_ok)
    if not ffmpeg_ok:
        logger.warning(
            "FFmpeg was not found at '%s'. Video rendering will fail until FFmpeg "
            "is installed and on PATH, or FFMPEG_PATH is set in .env.",
            settings.FFMPEG_PATH,
        )
    if not settings.PEXELS_API_KEY:
        logger.warning("PEXELS_API_KEY is not set in .env -- media acquisition will fail until configured.")
    if not settings.YOUTUBE_CLIENT_ID or not settings.YOUTUBE_CLIENT_SECRET:
        logger.warning("YouTube OAuth credentials are not set -- YouTube upload will be unavailable until configured.")
    logger.info("=" * 70)


@app.get("/")
def root():
    return {"app": "AI YouTube Automation Agent", "docs": "/docs", "status": "/api/system/status"}
