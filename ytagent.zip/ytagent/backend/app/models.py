"""
SQLAlchemy ORM models.

Schema overview
----------------
User        - local application user (V1 is single-user, but the table
              exists so multi-user support can be added without a schema
              migration later).
Project     - a named grouping of jobs/videos (e.g. a channel's content
              calendar).
Job         - one video-generation request and its lifecycle state.
Worker      - heartbeat/registration record for a worker process.
Video       - a finished (or in-progress) output video tied to a Job.
Channel     - a connected YouTube channel (OAuth tokens).
Setting     - simple key/value application settings.
ProviderConfig - which concrete provider implementation is active for each
              provider category (llm/tts/transcription/media/youtube), plus
              provider-specific JSON config blobs that are NOT secrets
              (secrets always come from environment variables).
"""
from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from app.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


class JobStatus(str, enum.Enum):
    QUEUED = "QUEUED"
    CLAIMED = "CLAIMED"
    RESEARCHING = "RESEARCHING"
    SCRIPTING = "SCRIPTING"
    SCENE_PLANNING = "SCENE_PLANNING"
    GENERATING_AUDIO = "GENERATING_AUDIO"
    TRANSCRIBING = "TRANSCRIBING"
    FETCHING_MEDIA = "FETCHING_MEDIA"
    RENDERING = "RENDERING"
    GENERATING_THUMBNAIL = "GENERATING_THUMBNAIL"
    GENERATING_METADATA = "GENERATING_METADATA"
    READY = "READY"
    UPLOADING = "UPLOADING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


# Terminal states a job can never leave.
TERMINAL_STATES = {JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED}


class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=_uuid)
    email = Column(String, unique=True, nullable=True)
    display_name = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    projects = relationship("Project", back_populates="owner")


class Project(Base):
    __tablename__ = "projects"

    id = Column(String, primary_key=True, default=_uuid)
    owner_id = Column(String, ForeignKey("users.id"), nullable=True)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    niche = Column(String, nullable=True)
    default_language = Column(String, default="en")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    owner = relationship("User", back_populates="projects")
    jobs = relationship("Job", back_populates="project")
    videos = relationship("Video", back_populates="project")


class Job(Base):
    __tablename__ = "jobs"

    id = Column(String, primary_key=True, default=_uuid)
    project_id = Column(String, ForeignKey("projects.id"), nullable=True)

    # ---- request parameters -------------------------------------------------
    topic = Column(String, nullable=False)
    content_type = Column(String, nullable=False)  # "short" | "long_form"
    niche = Column(String, nullable=True)
    language = Column(String, default="en")
    target_duration_seconds = Column(Integer, nullable=False)
    voice = Column(String, nullable=True)
    visual_style = Column(String, nullable=True)
    music_preference = Column(String, nullable=True)  # "none" | "auto" | filename
    research_enabled = Column(Boolean, default=False)
    auto_upload = Column(Boolean, default=False)
    upload_privacy = Column(String, default="private")

    # ---- lifecycle state -------------------------------------------------------
    status = Column(String, default=JobStatus.QUEUED.value, index=True)
    progress = Column(Integer, default=0)  # 0-100
    current_step = Column(String, nullable=True)
    error_code = Column(String, nullable=True)
    error_message = Column(Text, nullable=True)

    # ---- worker / retry bookkeeping ----------------------------------------------
    claimed_by_worker_id = Column(String, nullable=True)
    claimed_at = Column(DateTime, nullable=True)
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=2)

    # ---- output -------------------------------------------------------------------
    output_dir = Column(String, nullable=True)
    output_video_path = Column(String, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    project = relationship("Project", back_populates="jobs")
    video = relationship("Video", back_populates="job", uselist=False)


class Worker(Base):
    __tablename__ = "workers"

    id = Column(String, primary_key=True, default=_uuid)
    hostname = Column(String, nullable=True)
    status = Column(String, default="offline")  # online|offline|busy
    current_job_id = Column(String, nullable=True)
    last_heartbeat = Column(DateTime, nullable=True)
    cpu_info = Column(String, nullable=True)
    memory_info = Column(String, nullable=True)
    disk_info = Column(String, nullable=True)
    gpu_info = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Video(Base):
    __tablename__ = "videos"

    id = Column(String, primary_key=True, default=_uuid)
    job_id = Column(String, ForeignKey("jobs.id"), unique=True, nullable=False)
    project_id = Column(String, ForeignKey("projects.id"), nullable=True)
    channel_id = Column(String, ForeignKey("channels.id"), nullable=True)

    title = Column(String, nullable=True)
    description = Column(Text, nullable=True)
    tags = Column(JSON, nullable=True)
    category = Column(String, nullable=True)

    file_path = Column(String, nullable=True)
    thumbnail_path = Column(String, nullable=True)
    duration_seconds = Column(Float, nullable=True)
    content_type = Column(String, nullable=True)

    youtube_video_id = Column(String, nullable=True)
    youtube_url = Column(String, nullable=True)
    uploaded_at = Column(DateTime, nullable=True)
    upload_privacy = Column(String, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    job = relationship("Job", back_populates="video")
    project = relationship("Project", back_populates="videos")
    channel = relationship("Channel", back_populates="videos")


class Channel(Base):
    __tablename__ = "channels"

    id = Column(String, primary_key=True, default=_uuid)
    channel_title = Column(String, nullable=True)
    youtube_channel_id = Column(String, nullable=True)
    # OAuth token material. Stored locally only; never returned via the API.
    token_json = Column(Text, nullable=True)
    connected_at = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)

    videos = relationship("Video", back_populates="channel")


class Setting(Base):
    __tablename__ = "settings"

    key = Column(String, primary_key=True)
    value = Column(Text, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ProviderConfig(Base):
    __tablename__ = "provider_configs"

    id = Column(String, primary_key=True, default=_uuid)
    category = Column(String, nullable=False)  # llm|tts|transcription|media|youtube
    provider_name = Column(String, nullable=False)  # e.g. "ollama", "kokoro"
    is_active = Column(Boolean, default=True)
    config_json = Column(JSON, nullable=True)  # non-secret settings only
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
