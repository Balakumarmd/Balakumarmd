"""
Real YouTube provider using the YouTube Data API v3 with OAuth 2.0
(authorization-code flow, NOT the user's password).

Setup required from the user (documented in README.md):
  1. Create a Google Cloud project.
  2. Enable "YouTube Data API v3".
  3. Configure an OAuth consent screen (can stay in "Testing" mode).
  4. Create OAuth 2.0 credentials of type "Web application" with redirect
     URI http://localhost:8000/api/youtube/oauth2callback (or whatever
     YOUTUBE_OAUTH_REDIRECT_URI is set to).
  5. Put the client id/secret into .env as YOUTUBE_CLIENT_ID /
     YOUTUBE_CLIENT_SECRET.

Tokens are persisted in the `channels` table (token_json column) -- never
returned by any API response body.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import List, Optional

from app.config import Settings
from app.providers.base import YouTubeProvider
from app.utils.retry import PermanentError

logger = logging.getLogger("ytagent")

_SCOPES = ["https://www.googleapis.com/auth/youtube.upload", "https://www.googleapis.com/auth/youtube.readonly"]


class YouTubeDataAPIProvider(YouTubeProvider):
    def __init__(self, settings: Settings, stored_token_json: Optional[str] = None):
        if not settings.YOUTUBE_CLIENT_ID or not settings.YOUTUBE_CLIENT_SECRET:
            raise PermanentError(
                "YOUTUBE_CLIENT_ID / YOUTUBE_CLIENT_SECRET are not configured in .env. "
                "See README.md 'YouTube OAuth setup' for how to create them in Google Cloud Console."
            )
        self._settings = settings
        self._client_config = {
            "web": {
                "client_id": settings.YOUTUBE_CLIENT_ID,
                "client_secret": settings.YOUTUBE_CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": [settings.YOUTUBE_OAUTH_REDIRECT_URI],
            }
        }
        self._stored_token_json = stored_token_json
        self._flow = None

    def _get_flow(self):
        from google_auth_oauthlib.flow import Flow

        flow = Flow.from_client_config(
            self._client_config, scopes=_SCOPES, redirect_uri=self._settings.YOUTUBE_OAUTH_REDIRECT_URI
        )
        return flow

    def get_authorization_url(self) -> str:
        flow = self._get_flow()
        auth_url, _state = flow.authorization_url(
            access_type="offline", include_granted_scopes="true", prompt="consent"
        )
        return auth_url

    def exchange_code_for_token(self, code: str) -> dict:
        flow = self._get_flow()
        flow.fetch_token(code=code)
        creds = flow.credentials
        token_dict = json.loads(creds.to_json())
        return token_dict

    def is_connected(self) -> bool:
        return self._stored_token_json is not None

    def _get_credentials(self):
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request

        if not self._stored_token_json:
            raise PermanentError("YouTube account is not connected yet. Connect it from Settings first.")
        info = json.loads(self._stored_token_json)
        creds = Credentials.from_authorized_user_info(info, scopes=_SCOPES)
        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
        return creds

    def get_refreshed_token_json(self) -> str:
        creds = self._get_credentials()
        return creds.to_json()

    def upload_video(
        self,
        video_path: Path,
        title: str,
        description: str,
        tags: List[str],
        category_id: str,
        privacy_status: str,
        thumbnail_path: Optional[Path] = None,
    ) -> dict:
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload
        from googleapiclient.errors import HttpError

        if not video_path.exists() or video_path.stat().st_size == 0:
            raise PermanentError(f"Cannot upload: video file missing or empty at {video_path}")

        creds = self._get_credentials()
        youtube = build("youtube", "v3", credentials=creds, cache_discovery=False)

        body = {
            "snippet": {
                "title": title[:100],
                "description": description[:5000],
                "tags": tags[:15],
                "categoryId": category_id,
            },
            "status": {"privacyStatus": privacy_status, "selfDeclaredMadeForKids": False},
        }
        media = MediaFileUpload(str(video_path), chunksize=-1, resumable=True, mimetype="video/mp4")

        try:
            request = youtube.videos().insert(part="snippet,status", body=body, media_body=media)
            response = None
            while response is None:
                status, response = request.next_chunk()
                if status:
                    logger.info("YouTube upload progress: %d%%", int(status.progress() * 100))
        except HttpError as exc:
            raise RuntimeError(f"YouTube upload failed: {exc}") from exc

        video_id = response["id"]
        url = f"https://www.youtube.com/watch?v={video_id}"

        if thumbnail_path and thumbnail_path.exists():
            try:
                youtube.thumbnails().set(
                    videoId=video_id, media_body=MediaFileUpload(str(thumbnail_path))
                ).execute()
            except HttpError as exc:
                logger.warning("Thumbnail upload failed (video upload still succeeded): %s", exc)

        return {"video_id": video_id, "url": url}
