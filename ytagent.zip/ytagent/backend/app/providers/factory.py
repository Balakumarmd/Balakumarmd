"""
Provider factory.

This is the ONLY place in the application that instantiates a concrete
provider class. To add a new provider (e.g. OpenAIProvider, ElevenLabsProvider,
PixabayProvider), implement the relevant interface in providers/<category>/
and add one branch below. No other file needs to change.
"""
from __future__ import annotations

from typing import Optional

from app.config import Settings
from app.providers.base import LLMProvider, MediaProvider, TranscriptionProvider, TTSProvider, YouTubeProvider


def get_llm_provider(settings: Settings) -> LLMProvider:
    from app.providers.llm.ollama_provider import OllamaProvider

    # Only one LLM provider exists in V1 (Ollama). Future providers register
    # here, selected via a PROVIDER_CONFIG / env setting, e.g.:
    #   if settings.LLM_PROVIDER == "openai": return OpenAIProvider(settings)
    return OllamaProvider(settings)


def get_tts_provider(settings: Settings) -> TTSProvider:
    from app.providers.tts.kokoro_provider import KokoroProvider

    if settings.TTS_PROVIDER == "kokoro":
        return KokoroProvider(settings)
    raise ValueError(f"Unknown TTS_PROVIDER '{settings.TTS_PROVIDER}'")


def get_transcription_provider(settings: Settings) -> TranscriptionProvider:
    from app.providers.transcription.faster_whisper_provider import FasterWhisperProvider

    return FasterWhisperProvider(settings)


def get_media_provider(settings: Settings) -> MediaProvider:
    from app.providers.media.pexels_provider import PexelsProvider

    if settings.MEDIA_PROVIDER == "pexels":
        return PexelsProvider(settings)
    raise ValueError(f"Unknown MEDIA_PROVIDER '{settings.MEDIA_PROVIDER}'")


def get_youtube_provider(settings: Settings, stored_token_json: Optional[str] = None) -> YouTubeProvider:
    from app.providers.youtube.youtube_data_api_provider import YouTubeDataAPIProvider

    return YouTubeDataAPIProvider(settings, stored_token_json=stored_token_json)
