"""
Provider factory.

This is the ONLY place in the application that instantiates a concrete
provider class. To add a new provider (e.g. OpenAIProvider, ElevenLabsProvider,
PixabayProvider), implement the relevant interface in providers/<category>/
and add one branch below. No other file needs to change.
"""
from __future__ import annotations

from typing import Optional

from app.config import Settings
from app.providers.base import LLMProvider, MediaProvider, TranscriptionProvider, TTSProvider, YouTubeProvider


def get_llm_provider(settings: Settings) -> LLMProvider:
    provider = settings.LLM_PROVIDER.lower().strip()

    if provider == "gemini":
        from app.providers.llm.gemini_provider import GeminiProvider
        return GeminiProvider(settings, db)

    if provider == "ollama":
        from app.providers.llm.ollama_provider import OllamaProvider
        return OllamaProvider(settings)

    if provider == "groq":
        from app.providers.llm.groq_provider import GroqProvider
        return GroqProvider(settings, db)

    raise ValueError(
        f"Unsupported LLM_PROVIDER: {settings.LLM_PROVIDER}. "
        "Supported providers: ollama, gemini, groq"
    )

def get_llm_provider_from_db(
    settings: Settings,
    db,
) -> LLMProvider:
    from app.repositories.provider_config_repository import (
        ProviderConfigRepository,
    )

    config = ProviderConfigRepository.get_active(
        db,
        category="llm",
    )

    if config is None:
        return get_llm_provider(settings)

    provider = config.provider_name.lower().strip()

    if provider == "gemini":
        from app.providers.llm.gemini_provider import GeminiProvider
        return GeminiProvider(settings)

    if provider == "ollama":
        from app.providers.llm.ollama_provider import OllamaProvider
        return OllamaProvider(settings)

    if provider == "groq":
        from app.providers.llm.groq_provider import GroqProvider
        return GroqProvider(settings)

    raise ValueError(
        f"Unsupported dashboard LLM provider: {config.provider_name}. "
        "Supported providers: ollama, gemini, groq"
    )


def get_tts_provider(settings: Settings) -> TTSProvider:
    from app.providers.tts.kokoro_provider import KokoroProvider

    if settings.TTS_PROVIDER == "kokoro":
        return KokoroProvider(settings)
    raise ValueError(f"Unknown TTS_PROVIDER '{settings.TTS_PROVIDER}'")


def get_transcription_provider(settings: Settings) -> TranscriptionProvider:
    from app.providers.transcription.faster_whisper_provider import FasterWhisperProvider

    return FasterWhisperProvider(settings)


def get_media_provider(settings: Settings) -> MediaProvider:
    if settings.MEDIA_PROVIDER == "pexels":
        from app.providers.media.pexels_provider import PexelsProvider

        return PexelsProvider(settings)
    if settings.MEDIA_PROVIDER == "pixabay":
        from app.providers.media.pixabay_provider import PixabayProvider

        return PixabayProvider(settings)
    raise ValueError(f"Unknown MEDIA_PROVIDER '{settings.MEDIA_PROVIDER}' (expected 'pexels' or 'pixabay')")


def get_youtube_provider(settings: Settings, stored_token_json: Optional[str] = None) -> YouTubeProvider:
    from app.providers.youtube.youtube_data_api_provider import YouTubeDataAPIProvider

    return YouTubeDataAPIProvider(settings, stored_token_json=stored_token_json)
