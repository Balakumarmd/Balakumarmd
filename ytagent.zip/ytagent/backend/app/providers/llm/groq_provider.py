from __future__ import annotations

import logging
import time

from groq import Groq

from app.config import Settings
from app.providers.base import LLMProvider
from app.schemas.schemas import GeneratedScript
from sqlalchemy.orm import Session

from app.repositories.provider_credential_repository import (
    ProviderCredentialRepository,
)
from app.utils.secret_crypto import SecretCrypto

logger = logging.getLogger("ytagent")


class GroqProvider(LLMProvider):
    def __init__(
        self,
        settings: Settings,
        db: Session | None = None,
    ):
        self._model = settings.groq_model

        keys: list[str] = []

        if db is not None:
            credentials = ProviderCredentialRepository.get_active(
                db,
                category="llm",
                provider_name="groq",
            )

            if credentials:
                crypto = SecretCrypto()

                for credential in credentials:
                    try:
                        key = crypto.decrypt(
                            credential.encrypted_value
                        ).strip()

                        if key and key not in keys:
                            keys.append(key)

                    except Exception as exc:
                        logger.error(
                            "Failed to decrypt Groq credential %s: %s",
                            credential.id,
                            exc,
                        )

        # Temporary fallback to .env.
        # This keeps the existing system working until the dashboard
        # credentials are fully migrated.
        if not keys:
            if settings.groq_api_keys:
                keys.extend(
                    key.strip()
                    for key in settings.groq_api_keys.split(",")
                    if key.strip()
                )

            if settings.groq_api_key:
                legacy_key = settings.groq_api_key.strip()

                if legacy_key and legacy_key not in keys:
                    keys.append(legacy_key)

        if not keys:
            raise RuntimeError(
                "No Groq API keys are configured in the dashboard "
                "or backend/.env"
            )

        self._api_keys = keys
        self._clients = [
            Groq(api_key=key)
            for key in keys
        ]
        self._exhausted_keys: set[int] = set()

    def is_available(self) -> bool:
        return bool(self._api_keys)

    @staticmethod
    def _is_quota_error(exc: Exception) -> bool:
        text = str(exc).lower()

        status = getattr(exc, "status_code", None)
        code = getattr(exc, "code", None)

        if status == 429 or code == 429:
            return True

        markers = (
            "429",
            "rate limit",
            "rate_limit",
            "quota",
            "too many requests",
            "tokens per day",
            "requests per day",
            "exceeded",
        )

        return any(marker in text for marker in markers)

    @staticmethod
    def _is_503_error(exc: Exception) -> bool:
        text = str(exc).lower()

        status = getattr(exc, "status_code", None)
        code = getattr(exc, "code", None)

        if status == 503 or code == 503:
            return True

        markers = (
            "503",
            "service unavailable",
            "temporarily unavailable",
            "overloaded",
        )

        return any(marker in text for marker in markers)

    def _generate_with_key(
        self,
        index: int,
        contents: str,
        temperature: float,
    ):
        client = self._clients[index]

        last_error: Exception | None = None

        for attempt in range(3):
            try:
                response = client.chat.completions.create(
                    model=self._model,
                    messages=[
                        {
                            "role": "user",
                            "content": contents,
                        }
                    ],
                    temperature=temperature,
                )

                if not response.choices:
                    raise RuntimeError("Groq returned no choices.")

                message = response.choices[0].message

                if not message.content:
                    raise RuntimeError("Groq returned an empty response.")

                return message.content

            except Exception as exc:
                last_error = exc

                if not self._is_503_error(exc) or attempt == 2:
                    raise

                wait_seconds = 2**attempt

                logger.warning(
                    "Groq 503 unavailable on API key %s/%s. "
                    "Retrying in %s seconds...",
                    index + 1,
                    len(self._api_keys),
                    wait_seconds,
                )

                time.sleep(wait_seconds)

        raise RuntimeError(
            f"Groq request failed after retries: {last_error}"
        )

    def _generate(
        self,
        contents: str,
        temperature: float,
    ) -> str:
        for index in range(len(self._api_keys)):
            if index in self._exhausted_keys:
                continue

            try:
                return self._generate_with_key(
                    index,
                    contents,
                    temperature,
                )

            except Exception as exc:
                if self._is_quota_error(exc):
                    self._exhausted_keys.add(index)

                    logger.warning(
                        "Groq API key %s/%s exhausted. "
                        "Rotating to the next key.",
                        index + 1,
                        len(self._api_keys),
                    )
                    continue

                if self._is_503_error(exc):
                    logger.warning(
                        "Groq API key %s/%s remains unavailable "
                        "after retries. Rotating to the next key.",
                        index + 1,
                        len(self._api_keys),
                    )
                    continue

                raise

        raise RuntimeError(
            "All configured Groq API keys are exhausted or unavailable."
        )

    def generate(
        self,
        prompt: str,
        system: str | None = None,
        temperature: float = 0.7,
    ) -> str:
        contents = prompt

        if system:
            contents = f"{system}\n\n{prompt}"

        return self._generate(contents, temperature)

    def generate_script(
        self,
        prompt: str,
        system: str | None = None,
    ) -> GeneratedScript:
        contents = prompt

        if system:
            contents = f"{system}\n\n{prompt}"

        last_error: Exception | None = None

        for attempt in range(2):
            try:
                response_text = self._generate(
                    contents,
                    temperature=0.2,
                )

                return GeneratedScript.model_validate_json(
                    response_text
                )

            except Exception as exc:
                last_error = exc

                if attempt == 1:
                    raise

                logger.warning(
                    "Groq script validation failed. Retrying generation."
                )

                contents = (
                    f"{contents}\n\n"
                    "Return ONLY valid JSON matching the required "
                    "GeneratedScript schema. Do not include markdown "
                    "or explanatory text."
                )

        raise RuntimeError(
            f"Groq script generation failed: {last_error}"
        )