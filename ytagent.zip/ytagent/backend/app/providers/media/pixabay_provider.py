"""
Real MediaProvider backed by the Pixabay API (videos + photo fallback).

Pixabay was already named in the spec as the planned second media
provider, so this is a drop-in alternative to Pexels via the provider
abstraction -- no pipeline code changes needed, just MEDIA_PROVIDER and
PIXABAY_API_KEY in .env.

Get a free key: log in at https://pixabay.com, then open
https://pixabay.com/api/docs/ -- your personal key is shown inline at the
top of that page (no separate "create key" form, no approval step).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

import httpx

from app.config import Settings
from app.providers.base import MediaProvider, MediaSearchResult
from app.utils.retry import PermanentError, retry_with_backoff

logger = logging.getLogger("ytagent")

_VIDEO_SEARCH_URL = "https://pixabay.com/api/videos/"
_PHOTO_SEARCH_URL = "https://pixabay.com/api/"


class PixabayProvider(MediaProvider):
    def __init__(self, settings: Settings):
        if not settings.PIXABAY_API_KEY:
            raise PermanentError(
                "PIXABAY_API_KEY is not configured. Add it to your .env file. "
                "Get a free key at https://pixabay.com/api/docs/ (shown inline once you're logged in)."
            )
        self._api_key = settings.PIXABAY_API_KEY
        self._client = httpx.Client(timeout=30)

    def is_available(self) -> bool:
        try:
            resp = self._client.get(_VIDEO_SEARCH_URL, params={"key": self._api_key, "q": "nature", "per_page": 3})
            return resp.status_code == 200
        except Exception as exc:
            logger.warning("Pixabay availability check failed: %s", exc)
            return False

    def search(self, query: str, *, orientation: str = "portrait", per_page: int = 5) -> List[MediaSearchResult]:
        def _do_search() -> List[MediaSearchResult]:
            resp = self._client.get(
                _VIDEO_SEARCH_URL,
                params={
                    "key": self._api_key,
                    "q": query,
                    "per_page": max(per_page, 3),  # Pixabay requires per_page >= 3
                    "safesearch": "true",
                },
            )
            if resp.status_code in (401, 403):
                raise PermanentError("Pixabay API key rejected. Check PIXABAY_API_KEY.")
            if resp.status_code == 429:
                raise RuntimeError("Pixabay rate limit hit (429)")
            resp.raise_for_status()
            data = resp.json()

            results: List[MediaSearchResult] = []
            for hit in data.get("hits", []):
                variants = hit.get("videos", {})
                chosen = self._choose_video_variant(variants, orientation)
                if chosen is None:
                    continue
                results.append(
                    MediaSearchResult(
                        source_id=str(hit["id"]),
                        url=chosen["url"],
                        asset_type="video",
                        width=chosen.get("width") or 0,
                        height=chosen.get("height") or 0,
                        duration=hit.get("duration"),
                    )
                )
            return results

        try:
            return retry_with_backoff(_do_search, max_attempts=3, retry_on=(RuntimeError, httpx.HTTPError))
        except PermanentError:
            raise
        except Exception as exc:
            logger.warning("Pixabay video search failed for '%s': %s. Trying photo fallback.", query, exc)
            return self._search_photos(query, orientation, per_page=per_page)

    @staticmethod
    def _choose_video_variant(variants: dict, orientation: str) -> Optional[dict]:
        """
        Pixabay's video search has no orientation filter, so we inspect each
        hit's size variants (large/medium/small/tiny) and pick the smallest
        one that both matches the requested orientation and covers our
        minimum usable resolution.
        """
        candidates = [v for v in variants.values() if v.get("width") and v.get("height")]
        if not candidates:
            return None

        def matches_orientation(v: dict) -> bool:
            is_portrait = v["height"] >= v["width"]
            return is_portrait if orientation == "portrait" else not is_portrait

        oriented = [v for v in candidates if matches_orientation(v)] or candidates
        oriented.sort(key=lambda v: max(v["width"], v["height"]))
        for v in oriented:
            if max(v["width"], v["height"]) >= 720:
                return v
        return oriented[-1]

    def _search_photos(self, query: str, orientation: str, per_page: int = 5) -> List[MediaSearchResult]:
        pixabay_orientation = "vertical" if orientation == "portrait" else "horizontal"
        try:
            resp = self._client.get(
                _PHOTO_SEARCH_URL,
                params={
                    "key": self._api_key,
                    "q": query,
                    "image_type": "photo",
                    "orientation": pixabay_orientation,
                    "per_page": max(per_page, 3),
                    "safesearch": "true",
                },
            )
            resp.raise_for_status()
            data = resp.json()
            results = []
            for hit in data.get("hits", []):
                results.append(
                    MediaSearchResult(
                        source_id=str(hit["id"]),
                        url=hit["largeImageURL"],
                        asset_type="photo",
                        width=hit.get("imageWidth") or 0,
                        height=hit.get("imageHeight") or 0,
                    )
                )
            return results
        except Exception as exc:
            logger.error("Pixabay photo fallback also failed for '%s': %s", query, exc)
            return []

    def download(self, result: MediaSearchResult, destination: Path) -> Path:
        def _do_download() -> Path:
            destination.parent.mkdir(parents=True, exist_ok=True)
            with httpx.stream("GET", result.url, timeout=60, follow_redirects=True) as resp:
                resp.raise_for_status()
                with open(destination, "wb") as f:
                    for chunk in resp.iter_bytes(chunk_size=65536):
                        f.write(chunk)
            if not destination.exists() or destination.stat().st_size == 0:
                raise RuntimeError(f"Downloaded file is empty: {destination}")
            return destination

        return retry_with_backoff(_do_download, max_attempts=3, retry_on=(httpx.HTTPError, RuntimeError, OSError))
