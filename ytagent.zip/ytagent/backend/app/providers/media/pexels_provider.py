"""
Real MediaProvider backed by the Pexels API (videos + photo fallback).

Requires PEXELS_API_KEY in .env. Get one free at https://www.pexels.com/api/
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

import httpx

from app.config import Settings
from app.providers.base import MediaProvider, MediaSearchResult
from app.utils.retry import PermanentError, retry_with_backoff

logger = logging.getLogger("ytagent")

_VIDEO_SEARCH_URL = "https://api.pexels.com/videos/search"
_PHOTO_SEARCH_URL = "https://api.pexels.com/v1/search"


class PexelsProvider(MediaProvider):
    def __init__(self, settings: Settings):
        if not settings.PEXELS_API_KEY:
            raise PermanentError(
                "PEXELS_API_KEY is not configured. Add it to your .env file. "
                "Get a free key at https://www.pexels.com/api/"
            )
        self._api_key = settings.PEXELS_API_KEY
        self._client = httpx.Client(headers={"Authorization": self._api_key}, timeout=30)

    def is_available(self) -> bool:
        try:
            resp = self._client.get(_VIDEO_SEARCH_URL, params={"query": "nature", "per_page": 1})
            return resp.status_code == 200
        except Exception as exc:
            logger.warning("Pexels availability check failed: %s", exc)
            return False

    def search(self, query: str, *, orientation: str = "portrait", per_page: int = 5) -> List[MediaSearchResult]:
        def _do_search() -> List[MediaSearchResult]:
            resp = self._client.get(
                _VIDEO_SEARCH_URL,
                params={"query": query, "orientation": orientation, "per_page": per_page, "size": "medium"},
            )
            if resp.status_code == 401:
                raise PermanentError("Pexels API key rejected (401). Check PEXELS_API_KEY.")
            if resp.status_code == 429:
                raise RuntimeError("Pexels rate limit hit (429)")
            resp.raise_for_status()
            data = resp.json()
            results: List[MediaSearchResult] = []
            for video in data.get("videos", []):
                # Pick the smallest file that still covers our target resolution
                files = sorted(video.get("video_files", []), key=lambda f: (f.get("width") or 0))
                chosen = None
                for f in files:
                    if (f.get("width") or 0) >= 720:
                        chosen = f
                        break
                if chosen is None and files:
                    chosen = files[-1]
                if chosen is None:
                    continue
                results.append(
                    MediaSearchResult(
                        source_id=str(video["id"]),
                        url=chosen["link"],
                        asset_type="video",
                        width=chosen.get("width") or 0,
                        height=chosen.get("height") or 0,
                        duration=video.get("duration"),
                    )
                )
            return results

        try:
            return retry_with_backoff(_do_search, max_attempts=3, retry_on=(RuntimeError, httpx.HTTPError))
        except PermanentError:
            raise
        except Exception as exc:
            logger.warning("Pexels video search failed for '%s': %s. Trying photo fallback.", query, exc)
            return self._search_photos(query, per_page=per_page)

    def _search_photos(self, query: str, per_page: int = 5) -> List[MediaSearchResult]:
        try:
            resp = self._client.get(_PHOTO_SEARCH_URL, params={"query": query, "per_page": per_page})
            resp.raise_for_status()
            data = resp.json()
            results = []
            for photo in data.get("photos", []):
                results.append(
                    MediaSearchResult(
                        source_id=str(photo["id"]),
                        url=photo["src"]["large2x"],
                        asset_type="photo",
                        width=photo.get("width") or 0,
                        height=photo.get("height") or 0,
                    )
                )
            return results
        except Exception as exc:
            logger.error("Pexels photo fallback also failed for '%s': %s", query, exc)
            return []

    def download(self, result: MediaSearchResult, destination: Path) -> Path:
        def _do_download() -> Path:
            destination.parent.mkdir(parents=True, exist_ok=True)
            with httpx.stream("GET", result.url, timeout=60, follow_redirects=True) as resp:
                resp.raise_for_status()
                with open(destination, "wb") as f:
                    for chunk in resp.iter_bytes(chunk_size=65536):
                        f.write(chunk)
            if not destination.exists() or destination.stat().st_size == 0:
                raise RuntimeError(f"Downloaded file is empty: {destination}")
            return destination

        return retry_with_backoff(_do_download, max_attempts=3, retry_on=(httpx.HTTPError, RuntimeError, OSError))
