"""
SQLite persistence layer.

The application talks to SQLite through SQLAlchemy Core/ORM only. No part
of the business logic issues raw string-formatted SQL, and no part of the
schema is SQLite-specific in a way that would prevent swapping in
PostgreSQL later (see repositories/ for the one place that uses a SQLite
specific atomic-claim transaction, which has a documented PostgreSQL
equivalent in a comment).
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Generator

from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker

from app.config import get_settings

_settings = get_settings()

# check_same_thread=False is required because the API process and the
# worker process each open their own connections; SQLite itself is safe
# for multi-process access as long as we use short transactions and WAL.
engine = create_engine(
    _settings.database_url,
    connect_args={"check_same_thread": False, "timeout": 30},
    future=True,
)


@event.listens_for(engine, "connect")
def _set_sqlite_pragmas(dbapi_connection, connection_record):  # noqa: ANN001
    cursor = dbapi_connection.cursor()
    # WAL mode allows one writer + many readers concurrently, which is what
    # lets the API process and the worker process share the same DB file
    # safely.
    cursor.execute("PRAGMA journal_mode=WAL;")
    cursor.execute("PRAGMA synchronous=NORMAL;")
    cursor.execute("PRAGMA foreign_keys=ON;")
    cursor.execute("PRAGMA busy_timeout=30000;")
    cursor.close()


SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


class Base:
    pass


from sqlalchemy.orm import declarative_base  # noqa: E402

Base = declarative_base()


def init_db() -> None:
    from app import models  # noqa: F401  (ensures models are registered)

    Base.metadata.create_all(bind=engine)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def session_scope() -> Generator[Session, None, None]:
    """Context manager for use outside of FastAPI's dependency injection
    (e.g. inside the worker process)."""
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
