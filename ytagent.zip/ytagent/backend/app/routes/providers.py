from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.repositories.provider_credential_repository import ProviderCredentialRepository
from app.schemas.schemas import (
    ProviderCredentialCreateRequest,
    ProviderCredentialListResponse,
    ProviderCredentialResponse,
)
from app.utils.secret_crypto import SecretCrypto

router = APIRouter(prefix="/api/providers", tags=["providers"])


@router.post("/credentials", response_model=ProviderCredentialResponse)
def create_provider_credential(
    payload: ProviderCredentialCreateRequest,
    db: Session = Depends(get_db),
):
    crypto = SecretCrypto()

    encrypted_value = crypto.encrypt(payload.secret)

    credential = ProviderCredentialRepository.create(
        db,
        category=payload.category,
        provider_name=payload.provider_name,
        credential_type=payload.credential_type,
        display_name=payload.display_name,
        encrypted_value=encrypted_value,
    )

    db.commit()
    db.refresh(credential)

    return credential


@router.get(
    "/credentials/{category}/{provider_name}",
    response_model=ProviderCredentialListResponse,
)
def list_provider_credentials(
    category: str,
    provider_name: str,
    db: Session = Depends(get_db),
):
    credentials = ProviderCredentialRepository.list_by_provider(
        db,
        category=category,
        provider_name=provider_name,
    )

    return {"credentials": credentials}


@router.get("/config/{category}")
def list_provider_configs(
    category: str,
    db: Session = Depends(get_db),
):
    from app.repositories.provider_config_repository import (
        ProviderConfigRepository,
    )

    configs = ProviderConfigRepository.list_by_category(
        db,
        category=category,
    )

    return {
        "configs": [
            {
                "id": config.id,
                "category": config.category,
                "provider_name": config.provider_name,
                "is_active": config.is_active,
                "config_json": config.config_json,
                "updated_at": config.updated_at,
            }
            for config in configs
        ]
    }


@router.put("/config/{category}/{provider_name}")
def set_provider_config(
    category: str,
    provider_name: str,
    db: Session = Depends(get_db),
):
    from app.repositories.provider_config_repository import (
        ProviderConfigRepository,
    )

    ProviderConfigRepository.deactivate_category(
        db,
        category=category,
    )

    config = ProviderConfigRepository.get_by_provider(
        db,
        category=category,
        provider_name=provider_name,
    )

    if config is None:
        config = ProviderConfigRepository.create(
            db,
            category=category,
            provider_name=provider_name,
        )
    else:
        config.is_active = True
        db.flush()

    db.commit()
    db.refresh(config)

    return {
        "id": config.id,
        "category": config.category,
        "provider_name": config.provider_name,
        "is_active": config.is_active,
        "config_json": config.config_json,
        "updated_at": config.updated_at,
    }