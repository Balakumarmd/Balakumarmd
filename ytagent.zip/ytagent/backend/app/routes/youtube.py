from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.config import Settings, get_settings
from app.database import get_db
from app.repositories import video_repository
from app.services.youtube_service import YouTubeService
from app.utils.retry import PermanentError

router = APIRouter(prefix="/api/youtube", tags=["youtube"])


@router.post("/connect")
def connect(settings: Settings = Depends(get_settings), db: Session = Depends(get_db)):
    try:
        svc = YouTubeService(settings, db)
        url = svc.get_authorization_url()
        return {"authorization_url": url}
    except PermanentError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/oauth2callback")
def oauth2callback(code: str, settings: Settings = Depends(get_settings), db: Session = Depends(get_db)):
    try:
        svc = YouTubeService(settings, db)
        svc.handle_oauth_callback(code)
    except Exception as exc:
        return HTMLResponse(f"<h2>YouTube connection failed</h2><p>{exc}</p>", status_code=400)
    return HTMLResponse(
        "<h2>YouTube account connected successfully.</h2>"
        "<p>You can close this tab and return to the dashboard.</p>"
    )


@router.get("/status")
def status(settings: Settings = Depends(get_settings), db: Session = Depends(get_db)):
    svc = YouTubeService(settings, db)
    return {"connected": svc.is_connected()}


@router.post("/upload/{video_id}")
def upload(video_id: str, settings: Settings = Depends(get_settings), db: Session = Depends(get_db)):
    video = video_repository.get_video(db, video_id)
    if video is None or not video.file_path:
        raise HTTPException(status_code=404, detail="Video not found")

    from pathlib import Path

    svc = YouTubeService(settings, db)
    if not svc.is_connected():
        raise HTTPException(status_code=400, detail="YouTube account not connected. Use /api/youtube/connect first.")

    try:
        result = svc.upload_video(
            Path(video.file_path),
            video.title or "Untitled video",
            video.description or "",
            video.tags or [],
            video.category or "27",
            "private",
            thumbnail_path=Path(video.thumbnail_path) if video.thumbnail_path else None,
        )
    except PermanentError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Upload failed: {exc}")

    video_repository.mark_uploaded(db, video_id, result["video_id"], result["url"], "private")
    return result
