from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import JobStatus
from app.repositories import job_repository
from app.schemas.schemas import JobCreateRequest, JobResponse

router = APIRouter(prefix="/api/jobs", tags=["jobs"])


@router.post("", response_model=JobResponse)
def create_job(payload: JobCreateRequest, db: Session = Depends(get_db)):
    # Sensible defaults for duration if the client didn't specify one.
    target_duration = payload.target_duration_seconds or (45 if payload.content_type == "short" else 180)

    job = job_repository.create_job(
        db,
        topic=payload.topic,
        content_type=payload.content_type,
        project_id=payload.project_id,
        niche=payload.niche,
        language=payload.language,
        target_duration_seconds=target_duration,
        voice=payload.voice,
        visual_style=payload.visual_style,
        music_preference=payload.music_preference,
        research_enabled=payload.research_enabled,
        auto_upload=payload.auto_upload,
        upload_privacy=payload.upload_privacy,
        status=JobStatus.QUEUED.value,
        progress=0,
    )
    return job


@router.get("", response_model=list[JobResponse])
def list_jobs(status: str | None = None, limit: int = 100, db: Session = Depends(get_db)):
    return job_repository.list_jobs(db, limit=limit, status=status)


@router.get("/{job_id}", response_model=JobResponse)
def get_job(job_id: str, db: Session = Depends(get_db)):
    job = job_repository.get_job(db, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.post("/{job_id}/cancel", response_model=JobResponse)
def cancel_job(job_id: str, db: Session = Depends(get_db)):
    job = job_repository.cancel_job(db, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.post("/{job_id}/retry", response_model=JobResponse)
def retry_job(job_id: str, db: Session = Depends(get_db)):
    job = job_repository.retry_job(db, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.post("/{job_id}/generate", response_model=JobResponse)
def generate_now(job_id: str, db: Session = Depends(get_db)):
    """
    No-op convenience endpoint: jobs are already queued automatically on
    creation and picked up by any running worker. This endpoint exists for
    UI flows that want an explicit "Generate" confirmation step and simply
    returns current job state (and re-queues if the job had previously
    failed or was cancelled).
    """
    job = job_repository.get_job(db, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    if job.status in (JobStatus.FAILED.value, JobStatus.CANCELLED.value):
        job = job_repository.retry_job(db, job_id)
    return job
