"""
Aggregates health checks for every subsystem (spec section 38) so the
dashboard's System Status page and GET /api/system/status reflect the
real, current state of each dependency -- never a hardcoded "ok".
"""
from __future__ import annotations

from typing import Optional

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.config import Settings
from app.database import engine
from app.utils.ffmpeg_utils import check_ffmpeg_available
from app.utils.system_info import get_cpu_info, get_disk_info, get_gpu_info, get_memory_info


def check_database() -> str:
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return "ok"
    except Exception:
        return "error"


def check_ollama(settings: Settings) -> str:
    try:
        from app.providers.llm.ollama_provider import OllamaProvider

        return "ok" if OllamaProvider(settings).is_available() else "unavailable"
    except Exception:
        return "unavailable"


def check_ffmpeg() -> str:
    return "ok" if check_ffmpeg_available() else "unavailable"


def check_tts(settings: Settings) -> str:
    try:
        from app.providers.tts.kokoro_provider import KokoroProvider

        return "ok" if KokoroProvider(settings).is_available() else "unavailable"
    except Exception:
        return "unavailable"


def check_whisper(settings: Settings) -> str:
    try:
        from app.providers.transcription.faster_whisper_provider import FasterWhisperProvider

        return "ok" if FasterWhisperProvider(settings).is_available() else "unavailable"
    except Exception:
        return "unavailable"


def check_media_provider(settings: Settings) -> str:
    """Checks whichever MediaProvider is currently active (Pexels or
    Pixabay) rather than hardcoding Pexels -- swapping MEDIA_PROVIDER in
    .env is reflected here automatically."""
    try:
        from app.providers.factory import get_media_provider

        provider = get_media_provider(settings)
    except Exception:
        return "not_configured"
    try:
        return "configured" if provider.is_available() else "error"
    except Exception:
        return "error"


def check_youtube(db: Session) -> str:
    try:
        from app.services.youtube_service import YouTubeService
        from app.config import get_settings

        svc = YouTubeService(get_settings(), db)
        return "connected" if svc.is_connected() else "not_connected"
    except Exception:
        return "not_connected"


def full_system_status(settings: Settings, db: Session) -> dict:
    return {
        "api": "ok",
        "database": check_database(),
        "ollama": check_ollama(settings),
        "ollama_model": settings.OLLAMA_MODEL,
        "ffmpeg": check_ffmpeg(),
        "tts": check_tts(settings),
        "whisper": check_whisper(settings),
        "media_provider_name": settings.MEDIA_PROVIDER,
        "pexels": check_media_provider(settings),  # key name kept for dashboard compatibility
        "youtube": check_youtube(db),
        "storage": get_disk_info(str(settings.data_dir_path)),
        "cpu": get_cpu_info(),
        "memory": get_memory_info(),
        "gpu": get_gpu_info(),
        "data_dir": str(settings.data_dir_path),
    }
