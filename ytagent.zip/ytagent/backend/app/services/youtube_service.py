"""
Thin orchestration around the YouTubeProvider: persists OAuth tokens to the
`channels` table and exposes connect/status/upload operations to the API
and worker layers.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import List, Optional

from sqlalchemy.orm import Session

from app.config import Settings
from app.models import Channel
from app.providers.factory import get_youtube_provider


class YouTubeService:
    def __init__(self, settings: Settings, db: Session):
        self._settings = settings
        self._db = db

    def _get_active_channel(self) -> Optional[Channel]:
        return self._db.query(Channel).filter(Channel.is_active == True).first()  # noqa: E712

    def get_authorization_url(self) -> str:
        provider = get_youtube_provider(self._settings)
        return provider.get_authorization_url()

    def handle_oauth_callback(self, code: str) -> Channel:
        provider = get_youtube_provider(self._settings)
        token_dict = provider.exchange_code_for_token(code)

        channel = self._get_active_channel()
        if channel is None:
            channel = Channel(is_active=True)
            self._db.add(channel)

        import json

        channel.token_json = json.dumps(token_dict)
        channel.connected_at = datetime.utcnow()
        self._db.commit()
        self._db.refresh(channel)
        return channel

    def is_connected(self) -> bool:
        channel = self._get_active_channel()
        return channel is not None and channel.token_json is not None

    def upload_video(
        self,
        video_path: Path,
        title: str,
        description: str,
        tags: List[str],
        category_id: str,
        privacy_status: str,
        thumbnail_path: Optional[Path] = None,
    ) -> dict:
        channel = self._get_active_channel()
        stored_token = channel.token_json if channel else None
        provider = get_youtube_provider(self._settings, stored_token_json=stored_token)
        result = provider.upload_video(
            video_path, title, description, tags, category_id, privacy_status, thumbnail_path
        )

        # Persist any refreshed token back to the DB.
        if channel is not None:
            try:
                refreshed = provider.get_refreshed_token_json()  # type: ignore[attr-defined]
                channel.token_json = refreshed
                self._db.commit()
            except Exception:
                pass

        return result
