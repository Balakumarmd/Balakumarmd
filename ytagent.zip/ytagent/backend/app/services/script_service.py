"""
Turns a topic + parameters into a structured, validated GeneratedScript
using the configured LLM provider (Ollama / qwen3:8b by default).

Reliability strategy (per spec section 10):
  1. Ask the model for JSON only, with an explicit schema description.
  2. Try to parse/repair the JSON (app.utils.json_repair).
  3. Validate against the GeneratedScript Pydantic schema.
  4. If invalid, re-prompt once with the validation error appended so the
     model can correct itself.
  5. If it still fails, raise a clear, typed error -- never fabricate a
     script or silently accept malformed data.
"""
from __future__ import annotations

import logging

from pydantic import ValidationError

from app.config import Settings
from app.providers.base import LLMProvider
from app.schemas.schemas import GeneratedScript
from app.utils.json_repair import safe_parse_json

logger = logging.getLogger("ytagent")

_SYSTEM_PROMPT = (
    "You are a professional video scriptwriter. You ALWAYS respond with a single "
    "valid JSON object and nothing else -- no markdown fences, no commentary, "
    "no explanations before or after the JSON."
)

_SCHEMA_DESCRIPTION = """
Respond with a single JSON object with EXACTLY this shape:
{
  "title": "<short catchy title>",
  "hook": "<1-2 sentence spoken hook for the first 3-5 seconds>",
  "scenes": [
    {
      "scene_number": 1,
      "narration": "<spoken narration text for this scene, natural spoken language>",
      "visual_query": "<a short, concrete visual search phrase describing what should be shown on screen, e.g. 'student typing on laptop at night'>",
      "duration": 5.0
    }
  ],
  "outro": "<short closing line>",
  "cta": "<optional short call to action, or empty string>",
  "estimated_duration": 45.0
}
Rules:
- narration must be natural spoken English, no stage directions, no emojis, no hashtags.
- visual_query must describe a concrete, filmable subject (not an abstract idea) so it can be used as a stock footage search query.
- durations are in seconds and must sum close to the requested target duration.
- Do not include any text outside the JSON object.
"""


class ScriptGenerationError(Exception):
    pass


class ScriptService:
    def __init__(self, llm: LLMProvider):
        self._llm = llm

    def _build_prompt(
        self,
        topic: str,
        content_type: str,
        niche: str | None,
        target_duration_seconds: int,
        research_context: str | None,
    ) -> str:
        pacing_guidance = (
            "This is a YouTube SHORT: prioritize a strong first-3-second hook, fast pacing, "
            "punchy short sentences, high retention, and a clear ending. Use 4-8 short scenes."
            if content_type == "short"
            else "This is a LONG-FORM video: include a clear introduction, problem/context, "
            "main points with examples, and a conclusion. Use as many scenes as needed for good pacing."
        )
        niche_line = f"Niche/category: {niche}\n" if niche else ""
        research_block = f"\nResearch context (use only verified facts from here; do not invent facts):\n{research_context}\n" if research_context else ""

        return (
            f"Topic: {topic}\n"
            f"{niche_line}"
            f"Target total spoken duration: approximately {target_duration_seconds} seconds.\n"
            f"{pacing_guidance}\n"
            f"{research_block}\n"
            f"{_SCHEMA_DESCRIPTION}"
        )

    def generate_script(
        self,
        *,
        topic: str,
        content_type: str,
        niche: str | None,
        target_duration_seconds: int,
        research_context: str | None = None,
    ) -> GeneratedScript:
        prompt = self._build_prompt(topic, content_type, niche, target_duration_seconds, research_context)

        last_error: Exception | None = None
        for attempt in range(1, 3):  # one initial try + one corrective retry
            raw = self._llm.generate(prompt, system=_SYSTEM_PROMPT, temperature=0.7)
            try:
                data = safe_parse_json(raw)
                script = GeneratedScript.model_validate(data)
                return script
            except (ValueError, ValidationError) as exc:
                last_error = exc
                logger.warning("Script generation attempt %s produced invalid output: %s", attempt, exc)
                prompt = (
                    prompt
                    + f"\n\nYour previous response was invalid JSON or did not match the schema "
                    f"(error: {exc}). Respond again with ONLY the corrected JSON object."
                )
        raise ScriptGenerationError(
            f"LLM failed to produce a valid script after retries. Last error: {last_error}"
        )
