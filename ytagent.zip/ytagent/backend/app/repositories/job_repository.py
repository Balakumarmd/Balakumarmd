"""
Job repository.

The most important function here is `claim_next_job`, which must guarantee
that if two worker processes race to claim the same job, exactly one of
them wins. This is implemented with a single atomic UPDATE ... WHERE
status='QUEUED' statement (no separate SELECT-then-UPDATE), so there is no
window in which two workers could both believe they own the job.

PostgreSQL note (for future cloud migration): the same pattern works
unchanged against PostgreSQL. If higher throughput is ever needed,
`SELECT ... FOR UPDATE SKIP LOCKED` is the PostgreSQL-idiomatic upgrade,
but is not required for the single-writer-at-a-time SQLite deployment.
"""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from sqlalchemy import update
from sqlalchemy.orm import Session

from app.models import Job, JobStatus, TERMINAL_STATES


def create_job(db: Session, **kwargs) -> Job:
    job = Job(**kwargs)
    db.add(job)
    db.commit()
    db.refresh(job)
    return job


def get_job(db: Session, job_id: str) -> Optional[Job]:
    return db.get(Job, job_id)


def list_jobs(db: Session, limit: int = 100, status: Optional[str] = None) -> List[Job]:
    q = db.query(Job).order_by(Job.created_at.desc())
    if status:
        q = q.filter(Job.status == status)
    return q.limit(limit).all()


def claim_next_job(db: Session, worker_id: str) -> Optional[Job]:
    """
    Atomically claim the oldest QUEUED job for this worker.

    Implementation: SQLite guarantees that a single UPDATE statement is
    atomic with respect to other connections (each connection blocks on the
    database's write lock, and WAL mode lets readers proceed without
    blocking). We first identify a candidate id with a plain SELECT, then
    perform a conditional UPDATE that only succeeds if the row is *still*
    QUEUED. If the UPDATE affects 0 rows, another worker won the race and we
    retry against the next candidate. This avoids a long-held explicit
    transaction while still being race-free.
    """
    for _ in range(25):  # bounded retries to avoid a pathological infinite loop
        candidate = (
            db.query(Job.id)
            .filter(Job.status == JobStatus.QUEUED.value)
            .order_by(Job.created_at.asc())
            .limit(1)
            .first()
        )
        if candidate is None:
            return None
        job_id = candidate[0]

        stmt = (
            update(Job)
            .where(Job.id == job_id, Job.status == JobStatus.QUEUED.value)
            .values(
                status=JobStatus.CLAIMED.value,
                claimed_by_worker_id=worker_id,
                claimed_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
        )
        result = db.execute(stmt)
        db.commit()

        if result.rowcount == 1:
            job = db.get(Job, job_id)
            db.refresh(job)
            return job
        # rowcount == 0 means someone else claimed it first; loop and try again
        continue
    return None


def update_job_progress(
    db: Session,
    job_id: str,
    status: Optional[str] = None,
    progress: Optional[int] = None,
    current_step: Optional[str] = None,
) -> Optional[Job]:
    job = db.get(Job, job_id)
    if job is None:
        return None
    if status is not None:
        job.status = status
    if progress is not None:
        job.progress = max(0, min(100, progress))
    if current_step is not None:
        job.current_step = current_step
    job.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(job)
    return job


def mark_job_failed(db: Session, job_id: str, error_code: str, error_message: str) -> Optional[Job]:
    job = db.get(Job, job_id)
    if job is None:
        return None
    job.status = JobStatus.FAILED.value
    job.error_code = error_code
    job.error_message = error_message[:4000]
    job.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(job)
    return job


def mark_job_completed(db: Session, job_id: str, output_video_path: str) -> Optional[Job]:
    job = db.get(Job, job_id)
    if job is None:
        return None
    job.status = JobStatus.COMPLETED.value
    job.progress = 100
    job.output_video_path = output_video_path
    job.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(job)
    return job


def requeue_job_for_retry(db: Session, job_id: str) -> Optional[Job]:
    job = db.get(Job, job_id)
    if job is None:
        return None
    job.status = JobStatus.QUEUED.value
    job.retry_count = (job.retry_count or 0) + 1
    job.claimed_by_worker_id = None
    job.claimed_at = None
    job.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(job)
    return job


def cancel_job(db: Session, job_id: str) -> Optional[Job]:
    job = db.get(Job, job_id)
    if job is None:
        return None
    if job.status in {s.value for s in TERMINAL_STATES}:
        return job
    job.status = JobStatus.CANCELLED.value
    job.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(job)
    return job


def retry_job(db: Session, job_id: str) -> Optional[Job]:
    """Re-queue a FAILED or CANCELLED job so the worker can pick it up again."""
    job = db.get(Job, job_id)
    if job is None:
        return None
    if job.status not in (JobStatus.FAILED.value, JobStatus.CANCELLED.value):
        return job
    job.status = JobStatus.QUEUED.value
    job.error_code = None
    job.error_message = None
    job.progress = 0
    job.current_step = None
    job.claimed_by_worker_id = None
    job.claimed_at = None
    job.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(job)
    return job
