from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import ProviderConfig


class ProviderConfigRepository:

    @staticmethod
    def list_by_category(
        db: Session,
        *,
        category: str,
    ) -> list[ProviderConfig]:
        stmt = (
            select(ProviderConfig)
            .where(ProviderConfig.category == category)
            .order_by(ProviderConfig.updated_at.desc())
        )
        return list(db.scalars(stmt).all())

    @staticmethod
    def get_active(
        db: Session,
        *,
        category: str,
    ) -> ProviderConfig | None:
        stmt = (
            select(ProviderConfig)
            .where(
                ProviderConfig.category == category,
                ProviderConfig.is_active.is_(True),
            )
            .order_by(ProviderConfig.updated_at.desc())
        )
        return db.scalars(stmt).first()

    @staticmethod
    def get_by_provider(
        db: Session,
        *,
        category: str,
        provider_name: str,
    ) -> ProviderConfig | None:
        stmt = select(ProviderConfig).where(
            ProviderConfig.category == category,
            ProviderConfig.provider_name == provider_name,
        )
        return db.scalars(stmt).first()

    @staticmethod
    def create(
        db: Session,
        *,
        category: str,
        provider_name: str,
        config_json: dict | None = None,
    ) -> ProviderConfig:
        config = ProviderConfig(
            category=category,
            provider_name=provider_name,
            is_active=True,
            config_json=config_json,
        )
        db.add(config)
        db.flush()
        return config

    @staticmethod
    def deactivate_category(
        db: Session,
        *,
        category: str,
    ) -> None:
        configs = ProviderConfigRepository.list_by_category(
            db,
            category=category,
        )

        for config in configs:
            config.is_active = False

        db.flush()