from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import ProviderCredential


class ProviderCredentialRepository:

    @staticmethod
    def create(
        db: Session,
        *,
        category: str,
        provider_name: str,
        encrypted_value: str,
        credential_type: str = "api_key",
        display_name: str | None = None,
    ) -> ProviderCredential:
        credential = ProviderCredential(
            category=category,
            provider_name=provider_name,
            credential_type=credential_type,
            display_name=display_name,
            encrypted_value=encrypted_value,
            is_active=True,
            is_exhausted=False,
        )

        db.add(credential)
        db.flush()
        return credential

    @staticmethod
    def list_by_provider(
        db: Session,
        *,
        category: str,
        provider_name: str,
    ) -> list[ProviderCredential]:
        stmt = (
            select(ProviderCredential)
            .where(
                ProviderCredential.category == category,
                ProviderCredential.provider_name == provider_name,
            )
            .order_by(ProviderCredential.created_at.asc())
        )

        return list(db.scalars(stmt).all())

    @staticmethod
    def get_active(
        db: Session,
        *,
        category: str,
        provider_name: str,
    ) -> list[ProviderCredential]:
        stmt = (
            select(ProviderCredential)
            .where(
                ProviderCredential.category == category,
                ProviderCredential.provider_name == provider_name,
                ProviderCredential.is_active.is_(True),
                ProviderCredential.is_exhausted.is_(False),
            )
            .order_by(ProviderCredential.created_at.asc())
        )

        return list(db.scalars(stmt).all())

    @staticmethod
    def mark_exhausted(
        db: Session,
        credential: ProviderCredential,
        exhausted: bool = True,
    ) -> None:
        credential.is_exhausted = exhausted
        db.flush()

    @staticmethod
    def set_active(
        db: Session,
        credential: ProviderCredential,
        active: bool,
    ) -> None:
        credential.is_active = active
        db.flush()