"""
The job pipeline: orchestrates a single Job through every stage of real
video generation (spec sections 6, 10-25), updating progress in SQLite as
it goes, and mapping any failure to a clear error code + message rather
than letting a raw traceback reach the user.
"""
from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path
from typing import Optional

from app.config import Settings
from app.models import Job, JobStatus
from app.providers.factory import (
    get_llm_provider,
    get_media_provider,
    get_tts_provider,
    get_transcription_provider,
)
from app.repositories import job_repository, video_repository
from app.schemas.schemas import GeneratedScript
from app.services.caption_service import CaptionService, CaptionStyle
from app.services.media_service import MediaAcquisitionError, MediaService
from app.services.metadata_service import MetadataGenerationError, MetadataService
from app.services.music_service import resolve_music_path
from app.services.render_service import RenderError, RenderService, get_render_config
from app.services.research_service import ResearchService
from app.services.script_service import ScriptGenerationError, ScriptService
from app.services.thumbnail_service import ThumbnailError, ThumbnailService
from app.services.transcription_service import TranscriptionError, TranscriptionService
from app.services.tts_service import TTSGenerationError, TTSService
from app.services.workspace_service import JobWorkspace
from app.services.youtube_service import YouTubeService
from app.utils import error_codes
from app.utils.logging_config import get_job_logger
from app.utils.retry import PermanentError

logger = logging.getLogger("ytagent")

# Minimum free disk space required before starting a render (spec 44/45).
_MIN_FREE_DISK_BYTES = 2 * 1024 * 1024 * 1024  # 2 GB


class JobFailedError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def _progress(db, job_id: str, status: JobStatus, pct: int, step: str) -> None:
    job_repository.update_job_progress(db, job_id, status=status.value, progress=pct, current_step=step)


def run_job(db_session_factory, job_id: str, settings: Settings) -> None:
    """
    Executes the full pipeline for one job using its own short-lived DB
    sessions per step (so a long-running step never holds the SQLite
    write lock open unnecessarily).
    """
    with db_session_factory() as db:
        job = job_repository.get_job(db, job_id)
        if job is None:
            logger.error("Job %s not found when worker tried to run it", job_id)
            return
        topic = job.topic
        content_type = job.content_type
        niche = job.niche
        target_duration = job.target_duration_seconds
        voice = job.voice
        music_preference = job.music_preference
        research_enabled = job.research_enabled
        auto_upload = job.auto_upload
        upload_privacy = job.upload_privacy or "private"

    workspace = JobWorkspace(settings, job_id)
    job_logger = get_job_logger(job_id, workspace.root)
    job_logger.info("Starting pipeline for job %s | topic='%s' | type=%s", job_id, topic, content_type)

    try:
        _check_disk_space(settings, job_logger)

        # ---- 1. RESEARCH (optional) ------------------------------------------------
        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.RESEARCHING, 5, "Gathering research context")
        research_context = None
        if research_enabled:
            research_context = ResearchService(settings).gather_research(topic)
            job_logger.info("Research context gathered: %s chars", len(research_context or ""))

        # ---- 2. SCRIPT + SCENE PLANNING ------------------------------------------
        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.SCRIPTING, 15, "Generating script")
        script = _generate_script(settings, topic, content_type, niche, target_duration, research_context, job_logger)
        workspace.script_path.write_text(script.model_dump_json(indent=2), encoding="utf-8")
        workspace.narration_text_path.write_text(script.full_narration_text(), encoding="utf-8")

        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.SCENE_PLANNING, 25, f"Planned {len(script.scenes)} scenes")
        job_logger.info("Script generated: '%s' with %d scenes", script.title, len(script.scenes))

        # ---- 3. TTS ----------------------------------------------------------------
        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.GENERATING_AUDIO, 35, "Generating narration audio")
        audio_path, audio_duration = _generate_audio(settings, script, workspace, voice, job_logger)
        job_logger.info("Narration audio ready: %.2fs", audio_duration)

        # ---- 4. TRANSCRIPTION / WORD TIMESTAMPS ------------------------------------
        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.TRANSCRIBING, 45, "Generating word-level captions timing")
        transcript = _transcribe(settings, audio_path, workspace, job_logger)

        # ---- 5. MEDIA ACQUISITION --------------------------------------------------
        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.FETCHING_MEDIA, 60, "Finding and downloading visual footage")
        orientation = "portrait" if content_type == "short" else "landscape"
        assets = _acquire_media(settings, script, workspace, orientation, job_logger)

        # ---- 6. CAPTIONS + RENDER --------------------------------------------------
        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.RENDERING, 70, "Rendering video")
        render_cfg = get_render_config(content_type)
        CaptionService().generate_caption_file(
            transcript.words, workspace.captions_ass_path, render_cfg.width, render_cfg.height, CaptionStyle()
        )
        music_path = resolve_music_path(settings.music_dir, music_preference)
        _render(render_cfg, script, assets, audio_path, workspace, music_path, job_logger)

        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.RENDERING, 85, "Finalizing render")

        # ---- 7. THUMBNAIL ------------------------------------------------------------
        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.GENERATING_THUMBNAIL, 90, "Generating thumbnail")
        _generate_thumbnail(script, workspace, job_logger)

        # ---- 8. METADATA ---------------------------------------------------------------
        with db_session_factory() as db:
            _progress(db, job_id, JobStatus.GENERATING_METADATA, 95, "Generating title, description, tags")
        metadata = _generate_metadata(settings, script, content_type, niche, workspace, job_logger)

        # ---- 9. PERSIST VIDEO RECORD ----------------------------------------------------
        duration_seconds = audio_duration
        with db_session_factory() as db:
            existing = video_repository.get_video_by_job(db, job_id)
            job = job_repository.get_job(db, job_id)
            video_kwargs = dict(
                job_id=job_id,
                project_id=job.project_id if job else None,
                title=metadata.title,
                description=metadata.description,
                tags=metadata.tags,
                category=metadata.category_id,
                file_path=str(workspace.final_video_path),
                thumbnail_path=str(workspace.thumbnail_path),
                duration_seconds=duration_seconds,
                content_type=content_type,
            )
            if existing:
                video = video_repository.update_video(db, existing.id, **video_kwargs)
            else:
                video = video_repository.create_video(db, **video_kwargs)

            job_repository.update_job_progress(db, job_id, status=JobStatus.READY.value, progress=97, current_step="Video ready")

        # ---- 10. OPTIONAL UPLOAD --------------------------------------------------------
        if auto_upload:
            with db_session_factory() as db:
                _progress(db, job_id, JobStatus.UPLOADING, 98, "Uploading to YouTube")
            try:
                _upload_to_youtube(settings, workspace, metadata, upload_privacy, job_id, video.id, job_logger)
            except JobFailedError as exc:
                # Upload failure should not erase an otherwise-successful local video;
                # mark the job failed but the video record/local file remain usable.
                with db_session_factory() as db:
                    job_repository.mark_job_failed(db, job_id, exc.code, exc.message)
                job_logger.error("Upload failed but local video is complete: %s", exc.message)
                return

        with db_session_factory() as db:
            job_repository.mark_job_completed(db, job_id, str(workspace.final_video_path))
        job_logger.info("Job %s completed successfully", job_id)

    except JobFailedError as exc:
        job_logger.error("Job failed [%s]: %s", exc.code, exc.message)
        _handle_failure(db_session_factory, job_id, exc.code, exc.message)
    except Exception as exc:  # noqa: BLE001 - last line of defense, never leak raw traceback to user
        job_logger.exception("Unexpected error in pipeline")
        _handle_failure(db_session_factory, job_id, error_codes.UNKNOWN_ERROR, str(exc))


def _handle_failure(db_session_factory, job_id: str, code: str, message: str) -> None:
    with db_session_factory() as db:
        job = job_repository.get_job(db, job_id)
        if job is None:
            return
        if (job.retry_count or 0) < (job.max_retries or 0):
            job_repository.requeue_job_for_retry(db, job_id)
            logger.info("Job %s requeued for retry (%s/%s): %s", job_id, job.retry_count, job.max_retries, message)
        else:
            job_repository.mark_job_failed(db, job_id, code, message)


def _check_disk_space(settings: Settings, job_logger: logging.Logger) -> None:
    total, used, free = shutil.disk_usage(str(settings.data_dir_path))
    if free < _MIN_FREE_DISK_BYTES:
        raise JobFailedError(
            error_codes.INSUFFICIENT_STORAGE,
            f"Only {free / (1024**3):.2f} GB free at {settings.data_dir_path}; at least 2 GB is required.",
        )
    job_logger.info("Disk space check passed: %.2f GB free", free / (1024**3))


def _generate_script(settings, topic, content_type, niche, target_duration, research_context, job_logger) -> GeneratedScript:
    try:
        llm = get_llm_provider(settings)
        if not llm.is_available():
            raise JobFailedError(
                error_codes.OLLAMA_UNAVAILABLE,
                error_codes.USER_FACING_MESSAGES[error_codes.OLLAMA_UNAVAILABLE],
            )
        return ScriptService(llm).generate_script(
            topic=topic,
            content_type=content_type,
            niche=niche,
            target_duration_seconds=target_duration,
            research_context=research_context,
        )
    except JobFailedError:
        raise
    except (ScriptGenerationError, ConnectionError) as exc:
        job_logger.error("Script generation failed: %s", exc)
        raise JobFailedError(error_codes.SCRIPT_GENERATION_FAILED, str(exc)) from exc


def _generate_audio(settings, script, workspace, voice, job_logger):
    try:
        from app.providers.factory import get_tts_provider

        tts = get_tts_provider(settings)
        return TTSService(tts).generate_narration(script.full_narration_text(), workspace.audio_path, voice=voice)
    except (TTSGenerationError, RuntimeError, PermanentError) as exc:
        job_logger.error("TTS failed: %s", exc)
        raise JobFailedError(error_codes.TTS_FAILED, str(exc)) from exc


def _transcribe(settings, audio_path, workspace, job_logger):
    try:
        transcription = get_transcription_provider(settings)
        return TranscriptionService(transcription).transcribe(audio_path, workspace.transcript_path)
    except (TranscriptionError, RuntimeError) as exc:
        job_logger.error("Transcription failed: %s", exc)
        raise JobFailedError(error_codes.WHISPER_FAILED, str(exc)) from exc


def _acquire_media(settings, script, workspace, orientation, job_logger):
    try:
        media_provider = get_media_provider(settings)
        return MediaService(media_provider).acquire_assets_for_scenes(script.scenes, workspace.media_dir, orientation)
    except (MediaAcquisitionError, PermanentError) as exc:
        job_logger.error("Media acquisition failed: %s", exc)
        raise JobFailedError(error_codes.MEDIA_PROVIDER_FAILED, str(exc)) from exc


def _render(render_cfg, script, assets, audio_path, workspace, music_path, job_logger):
    try:
        RenderService(render_cfg).render(
            script.scenes,
            assets,
            audio_path,
            workspace.captions_ass_path,
            workspace.root,
            workspace.final_video_path,
            music_path=music_path,
        )
    except RenderError as exc:
        job_logger.error("Render failed: %s", exc)
        raise JobFailedError(error_codes.FFMPEG_FAILED, str(exc)) from exc


def _generate_thumbnail(script, workspace, job_logger):
    try:
        ThumbnailService().generate(workspace.final_video_path, script.title, workspace.thumbnail_path)
    except ThumbnailError as exc:
        job_logger.error("Thumbnail generation failed: %s", exc)
        raise JobFailedError(error_codes.THUMBNAIL_FAILED, str(exc)) from exc


def _generate_metadata(settings, script, content_type, niche, workspace, job_logger):
    try:
        llm = get_llm_provider(settings)
        metadata = MetadataService(llm).generate_metadata(script, content_type, niche)
        workspace.metadata_path.write_text(metadata.model_dump_json(indent=2), encoding="utf-8")
        return metadata
    except MetadataGenerationError as exc:
        job_logger.error("Metadata generation failed: %s", exc)
        raise JobFailedError(error_codes.METADATA_FAILED, str(exc)) from exc


def _upload_to_youtube(settings, workspace, metadata, privacy, job_id, video_id, job_logger):
    from app.database import session_scope

    try:
        with session_scope() as db:
            svc = YouTubeService(settings, db)
            if not svc.is_connected():
                raise JobFailedError(error_codes.YOUTUBE_AUTH_FAILED, error_codes.USER_FACING_MESSAGES[error_codes.YOUTUBE_AUTH_FAILED])
            result = svc.upload_video(
                workspace.final_video_path,
                metadata.title,
                metadata.description,
                metadata.tags,
                metadata.category_id,
                privacy,
                thumbnail_path=workspace.thumbnail_path,
            )
            from app.repositories import video_repository as vrepo

            vrepo.mark_uploaded(db, video_id, result["video_id"], result["url"], privacy)
        job_logger.info("Uploaded to YouTube: %s", result["url"])
    except JobFailedError:
        raise
    except PermanentError as exc:
        raise JobFailedError(error_codes.YOUTUBE_AUTH_FAILED, str(exc)) from exc
    except Exception as exc:
        job_logger.error("YouTube upload failed: %s", exc)
        raise JobFailedError(error_codes.YOUTUBE_UPLOAD_FAILED, str(exc)) from exc
