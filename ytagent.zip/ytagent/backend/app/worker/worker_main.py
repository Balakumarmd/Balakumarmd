"""
Standalone worker process (spec section 8).

Run with:  python run_worker.py   (or run_worker.bat on Windows)

The worker:
  1. Registers itself in the `workers` table and heartbeats periodically.
  2. Polls for QUEUED jobs and atomically claims one at a time (see
     repositories/job_repository.claim_next_job).
  3. Runs the full pipeline for the claimed job.
  4. Repeats until interrupted (Ctrl+C).

This process is intentionally separate from the FastAPI process: video
generation is long-running and must never block an HTTP request thread.
"""
from __future__ import annotations

import platform
import signal
import socket
import sys
import time
import uuid

from app.config import get_settings
from app.database import init_db, session_scope
from app.repositories import job_repository, worker_repository
from app.utils.logging_config import configure_logging
from app.utils.system_info import get_cpu_info, get_disk_info, get_gpu_info, get_memory_info
from app.worker.pipeline import run_job

_RUNNING = True


def _handle_shutdown(signum, frame):  # noqa: ANN001
    global _RUNNING
    _RUNNING = False


def main() -> None:
    settings = get_settings()
    logger = configure_logging(component="worker")
    init_db()

    worker_id = settings.WORKER_ID or str(uuid.uuid4())
    hostname = socket.gethostname()
    logger.info("Worker starting | id=%s | host=%s | platform=%s", worker_id, hostname, platform.platform())
    logger.info("Data directory: %s", settings.data_dir_path)

    signal.signal(signal.SIGINT, _handle_shutdown)
    try:
        signal.signal(signal.SIGTERM, _handle_shutdown)
    except (AttributeError, ValueError):
        pass  # SIGTERM not available on some platforms/threads

    with session_scope() as db:
        worker_repository.upsert_worker_heartbeat(
            db,
            worker_id,
            hostname=hostname,
            status="online",
            cpu_info=get_cpu_info(),
            memory_info=get_memory_info(),
            disk_info=get_disk_info(str(settings.data_dir_path)),
            gpu_info=get_gpu_info(),
        )

    logger.info("Worker online. Polling for jobs every %.1fs...", settings.WORKER_POLL_INTERVAL_SECONDS)

    while _RUNNING:
        try:
            with session_scope() as db:
                job = job_repository.claim_next_job(db, worker_id)
                job_id = job.id if job else None

            if job_id:
                logger.info("Claimed job %s", job_id)
                with session_scope() as db:
                    worker_repository.upsert_worker_heartbeat(db, worker_id, status="busy", current_job_id=job_id)

                run_job(session_scope, job_id, settings)

                with session_scope() as db:
                    worker_repository.upsert_worker_heartbeat(db, worker_id, status="online", current_job_id=None)
            else:
                with session_scope() as db:
                    worker_repository.upsert_worker_heartbeat(db, worker_id, status="online", current_job_id=None)
                time.sleep(settings.WORKER_POLL_INTERVAL_SECONDS)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Worker loop encountered an unexpected error: %s", exc)
            time.sleep(settings.WORKER_POLL_INTERVAL_SECONDS)

    with session_scope() as db:
        worker_repository.upsert_worker_heartbeat(db, worker_id, status="offline", current_job_id=None)
    logger.info("Worker shut down cleanly.")


if __name__ == "__main__":
    main()
