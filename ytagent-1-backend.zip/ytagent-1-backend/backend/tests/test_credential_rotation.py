"""
Tests for persisted API-key exhaustion/rotation (spec: 'if Gemini keys run
out, switch to Groq', applied at the credential layer).
"""
from datetime import datetime, timedelta

from app.repositories.provider_credential_repository import (
    DEFAULT_EXHAUSTION_COOLDOWN,
    ProviderCredentialRepository,
)
from app.utils.secret_crypto import SecretCrypto


def _make_credential(db, provider_name="gemini", secret="test-key-123"):
    crypto = SecretCrypto()
    encrypted = crypto.encrypt(secret)
    return ProviderCredentialRepository.create(
        db,
        category="llm",
        provider_name=provider_name,
        encrypted_value=encrypted,
        display_name="test key",
    )


def test_new_credential_is_active_by_default(db_session, monkeypatch):
    monkeypatch.setenv("YT_AGENT_ENCRYPTION_KEY", SecretCrypto_test_key())
    cred = _make_credential(db_session)
    active = ProviderCredentialRepository.get_active(db_session, category="llm", provider_name="gemini")
    assert any(c.id == cred.id for c in active)


def test_mark_exhausted_removes_from_active_list(db_session, monkeypatch):
    monkeypatch.setenv("YT_AGENT_ENCRYPTION_KEY", SecretCrypto_test_key())
    cred = _make_credential(db_session)
    ProviderCredentialRepository.mark_exhausted(db_session, cred, True, error_message="quota exceeded")
    active = ProviderCredentialRepository.get_active(db_session, category="llm", provider_name="gemini")
    assert all(c.id != cred.id for c in active)
    assert cred.is_exhausted is True
    assert cred.exhausted_until is not None


def test_exhausted_key_recovers_after_cooldown(db_session, monkeypatch):
    monkeypatch.setenv("YT_AGENT_ENCRYPTION_KEY", SecretCrypto_test_key())
    cred = _make_credential(db_session)
    ProviderCredentialRepository.mark_exhausted(db_session, cred, True)
    # Simulate the cooldown having already passed.
    cred.exhausted_until = datetime.utcnow() - timedelta(minutes=1)
    db_session.commit()

    active = ProviderCredentialRepository.get_active(db_session, category="llm", provider_name="gemini")
    assert any(c.id == cred.id for c in active)


def test_clear_exhausted_resets_state(db_session, monkeypatch):
    monkeypatch.setenv("YT_AGENT_ENCRYPTION_KEY", SecretCrypto_test_key())
    cred = _make_credential(db_session)
    ProviderCredentialRepository.mark_exhausted(db_session, cred, True, error_message="boom")
    ProviderCredentialRepository.clear_exhausted(db_session, cred)
    assert cred.is_exhausted is False
    assert cred.exhausted_until is None
    assert cred.last_error is None


def test_multiple_keys_second_key_available_when_first_exhausted(db_session, monkeypatch):
    monkeypatch.setenv("YT_AGENT_ENCRYPTION_KEY", SecretCrypto_test_key())
    cred1 = _make_credential(db_session, secret="key-one")
    cred2 = _make_credential(db_session, secret="key-two")

    ProviderCredentialRepository.mark_exhausted(db_session, cred1, True)

    active = ProviderCredentialRepository.get_active(db_session, category="llm", provider_name="gemini")
    active_ids = {c.id for c in active}
    assert cred2.id in active_ids
    assert cred1.id not in active_ids


def SecretCrypto_test_key():
    """A valid Fernet key, generated once and hardcoded for deterministic
    tests (never used for anything but test fixtures)."""
    from cryptography.fernet import Fernet

    return Fernet.generate_key().decode()
