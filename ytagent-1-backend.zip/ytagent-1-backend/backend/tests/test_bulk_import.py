from datetime import datetime

from app.models import JobStatus
from app.services.bulk_import_service import (
    _coerce_bool,
    _coerce_datetime,
    normalize_row,
    import_rows,
)


def test_normalize_row_maps_flexible_headers():
    raw = {
        "Topic": "5 AI tools students should know",
        "Type": "Short",
        "Niche": "Education",
        "Duration": "45",
        "Music": "auto",
        "Channel": "Main Channel",
        "Privacy": "PUBLIC",
    }
    fields = normalize_row(raw)
    assert fields["topic"] == "5 AI tools students should know"
    assert fields["content_type"] == "short"
    assert fields["niche"] == "Education"
    assert fields["target_duration_seconds"] == 45
    assert fields["channel_label"] == "Main Channel"
    assert fields["upload_privacy"] == "public"


def test_normalize_row_long_form_aliases():
    for alias in ("long", "long_form", "LongForm", "Long-Form".replace("-", "_")):
        fields = normalize_row({"Topic": "x", "Type": alias})
        assert fields["content_type"] == "long_form"


def test_normalize_row_rejects_unknown_llm_provider_gracefully():
    fields = normalize_row({"Topic": "x", "Model": "chatgpt"})
    assert fields["llm_provider"] is None  # unrecognized -> dashboard default, not an error


def test_normalize_row_invalid_privacy_defaults_to_private():
    fields = normalize_row({"Topic": "x", "Privacy": "nonsense"})
    assert fields["upload_privacy"] == "private"


def test_coerce_bool_variants():
    assert _coerce_bool("yes") is True
    assert _coerce_bool("YES") is True
    assert _coerce_bool("1") is True
    assert _coerce_bool("auto") is True
    assert _coerce_bool("no") is False
    assert _coerce_bool("") is True  # default True when omitted
    assert _coerce_bool(None, default=False) is False


def test_coerce_datetime_combined_field():
    result = _coerce_datetime({"scheduled_at": "2026-10-10T18:00:00"})
    assert result == datetime(2026, 10, 10, 18, 0, 0)


def test_coerce_datetime_separate_date_and_time():
    result = _coerce_datetime({"schedule_date": "2026-10-10", "schedule_time": "18:30"})
    assert result == datetime(2026, 10, 10, 18, 30)


def test_coerce_datetime_defaults_time_when_missing():
    result = _coerce_datetime({"schedule_date": "2026-10-10"})
    assert result == datetime(2026, 10, 10, 9, 0)


def test_coerce_datetime_returns_none_when_no_date():
    assert _coerce_datetime({}) is None


def test_import_rows_creates_jobs_and_dedups_unchanged_rows(db_session):
    rows = [{"Topic": "5 AI tools", "Type": "short"}, {"Topic": "How compound interest works", "Type": "long"}]

    first_pass = import_rows(db_session, rows, source="excel", row_key_prefix="test")
    assert first_pass.created_jobs == 2
    assert first_pass.skipped_unchanged == 0

    second_pass = import_rows(db_session, rows, source="excel", row_key_prefix="test")
    assert second_pass.created_jobs == 0
    assert second_pass.skipped_unchanged == 2


def test_import_rows_replaces_unstarted_job_when_row_edited(db_session):
    rows = [{"Topic": "Original topic", "Type": "short"}]
    first_pass = import_rows(db_session, rows, source="excel", row_key_prefix="test2")
    assert first_pass.created_jobs == 1

    edited_rows = [{"Topic": "Edited topic", "Type": "short"}]
    second_pass = import_rows(db_session, edited_rows, source="excel", row_key_prefix="test2")
    assert second_pass.created_jobs == 1

    from app.repositories import job_repository

    jobs = job_repository.list_jobs(db_session)
    topics = {j.topic for j in jobs}
    assert "Edited topic" in topics
    assert "Original topic" not in topics  # replaced, not duplicated


def test_import_rows_leaves_in_progress_job_untouched_on_edit(db_session):
    from app.repositories import job_repository

    rows = [{"Topic": "Original topic", "Type": "short"}]
    first_pass = import_rows(db_session, rows, source="excel", row_key_prefix="test3")
    assert first_pass.created_jobs == 1

    jobs = job_repository.list_jobs(db_session)
    job_repository.update_job_progress(db_session, jobs[0].id, status=JobStatus.RENDERING.value, progress=70)

    edited_rows = [{"Topic": "Edited topic", "Type": "short"}]
    second_pass = import_rows(db_session, edited_rows, source="excel", row_key_prefix="test3")
    assert second_pass.created_jobs == 0
    assert len(second_pass.errors) == 1

    remaining_topics = {j.topic for j in job_repository.list_jobs(db_session)}
    assert "Original topic" in remaining_topics


def test_import_rows_skips_row_with_missing_topic(db_session):
    rows = [{"Topic": "", "Type": "short"}]
    result = import_rows(db_session, rows, source="excel", row_key_prefix="test4")
    assert result.created_jobs == 0
    assert len(result.errors) == 1
