"""
Shared pytest fixtures. Tests use a temporary DATA_DIR / SQLite file so
they never touch the real user data directory, and never require network
access, Ollama, Kokoro, or any other external dependency to run.
"""
import os
import tempfile
from pathlib import Path

import pytest


@pytest.fixture()
def temp_data_dir(monkeypatch):
    with tempfile.TemporaryDirectory() as tmp:
        monkeypatch.setenv("DATA_DIR", tmp)
        # Ensure config + database caches don't leak between tests.
        from app.config import get_settings
        get_settings.cache_clear()
        yield Path(tmp)
        get_settings.cache_clear()


@pytest.fixture()
def db_session(temp_data_dir):
    from app.database import SessionLocal, init_db, engine
    from app import models  # noqa: F401

    init_db()
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()
