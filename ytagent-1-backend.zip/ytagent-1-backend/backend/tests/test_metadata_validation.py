import pytest
from pydantic import ValidationError

from app.schemas.schemas import YouTubeMetadata


def test_valid_metadata():
    meta = YouTubeMetadata(
        title="5 AI Tools Students Should Know",
        description="A quick rundown of five useful AI tools for students.",
        tags=["ai", "students", "productivity"],
        category_id="27",
        hashtags=["#ai", "#studytips"],
    )
    assert meta.category_id == "27"


def test_metadata_title_too_long_rejected():
    with pytest.raises(ValidationError):
        YouTubeMetadata(title="x" * 200, description="ok", tags=[], category_id="27")


def test_metadata_tags_truncated_to_15():
    meta = YouTubeMetadata(title="T", description="D", tags=[f"tag{i}" for i in range(30)], category_id="27")
    assert len(meta.tags) == 15
