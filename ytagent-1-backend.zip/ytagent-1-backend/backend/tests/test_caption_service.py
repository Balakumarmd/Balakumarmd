from app.schemas.schemas import TranscriptWord
from app.services.caption_service import CaptionService, CaptionStyle, build_ass_content, group_words


def _words():
    return [
        TranscriptWord(word="Students", start=0.0, end=0.4),
        TranscriptWord(word="should", start=0.4, end=0.7),
        TranscriptWord(word="know", start=0.7, end=1.0),
        TranscriptWord(word="about", start=1.0, end=1.3),
        TranscriptWord(word="ChatGPT", start=1.3, end=1.8),
    ]


def test_group_words_respects_max_words_per_group():
    style = CaptionStyle(max_words_per_group=2, max_chars_per_group=999)
    groups = group_words(_words(), style)
    assert all(len(g) <= 2 for g in groups)
    assert sum(len(g) for g in groups) == len(_words())


def test_build_ass_content_contains_karaoke_tags_and_all_words():
    content = build_ass_content(_words(), CaptionStyle(), 1080, 1920)
    assert "[Events]" in content
    assert "\\k" in content
    for w in _words():
        assert w.word in content


def test_generate_caption_file_writes_nonempty_file(tmp_path):
    out_path = tmp_path / "captions.ass"
    CaptionService().generate_caption_file(_words(), out_path, 1080, 1920)
    assert out_path.exists()
    assert out_path.stat().st_size > 0
