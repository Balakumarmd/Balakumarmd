from pathlib import Path

from app.schemas.schemas import MediaAsset


def test_media_asset_schema_requires_fields():
    asset = MediaAsset(
        scene_number=1,
        source="pexels",
        asset_type="video",
        source_id="123",
        source_url="https://example.com/video.mp4",
        local_path="/tmp/video.mp4",
        width=1080,
        height=1920,
        duration=6.0,
    )
    assert asset.scene_number == 1
    assert asset.asset_type == "video"


def test_media_service_validation_rejects_empty_file(tmp_path):
    from app.services.media_service import MediaService

    class DummyProvider:
        pass

    svc = MediaService(DummyProvider())
    empty_file = tmp_path / "empty.mp4"
    empty_file.write_bytes(b"")
    assert svc._validate_file(empty_file) is False


def test_media_service_validation_rejects_missing_file(tmp_path):
    from app.services.media_service import MediaService

    class DummyProvider:
        pass

    svc = MediaService(DummyProvider())
    assert svc._validate_file(tmp_path / "does_not_exist.mp4") is False
