from app.schemas.schemas import Scene
from app.services.render_service import rescale_scene_durations


def test_rescale_scene_durations_matches_audio_length():
    scenes = [
        Scene(scene_number=1, narration="a", visual_query="q", duration=5.0),
        Scene(scene_number=2, narration="b", visual_query="q", duration=5.0),
    ]
    rescaled = rescale_scene_durations(scenes, actual_audio_duration=20.0)
    assert abs(sum(s.duration for s in rescaled) - 20.0) < 0.01
    # proportions preserved
    assert abs(rescaled[0].duration - rescaled[1].duration) < 0.01
