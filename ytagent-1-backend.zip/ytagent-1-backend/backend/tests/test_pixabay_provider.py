from app.providers.media.pixabay_provider import PixabayProvider


def _variants():
    return {
        "large": {"url": "https://example.com/large.mp4", "width": 1920, "height": 1080},
        "medium": {"url": "https://example.com/medium.mp4", "width": 1280, "height": 720},
        "small": {"url": "https://example.com/small.mp4", "width": 640, "height": 360},
        "tiny": {"url": "https://example.com/tiny.mp4", "width": 320, "height": 180},
    }


def test_choose_video_variant_prefers_landscape_for_landscape_orientation():
    chosen = PixabayProvider._choose_video_variant(_variants(), "landscape")
    assert chosen is not None
    assert chosen["width"] >= chosen["height"]
    # Should pick the smallest variant that still clears the 720px floor.
    assert max(chosen["width"], chosen["height"]) >= 720


def test_choose_video_variant_falls_back_when_no_matching_orientation():
    # None of these variants are portrait; requesting portrait should still
    # return *something* usable rather than nothing.
    chosen = PixabayProvider._choose_video_variant(_variants(), "portrait")
    assert chosen is not None


def test_choose_video_variant_handles_empty_variants():
    assert PixabayProvider._choose_video_variant({}, "portrait") is None
