"""
Real end-to-end pipeline integration test (spec section 43).

This test is SKIPPED by default because it requires genuinely running
local infrastructure: Ollama serving qwen3:8b, FFmpeg on PATH, Kokoro TTS
and faster-whisper installed, and a valid PEXELS_API_KEY. It deliberately
does NOT mock any of these -- that would defeat the purpose of an
end-to-end test. Run it explicitly once your local environment is set up:

    set RUN_E2E_TEST=1
    pytest tests/test_e2e_pipeline.py -v -s

On success it asserts that script.json, audio.wav, transcript.json,
downloaded media, captions, thumbnail.png, metadata.json and final.mp4 all
exist and that final.mp4 is a valid, playable video file with non-zero
duration -- matching the "Final Success Criteria" in the spec.
"""
import os

import pytest


RUN_E2E = os.environ.get("RUN_E2E_TEST") == "1"


@pytest.mark.skipif(not RUN_E2E, reason="Set RUN_E2E_TEST=1 to run the real end-to-end pipeline test")
def test_full_pipeline_produces_playable_video(temp_data_dir):
    from app.config import get_settings
    from app.database import init_db, session_scope
    from app.models import JobStatus
    from app.repositories import job_repository
    from app.worker.pipeline import run_job
    from app.utils.ffmpeg_utils import get_media_duration

    init_db()
    settings = get_settings()

    with session_scope() as db:
        job = job_repository.create_job(
            db,
            topic="5 AI tools students should know",
            content_type="short",
            target_duration_seconds=45,
            status=JobStatus.QUEUED.value,
        )
        job_id = job.id
        job_repository.update_job_progress(db, job_id, status=JobStatus.CLAIMED.value)

    run_job(session_scope, job_id, settings)

    with session_scope() as db:
        job = job_repository.get_job(db, job_id)

    assert job.status == JobStatus.COMPLETED.value, f"Job failed: {job.error_code} - {job.error_message}"

    from app.services.workspace_service import JobWorkspace

    ws = JobWorkspace(settings, job_id)
    for path in [
        ws.script_path,
        ws.audio_path,
        ws.transcript_path,
        ws.captions_ass_path,
        ws.thumbnail_path,
        ws.metadata_path,
        ws.final_video_path,
    ]:
        assert path.exists(), f"Expected pipeline output missing: {path}"
        assert path.stat().st_size > 0, f"Pipeline output is empty: {path}"

    duration = get_media_duration(ws.final_video_path)
    assert duration is not None and duration > 5, "Final video has no valid duration"
