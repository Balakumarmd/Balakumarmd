from app.models import JobStatus
from app.repositories import job_repository


def test_create_and_retrieve_job(db_session):
    job = job_repository.create_job(
        db_session,
        topic="5 AI tools students should know",
        content_type="short",
        language="en",
        target_duration_seconds=45,
        status=JobStatus.QUEUED.value,
        progress=0,
    )
    assert job.id is not None
    assert job.status == JobStatus.QUEUED.value

    fetched = job_repository.get_job(db_session, job.id)
    assert fetched is not None
    assert fetched.topic == "5 AI tools students should know"


def test_multiple_jobs_listed_newest_first(db_session):
    job_repository.create_job(db_session, topic="Topic A", content_type="short", target_duration_seconds=30)
    job_repository.create_job(db_session, topic="Topic B", content_type="long_form", target_duration_seconds=180)

    jobs = job_repository.list_jobs(db_session)
    assert len(jobs) == 2
    assert jobs[0].created_at >= jobs[1].created_at


def test_job_status_update(db_session):
    job = job_repository.create_job(db_session, topic="Test", content_type="short", target_duration_seconds=30)
    updated = job_repository.update_job_progress(db_session, job.id, status=JobStatus.SCRIPTING.value, progress=15, current_step="Generating script")
    assert updated.status == JobStatus.SCRIPTING.value
    assert updated.progress == 15
    assert updated.current_step == "Generating script"


def test_mark_job_failed_and_completed(db_session):
    job = job_repository.create_job(db_session, topic="Test", content_type="short", target_duration_seconds=30)
    failed = job_repository.mark_job_failed(db_session, job.id, "FFMPEG_FAILED", "ffmpeg not found")
    assert failed.status == JobStatus.FAILED.value
    assert failed.error_code == "FFMPEG_FAILED"

    job2 = job_repository.create_job(db_session, topic="Test2", content_type="short", target_duration_seconds=30)
    completed = job_repository.mark_job_completed(db_session, job2.id, "/tmp/out.mp4")
    assert completed.status == JobStatus.COMPLETED.value
    assert completed.progress == 100
    assert completed.output_video_path == "/tmp/out.mp4"


def test_cancel_job_is_terminal(db_session):
    job = job_repository.create_job(db_session, topic="Test", content_type="short", target_duration_seconds=30)
    job_repository.mark_job_completed(db_session, job.id, "/tmp/out.mp4")
    # Cancelling an already-completed job should be a no-op, not overwrite completion.
    result = job_repository.cancel_job(db_session, job.id)
    assert result.status == JobStatus.COMPLETED.value


def test_retry_requeues_failed_job(db_session):
    job = job_repository.create_job(db_session, topic="Test", content_type="short", target_duration_seconds=30)
    job_repository.mark_job_failed(db_session, job.id, "TTS_FAILED", "boom")
    retried = job_repository.retry_job(db_session, job.id)
    assert retried.status == JobStatus.QUEUED.value
    assert retried.error_code is None
