from fastapi.testclient import TestClient


def test_health_endpoint_ok(temp_data_dir):
    from app.main import app

    client = TestClient(app)
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
