"""
Verifies the atomic job-claiming guarantee: two 'workers' racing to claim
jobs must never both end up claiming the same job.
"""
import threading

from app.database import SessionLocal
from app.models import JobStatus
from app.repositories import job_repository


def test_atomic_claim_no_double_claim(db_session):
    jobs = [
        job_repository.create_job(db_session, topic=f"Topic {i}", content_type="short", target_duration_seconds=30)
        for i in range(10)
    ]
    job_ids = {j.id for j in jobs}

    claimed_by: dict[str, list[str]] = {jid: [] for jid in job_ids}
    lock = threading.Lock()

    def worker(worker_id: str):
        session = SessionLocal()
        try:
            while True:
                job = job_repository.claim_next_job(session, worker_id)
                if job is None:
                    break
                with lock:
                    claimed_by[job.id].append(worker_id)
        finally:
            session.close()

    threads = [threading.Thread(target=worker, args=(f"worker-{i}",)) for i in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # Every job must have been claimed by exactly one worker, exactly once.
    for job_id, claimers in claimed_by.items():
        assert len(claimers) == 1, f"Job {job_id} was claimed {len(claimers)} times: {claimers}"

    session = SessionLocal()
    try:
        for job_id in job_ids:
            job = job_repository.get_job(session, job_id)
            assert job.status == JobStatus.CLAIMED.value
    finally:
        session.close()


def test_claim_returns_none_when_no_jobs_queued(db_session):
    result = job_repository.claim_next_job(db_session, "worker-x")
    assert result is None
