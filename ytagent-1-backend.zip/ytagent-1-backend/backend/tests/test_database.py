def test_database_initializes_and_creates_tables(db_session):
    from sqlalchemy import inspect
    from app.database import engine

    inspector = inspect(engine)
    tables = set(inspector.get_table_names())
    expected = {"users", "projects", "jobs", "workers", "videos", "channels", "settings", "provider_configs"}
    assert expected.issubset(tables)
