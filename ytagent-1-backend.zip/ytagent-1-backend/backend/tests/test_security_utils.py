import pytest

from app.utils.security import safe_filename, safe_join


def test_safe_filename_strips_unsafe_chars():
    assert safe_filename("my topic! / <script>") == "my_topic_script"


def test_safe_join_prevents_traversal(tmp_path):
    with pytest.raises(ValueError):
        safe_join(tmp_path, "..", "..", "etc", "passwd")


def test_safe_join_allows_valid_subpath(tmp_path):
    result = safe_join(tmp_path, "jobs", "abc123")
    assert str(result).startswith(str(tmp_path.resolve()))
