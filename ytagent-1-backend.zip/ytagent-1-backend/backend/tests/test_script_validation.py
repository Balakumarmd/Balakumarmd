import pytest
from pydantic import ValidationError

from app.schemas.schemas import GeneratedScript
from app.utils.json_repair import safe_parse_json


def test_valid_script_parses():
    script = GeneratedScript(
        title="5 AI Tools",
        hook="Did you know AI can do your homework research in seconds?",
        scenes=[
            {"scene_number": 1, "narration": "Tool one is ChatGPT.", "visual_query": "student using laptop", "duration": 5.0},
            {"scene_number": 2, "narration": "Tool two is Notion AI.", "visual_query": "notebook and pen on desk", "duration": 5.0},
        ],
        outro="That's five tools to try today.",
        cta="Subscribe for more!",
        estimated_duration=10.0,
    )
    assert len(script.scenes) == 2
    assert "ChatGPT" in script.full_narration_text()


def test_script_requires_at_least_one_scene():
    with pytest.raises(ValidationError):
        GeneratedScript(title="x", hook="x", scenes=[], outro="x", estimated_duration=10.0)


def test_json_repair_extracts_from_markdown_fence():
    raw = 'Sure! Here is the script:\n```json\n{"title": "T", "hook": "H", "scenes": [{"scene_number": 1, "narration": "N", "visual_query": "V", "duration": 5}], "outro": "O", "estimated_duration": 5}\n```'
    data = safe_parse_json(raw)
    assert data["title"] == "T"
    script = GeneratedScript.model_validate(data)
    assert script.scenes[0].narration == "N"


def test_json_repair_handles_trailing_commas():
    raw = '{"title": "T", "hook": "H", "scenes": [{"scene_number": 1, "narration": "N", "visual_query": "V", "duration": 5,},], "outro": "O", "estimated_duration": 5,}'
    data = safe_parse_json(raw)
    assert data["title"] == "T"


def test_json_repair_raises_on_garbage():
    with pytest.raises(ValueError):
        safe_parse_json("this is not json at all, sorry!")
