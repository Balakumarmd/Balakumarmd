from datetime import datetime, timedelta, timezone

from app.providers.youtube.youtube_data_api_provider import compute_upload_status


def test_no_publish_at_uses_requested_privacy_only():
    status = compute_upload_status("public", None)
    assert status == {"privacyStatus": "public", "selfDeclaredMadeForKids": False}
    assert "publishAt" not in status


def test_future_publish_at_forces_private_and_sets_publish_at():
    now = datetime(2026, 10, 5, 12, 0, 0, tzinfo=timezone.utc)
    future = now + timedelta(days=2)
    status = compute_upload_status("public", future, now=now)
    assert status["privacyStatus"] == "private"
    assert status["publishAt"] == "2026-10-07T12:00:00Z"


def test_past_publish_at_falls_back_to_requested_privacy():
    now = datetime(2026, 10, 5, 12, 0, 0, tzinfo=timezone.utc)
    past = now - timedelta(days=1)
    status = compute_upload_status("unlisted", past, now=now)
    assert status["privacyStatus"] == "unlisted"
    assert "publishAt" not in status


def test_naive_datetime_is_treated_as_utc():
    now = datetime(2026, 10, 5, 12, 0, 0, tzinfo=timezone.utc)
    naive_future = datetime(2026, 10, 10, 9, 0, 0)  # no tzinfo
    status = compute_upload_status("public", naive_future, now=now)
    assert status["privacyStatus"] == "private"
    assert status["publishAt"] == "2026-10-10T09:00:00Z"


def test_exactly_now_is_not_scheduled():
    now = datetime(2026, 10, 5, 12, 0, 0, tzinfo=timezone.utc)
    status = compute_upload_status("private", now, now=now)
    # Not strictly greater than "now" -> treated as already due, not scheduled.
    assert "publishAt" not in status
