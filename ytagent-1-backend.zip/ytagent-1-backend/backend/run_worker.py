"""Entrypoint script: starts the standalone local worker process.

Usage:
    python run_worker.py
"""
from app.worker.worker_main import main

if __name__ == "__main__":
    main()
