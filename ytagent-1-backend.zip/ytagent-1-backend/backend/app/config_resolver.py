"""
Merges dashboard-stored settings (the `settings` key/value table) on top of
the `.env`-derived Settings object, so the dashboard becomes the source of
truth for day-to-day configuration while `.env` remains only a first-run
bootstrap (and the one place that MUST stay file-based: DATABASE_URL/
DATA_DIR before the database even exists).

Only non-secret, safely-overridable fields are eligible here. Actual API
keys (Gemini/Groq/Pexels/Pixabay/YouTube client secret/Sheets API key) are
NOT handled here -- those go through ProviderCredentialRepository
(encrypted at rest) and are read directly by each provider, not merged
into this Settings object.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from sqlalchemy.orm import Session

from app.config import Settings, get_settings
from app.repositories.settings_repository import get_all_settings

if TYPE_CHECKING:
    pass

logger = logging.getLogger("ytagent")

# Dashboard setting key -> Settings field name, and the type to coerce to.
_OVERRIDABLE_FIELDS: dict[str, tuple[str, type]] = {
    "data_dir": ("DATA_DIR", str),
    "ffmpeg_path": ("FFMPEG_PATH", str),
    "ffprobe_path": ("FFPROBE_PATH", str),
    "tts_provider": ("TTS_PROVIDER", str),
    "kokoro_voice": ("KOKORO_VOICE", str),
    "kokoro_speed": ("KOKORO_SPEED", float),
    "whisper_model": ("WHISPER_MODEL", str),
    "whisper_device": ("WHISPER_DEVICE", str),
    "whisper_compute_type": ("WHISPER_COMPUTE_TYPE", str),
    "media_provider": ("MEDIA_PROVIDER", str),
    "youtube_oauth_redirect_uri": ("YOUTUBE_OAUTH_REDIRECT_URI", str),
    "youtube_client_id": ("YOUTUBE_CLIENT_ID", str),
    "youtube_default_privacy": ("YOUTUBE_DEFAULT_PRIVACY", str),
    "default_language": ("DEFAULT_LANGUAGE", str),
    "worker_poll_interval_seconds": ("WORKER_POLL_INTERVAL_SECONDS", float),
    "worker_max_retries": ("WORKER_MAX_RETRIES", int),
    "llm_provider": ("LLM_PROVIDER", str),
    "ollama_base_url": ("OLLAMA_BASE_URL", str),
    "ollama_model": ("OLLAMA_MODEL", str),
    "gemini_model": ("gemini_model", str),
    "groq_model": ("groq_model", str),
}


def get_effective_settings(db: Session) -> Settings:
    """
    Returns a Settings instance with any dashboard-stored overrides
    applied on top of the .env-derived defaults. Safe to call often --
    it's a cheap in-memory merge, not a config reload from disk.
    """
    base = get_settings()
    dashboard_values = get_all_settings(db)
    if not dashboard_values:
        return base

    updates: dict = {}
    for setting_key, (field_name, field_type) in _OVERRIDABLE_FIELDS.items():
        raw_value = dashboard_values.get(setting_key)
        if raw_value is None or raw_value == "":
            continue
        try:
            updates[field_name] = field_type(raw_value)
        except (ValueError, TypeError):
            logger.warning("Ignoring invalid dashboard setting %s=%r", setting_key, raw_value)

    # YOUTUBE_CLIENT_SECRET is an actual secret, so unlike the plain fields
    # above it is stored encrypted via ProviderCredentialRepository instead
    # of the plain settings table, and merged in here the same way.
    try:
        from app.repositories.provider_credential_repository import ProviderCredentialRepository
        from app.utils.secret_crypto import SecretCrypto

        creds = ProviderCredentialRepository.get_active(db, category="youtube", provider_name="oauth_client_secret")
        if creds:
            updates["YOUTUBE_CLIENT_SECRET"] = SecretCrypto().decrypt(creds[0].encrypted_value)
    except Exception as exc:
        logger.warning("Could not load YouTube client secret from dashboard: %s", exc)

    if not updates:
        return base
    return base.model_copy(update=updates)
