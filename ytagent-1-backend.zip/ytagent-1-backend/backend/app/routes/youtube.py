from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.repositories import video_repository
from app.schemas.schemas import ChannelResponse
from app.services.youtube_service import YouTubeService
from app.utils.retry import PermanentError

router = APIRouter(prefix="/api/youtube", tags=["youtube"])


@router.put("/oauth-app-credentials")
def set_oauth_app_credentials(client_id: str, client_secret: str, db: Session = Depends(get_db)):
    """
    Dashboard equivalent of editing YOUTUBE_CLIENT_ID/YOUTUBE_CLIENT_SECRET
    in .env. client_id is stored as a plain setting (it's sent to Google's
    consent screen URL anyway, so it isn't really secret); client_secret is
    encrypted via the same credential store used for LLM/media API keys.
    """
    from app.repositories.provider_credential_repository import ProviderCredentialRepository
    from app.repositories.settings_repository import set_settings
    from app.utils.secret_crypto import SecretCrypto

    set_settings(db, {"youtube_client_id": client_id})

    crypto = SecretCrypto()
    encrypted = crypto.encrypt(client_secret)
    existing = ProviderCredentialRepository.list_by_provider(db, category="youtube", provider_name="oauth_client_secret")
    if existing:
        existing[0].encrypted_value = encrypted
        existing[0].is_active = True
        db.commit()
    else:
        ProviderCredentialRepository.create(
            db,
            category="youtube",
            provider_name="oauth_client_secret",
            encrypted_value=encrypted,
            display_name="YouTube OAuth client secret",
        )
        db.commit()

    return {"saved": True}


@router.get("/oauth-app-credentials/status")
def oauth_app_credentials_status(db: Session = Depends(get_db)):
    from app.config_resolver import get_effective_settings

    settings = get_effective_settings(db)
    return {
        "client_id_configured": bool(settings.YOUTUBE_CLIENT_ID),
        "client_secret_configured": bool(settings.YOUTUBE_CLIENT_SECRET),
    }


@router.post("/connect")
def connect(db: Session = Depends(get_db)):
    """
    Starts an OAuth connection. Can be called again to connect ADDITIONAL
    channels -- each completed connection creates a new Channel row rather
    than overwriting a previous one.
    """
    from app.config_resolver import get_effective_settings
    settings = get_effective_settings(db)
    try:
        svc = YouTubeService(settings, db)
        url = svc.get_authorization_url()
        return {"authorization_url": url}
    except PermanentError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/oauth2callback")
def oauth2callback(code: str, db: Session = Depends(get_db)):
    from app.config_resolver import get_effective_settings
    settings = get_effective_settings(db)
    try:
        svc = YouTubeService(settings, db)
        channel = svc.handle_oauth_callback(code)
    except Exception as exc:
        return HTMLResponse(f"<h2>YouTube connection failed</h2><p>{exc}</p>", status_code=400)
    return HTMLResponse(
        f"<h2>Connected: {channel.label or channel.channel_title or 'YouTube channel'}</h2>"
        "<p>You can close this tab and return to the dashboard. "
        "To connect another channel, go back to the YouTube page and click Connect again "
        "(sign in with the other Google account when prompted).</p>"
    )


@router.get("/status")
def status(channel_id: str | None = None, db: Session = Depends(get_db)):
    from app.config_resolver import get_effective_settings
    settings = get_effective_settings(db)
    svc = YouTubeService(settings, db)
    return {"connected": svc.is_connected(channel_id), "channel_count": len(svc.list_channels())}


@router.get("/channels", response_model=list[ChannelResponse])
def list_channels(db: Session = Depends(get_db)):
    from app.config_resolver import get_effective_settings
    settings = get_effective_settings(db)
    svc = YouTubeService(settings, db)
    return svc.list_channels()


@router.post("/channels/{channel_id}/set-default", response_model=ChannelResponse)
def set_default_channel(channel_id: str, db: Session = Depends(get_db)):
    from app.config_resolver import get_effective_settings
    settings = get_effective_settings(db)
    svc = YouTubeService(settings, db)
    try:
        return svc.set_default_channel(channel_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.put("/channels/{channel_id}/label")
def rename_channel(channel_id: str, label: str, db: Session = Depends(get_db)):
    from app.config_resolver import get_effective_settings
    settings = get_effective_settings(db)
    svc = YouTubeService(settings, db)
    try:
        return svc.rename_channel(channel_id, label)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.delete("/channels/{channel_id}")
def disconnect_channel(channel_id: str, db: Session = Depends(get_db)):
    from app.config_resolver import get_effective_settings
    settings = get_effective_settings(db)
    svc = YouTubeService(settings, db)
    svc.disconnect_channel(channel_id)
    return {"disconnected": channel_id}


@router.post("/upload/{video_id}")
def upload(
    video_id: str,
    channel_id: str | None = None,
    db: Session = Depends(get_db),
):
    from app.config_resolver import get_effective_settings

    settings = get_effective_settings(db)
    video = video_repository.get_video(db, video_id)
    if video is None or not video.file_path:
        raise HTTPException(status_code=404, detail="Video not found")

    svc = YouTubeService(settings, db)
    if not svc.is_connected(channel_id):
        raise HTTPException(status_code=400, detail="No YouTube channel connected. Use /api/youtube/connect first.")

    try:
        result = svc.upload_video(
            Path(video.file_path),
            video.title or "Untitled video",
            video.description or "",
            video.tags or [],
            video.category or "27",
            "private",
            thumbnail_path=Path(video.thumbnail_path) if video.thumbnail_path else None,
            channel_id=channel_id,
        )
    except PermanentError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Upload failed: {exc}")

    video_repository.mark_uploaded(db, video_id, result["video_id"], result["url"], "private")
    return result
