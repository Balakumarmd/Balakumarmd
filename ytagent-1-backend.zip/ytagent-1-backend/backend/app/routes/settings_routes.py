from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.repositories import settings_repository
from app.schemas.schemas import SettingsUpdateRequest

router = APIRouter(prefix="/api/settings", tags=["settings"])


@router.get("")
def get_settings_values(db: Session = Depends(get_db)):
    return settings_repository.get_all_settings(db)


@router.put("")
def update_settings_values(payload: SettingsUpdateRequest, db: Session = Depends(get_db)):
    return settings_repository.set_settings(db, payload.values)
