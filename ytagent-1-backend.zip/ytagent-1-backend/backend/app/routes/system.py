from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.repositories import worker_repository
from app.services.system_status_service import full_system_status

router = APIRouter(prefix="/api/system", tags=["system"])


@router.get("/status")
def system_status(db: Session = Depends(get_db)):
    from app.config_resolver import get_effective_settings

    settings = get_effective_settings(db)
    return full_system_status(settings, db)


@router.get("/workers")
def list_workers(db: Session = Depends(get_db)):
    workers = worker_repository.list_workers(db)
    return [
        {
            "id": w.id,
            "hostname": w.hostname,
            "status": w.status,
            "current_job_id": w.current_job_id,
            "last_heartbeat": w.last_heartbeat,
            "cpu_info": w.cpu_info,
            "memory_info": w.memory_info,
            "disk_info": w.disk_info,
            "gpu_info": w.gpu_info,
        }
        for w in workers
    ]
