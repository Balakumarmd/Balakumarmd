from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.database import get_db
from app.repositories.provider_credential_repository import ProviderCredentialRepository
from app.repositories.settings_repository import set_settings
from app.schemas.schemas import BulkImportResult
from app.services.sheet_sync_service import get_sheet_sync_config
from app.utils.secret_crypto import SecretCrypto

router = APIRouter(prefix="/api/sheet-sync", tags=["sheet-sync"])


class SheetSyncUpdateRequest(BaseModel):
    sheet_id: Optional[str] = None
    sheet_range: Optional[str] = None
    poll_interval_seconds: Optional[int] = None
    enabled: Optional[bool] = None
    api_key: Optional[str] = None  # only sent when the user is setting/changing it


@router.get("/config")
def get_config(db: Session = Depends(get_db)):
    config = get_sheet_sync_config(db)
    config["api_key_configured"] = bool(config.pop("api_key"))
    return config


@router.put("/config")
def update_config(payload: SheetSyncUpdateRequest, db: Session = Depends(get_db)):
    values = {}
    if payload.sheet_id is not None:
        values["sheet_sync_sheet_id"] = payload.sheet_id
    if payload.sheet_range is not None:
        values["sheet_sync_range"] = payload.sheet_range
    if payload.poll_interval_seconds is not None:
        values["sheet_sync_poll_interval_seconds"] = str(payload.poll_interval_seconds)
    if payload.enabled is not None:
        values["sheet_sync_enabled"] = "true" if payload.enabled else "false"
    if values:
        set_settings(db, values)

    if payload.api_key:
        crypto = SecretCrypto()
        encrypted = crypto.encrypt(payload.api_key)
        existing = ProviderCredentialRepository.list_by_provider(db, category="sheets", provider_name="google_api_key")
        if existing:
            existing[0].encrypted_value = encrypted
            existing[0].is_active = True
            db.commit()
        else:
            ProviderCredentialRepository.create(
                db,
                category="sheets",
                provider_name="google_api_key",
                encrypted_value=encrypted,
                display_name="Google Sheets API key",
            )
            db.commit()

    config = get_sheet_sync_config(db)
    config["api_key_configured"] = bool(config.pop("api_key"))
    return config


@router.post("/run-now", response_model=BulkImportResult)
def run_now(db: Session = Depends(get_db)):
    from app.services.sheet_sync_service import run_sync_once

    config = get_sheet_sync_config(db)
    if not config["sheet_id"] or not config["api_key"]:
        raise HTTPException(status_code=400, detail="Set a Sheet ID and API key first.")

    result = run_sync_once(db, force=True)
    return result
