from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.repositories import video_repository
from app.schemas.schemas import VideoResponse

router = APIRouter(prefix="/api/videos", tags=["videos"])


@router.get("", response_model=list[VideoResponse])
def list_videos(limit: int = 100, db: Session = Depends(get_db)):
    return video_repository.list_videos(db, limit=limit)


@router.get("/{video_id}", response_model=VideoResponse)
def get_video(video_id: str, db: Session = Depends(get_db)):
    video = video_repository.get_video(db, video_id)
    if video is None:
        raise HTTPException(status_code=404, detail="Video not found")
    return video


@router.get("/{video_id}/file")
def download_video_file(video_id: str, db: Session = Depends(get_db)):
    video = video_repository.get_video(db, video_id)
    if video is None or not video.file_path:
        raise HTTPException(status_code=404, detail="Video file not found")
    path = Path(video.file_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail="Video file missing on disk")
    return FileResponse(str(path), media_type="video/mp4", filename=path.name)


@router.get("/{video_id}/thumbnail")
def download_thumbnail_file(video_id: str, db: Session = Depends(get_db)):
    video = video_repository.get_video(db, video_id)
    if video is None or not video.thumbnail_path:
        raise HTTPException(status_code=404, detail="Thumbnail not found")
    path = Path(video.thumbnail_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail="Thumbnail file missing on disk")
    return FileResponse(str(path), media_type="image/png", filename=path.name)
