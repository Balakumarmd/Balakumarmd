"""
Real MediaProvider backed by the Pexels API (videos + photo fallback),
with multi-key rotation and persisted exhaustion tracking -- the same
pattern used for the Gemini/Groq LLM providers, applied here because
Pexels enforces per-key rate limits too.

Keys are preferably stored in the dashboard (Settings -> API Keys ->
Pexels), falling back to PEXELS_API_KEY / PEXELS_API_KEYS (comma
separated) in .env if nothing is configured in the DB yet.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

import httpx
from sqlalchemy.orm import Session

from app.config import Settings
from app.providers.base import MediaProvider, MediaSearchResult
from app.utils.retry import PermanentError, retry_with_backoff

logger = logging.getLogger("ytagent")

_VIDEO_SEARCH_URL = "https://api.pexels.com/videos/search"
_PHOTO_SEARCH_URL = "https://api.pexels.com/v1/search"


class PexelsProvider(MediaProvider):
    def __init__(self, settings: Settings, db: Optional[Session] = None):
        self._db = db
        self._keys, self._credential_rows = self._load_keys(settings, db)
        if not self._keys:
            raise PermanentError(
                "No Pexels API key is configured. Add one in the dashboard "
                "(Settings -> API Keys -> Pexels) or set PEXELS_API_KEY in .env. "
                "Get a free key at https://www.pexels.com/api/"
            )
        self._exhausted: set[int] = set()

    @staticmethod
    def _load_keys(settings: Settings, db: Optional[Session]):
        keys: List[str] = []
        rows: List = []
        if db is not None:
            try:
                from app.repositories.provider_credential_repository import ProviderCredentialRepository
                from app.utils.secret_crypto import SecretCrypto

                credentials = ProviderCredentialRepository.get_active(db, category="media", provider_name="pexels")
                if credentials:
                    crypto = SecretCrypto()
                    for cred in credentials:
                        try:
                            key = crypto.decrypt(cred.encrypted_value).strip()
                            if key and key not in keys:
                                keys.append(key)
                                rows.append(cred)
                        except Exception as exc:
                            logger.error("Failed to decrypt Pexels credential %s: %s", cred.id, exc)
            except Exception as exc:
                logger.warning("Could not load Pexels credentials from DB: %s", exc)

        if not keys:
            if getattr(settings, "PEXELS_API_KEYS", None):
                for key in settings.PEXELS_API_KEYS.split(","):
                    key = key.strip()
                    if key and key not in keys:
                        keys.append(key)
            if settings.PEXELS_API_KEY and settings.PEXELS_API_KEY.strip() not in keys:
                keys.append(settings.PEXELS_API_KEY.strip())
            rows = [None] * len(keys)

        return keys, rows

    def _mark_exhausted(self, index: int, error: Optional[Exception] = None) -> None:
        self._exhausted.add(index)
        credential = self._credential_rows[index]
        if credential is not None and self._db is not None:
            try:
                from app.repositories.provider_credential_repository import ProviderCredentialRepository

                ProviderCredentialRepository.mark_exhausted(
                    self._db, credential, True, error_message=str(error) if error else None
                )
            except Exception as exc:
                logger.error("Failed to persist Pexels key exhaustion: %s", exc)

    def _available_indexes(self) -> List[int]:
        return [i for i in range(len(self._keys)) if i not in self._exhausted]

    def _client_for(self, index: int) -> httpx.Client:
        return httpx.Client(headers={"Authorization": self._keys[index]}, timeout=30)

    def is_available(self) -> bool:
        for i in self._available_indexes():
            try:
                resp = self._client_for(i).get(_VIDEO_SEARCH_URL, params={"query": "nature", "per_page": 1})
                if resp.status_code == 200:
                    return True
            except Exception as exc:
                logger.warning("Pexels availability check failed on key %d: %s", i + 1, exc)
        return False

    def search(self, query: str, *, orientation: str = "portrait", per_page: int = 5) -> List[MediaSearchResult]:
        last_error: Optional[Exception] = None
        for index in self._available_indexes():
            client = self._client_for(index)

            def _do_search() -> List[MediaSearchResult]:
                resp = client.get(
                    _VIDEO_SEARCH_URL,
                    params={"query": query, "orientation": orientation, "per_page": per_page, "size": "medium"},
                )
                if resp.status_code == 401:
                    raise RuntimeError("Pexels API key rejected (401)")
                if resp.status_code == 429:
                    raise RuntimeError("Pexels rate limit hit (429)")
                resp.raise_for_status()
                data = resp.json()
                results: List[MediaSearchResult] = []
                for video in data.get("videos", []):
                    files = sorted(video.get("video_files", []), key=lambda f: (f.get("width") or 0))
                    chosen = None
                    for f in files:
                        if (f.get("width") or 0) >= 720:
                            chosen = f
                            break
                    if chosen is None and files:
                        chosen = files[-1]
                    if chosen is None:
                        continue
                    results.append(
                        MediaSearchResult(
                            source_id=str(video["id"]),
                            url=chosen["link"],
                            asset_type="video",
                            width=chosen.get("width") or 0,
                            height=chosen.get("height") or 0,
                            duration=video.get("duration"),
                        )
                    )
                return results

            try:
                return retry_with_backoff(_do_search, max_attempts=2, retry_on=(httpx.HTTPError,))
            except Exception as exc:
                last_error = exc
                if "401" in str(exc) or "429" in str(exc):
                    logger.warning("Pexels key %d/%d exhausted/rejected: %s", index + 1, len(self._keys), exc)
                    self._mark_exhausted(index, exc)
                    continue
                logger.warning("Pexels video search failed for '%s' on key %d: %s", query, index + 1, exc)
                continue

        logger.warning("All Pexels keys failed for '%s' (%s); trying photo fallback.", query, last_error)
        return self._search_photos(query, per_page=per_page)

    def _search_photos(self, query: str, per_page: int = 5) -> List[MediaSearchResult]:
        for index in self._available_indexes():
            try:
                resp = self._client_for(index).get(_PHOTO_SEARCH_URL, params={"query": query, "per_page": per_page})
                if resp.status_code in (401, 429):
                    self._mark_exhausted(index, RuntimeError(f"HTTP {resp.status_code}"))
                    continue
                resp.raise_for_status()
                data = resp.json()
                results = []
                for photo in data.get("photos", []):
                    results.append(
                        MediaSearchResult(
                            source_id=str(photo["id"]),
                            url=photo["src"]["large2x"],
                            asset_type="photo",
                            width=photo.get("width") or 0,
                            height=photo.get("height") or 0,
                        )
                    )
                return results
            except Exception as exc:
                logger.error("Pexels photo fallback failed for '%s' on key %d: %s", query, index + 1, exc)
                continue
        return []

    def download(self, result: MediaSearchResult, destination: Path) -> Path:
        def _do_download() -> Path:
            destination.parent.mkdir(parents=True, exist_ok=True)
            with httpx.stream("GET", result.url, timeout=60, follow_redirects=True) as resp:
                resp.raise_for_status()
                with open(destination, "wb") as f:
                    for chunk in resp.iter_bytes(chunk_size=65536):
                        f.write(chunk)
            if not destination.exists() or destination.stat().st_size == 0:
                raise RuntimeError(f"Downloaded file is empty: {destination}")
            return destination

        return retry_with_backoff(_do_download, max_attempts=3, retry_on=(httpx.HTTPError, RuntimeError, OSError))
