"""
Real MediaProvider backed by the Pixabay API (videos + photo fallback),
with the same multi-key rotation + persisted exhaustion tracking as
PexelsProvider. Drop-in alternative via MEDIA_PROVIDER=pixabay.

Get a free key: log in at https://pixabay.com, then open
https://pixabay.com/api/docs/ -- your personal key is shown inline at the
top of that page (no separate "create key" form, no approval step).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

import httpx
from sqlalchemy.orm import Session

from app.config import Settings
from app.providers.base import MediaProvider, MediaSearchResult
from app.utils.retry import PermanentError, retry_with_backoff

logger = logging.getLogger("ytagent")

_VIDEO_SEARCH_URL = "https://pixabay.com/api/videos/"
_PHOTO_SEARCH_URL = "https://pixabay.com/api/"


class PixabayProvider(MediaProvider):
    def __init__(self, settings: Settings, db: Optional[Session] = None):
        self._db = db
        self._keys, self._credential_rows = self._load_keys(settings, db)
        if not self._keys:
            raise PermanentError(
                "No Pixabay API key is configured. Add one in the dashboard "
                "(Settings -> API Keys -> Pixabay) or set PIXABAY_API_KEY in .env. "
                "Get a free key at https://pixabay.com/api/docs/"
            )
        self._client = httpx.Client(timeout=30)
        self._exhausted: set[int] = set()

    @staticmethod
    def _load_keys(settings: Settings, db: Optional[Session]):
        keys: List[str] = []
        rows: List = []
        if db is not None:
            try:
                from app.repositories.provider_credential_repository import ProviderCredentialRepository
                from app.utils.secret_crypto import SecretCrypto

                credentials = ProviderCredentialRepository.get_active(db, category="media", provider_name="pixabay")
                if credentials:
                    crypto = SecretCrypto()
                    for cred in credentials:
                        try:
                            key = crypto.decrypt(cred.encrypted_value).strip()
                            if key and key not in keys:
                                keys.append(key)
                                rows.append(cred)
                        except Exception as exc:
                            logger.error("Failed to decrypt Pixabay credential %s: %s", cred.id, exc)
            except Exception as exc:
                logger.warning("Could not load Pixabay credentials from DB: %s", exc)

        if not keys:
            if getattr(settings, "PIXABAY_API_KEYS", None):
                for key in settings.PIXABAY_API_KEYS.split(","):
                    key = key.strip()
                    if key and key not in keys:
                        keys.append(key)
            if settings.PIXABAY_API_KEY and settings.PIXABAY_API_KEY.strip() not in keys:
                keys.append(settings.PIXABAY_API_KEY.strip())
            rows = [None] * len(keys)

        return keys, rows

    def _mark_exhausted(self, index: int, error: Optional[Exception] = None) -> None:
        self._exhausted.add(index)
        credential = self._credential_rows[index]
        if credential is not None and self._db is not None:
            try:
                from app.repositories.provider_credential_repository import ProviderCredentialRepository

                ProviderCredentialRepository.mark_exhausted(
                    self._db, credential, True, error_message=str(error) if error else None
                )
            except Exception as exc:
                logger.error("Failed to persist Pixabay key exhaustion: %s", exc)

    def _available_indexes(self) -> List[int]:
        return [i for i in range(len(self._keys)) if i not in self._exhausted]

    def is_available(self) -> bool:
        for i in self._available_indexes():
            try:
                resp = self._client.get(_VIDEO_SEARCH_URL, params={"key": self._keys[i], "q": "nature", "per_page": 3})
                if resp.status_code == 200:
                    return True
            except Exception as exc:
                logger.warning("Pixabay availability check failed on key %d: %s", i + 1, exc)
        return False

    def search(self, query: str, *, orientation: str = "portrait", per_page: int = 5) -> List[MediaSearchResult]:
        last_error: Optional[Exception] = None
        for index in self._available_indexes():
            key = self._keys[index]

            def _do_search() -> List[MediaSearchResult]:
                resp = self._client.get(
                    _VIDEO_SEARCH_URL,
                    params={"key": key, "q": query, "per_page": max(per_page, 3), "safesearch": "true"},
                )
                if resp.status_code in (401, 403):
                    raise RuntimeError("Pixabay API key rejected")
                if resp.status_code == 429:
                    raise RuntimeError("Pixabay rate limit hit (429)")
                resp.raise_for_status()
                data = resp.json()

                results: List[MediaSearchResult] = []
                for hit in data.get("hits", []):
                    variants = hit.get("videos", {})
                    chosen = self._choose_video_variant(variants, orientation)
                    if chosen is None:
                        continue
                    results.append(
                        MediaSearchResult(
                            source_id=str(hit["id"]),
                            url=chosen["url"],
                            asset_type="video",
                            width=chosen.get("width") or 0,
                            height=chosen.get("height") or 0,
                            duration=hit.get("duration"),
                        )
                    )
                return results

            try:
                return retry_with_backoff(_do_search, max_attempts=2, retry_on=(httpx.HTTPError,))
            except Exception as exc:
                last_error = exc
                if "rejected" in str(exc) or "429" in str(exc):
                    logger.warning("Pixabay key %d/%d exhausted/rejected: %s", index + 1, len(self._keys), exc)
                    self._mark_exhausted(index, exc)
                    continue
                logger.warning("Pixabay video search failed for '%s' on key %d: %s", query, index + 1, exc)
                continue

        logger.warning("All Pixabay keys failed for '%s' (%s); trying photo fallback.", query, last_error)
        return self._search_photos(query, orientation, per_page=per_page)

    @staticmethod
    def _choose_video_variant(variants: dict, orientation: str) -> Optional[dict]:
        candidates = [v for v in variants.values() if v.get("width") and v.get("height")]
        if not candidates:
            return None

        def matches_orientation(v: dict) -> bool:
            is_portrait = v["height"] >= v["width"]
            return is_portrait if orientation == "portrait" else not is_portrait

        oriented = [v for v in candidates if matches_orientation(v)] or candidates
        oriented.sort(key=lambda v: max(v["width"], v["height"]))
        for v in oriented:
            if max(v["width"], v["height"]) >= 720:
                return v
        return oriented[-1]

    def _search_photos(self, query: str, orientation: str, per_page: int = 5) -> List[MediaSearchResult]:
        pixabay_orientation = "vertical" if orientation == "portrait" else "horizontal"
        for index in self._available_indexes():
            try:
                resp = self._client.get(
                    _PHOTO_SEARCH_URL,
                    params={
                        "key": self._keys[index],
                        "q": query,
                        "image_type": "photo",
                        "orientation": pixabay_orientation,
                        "per_page": max(per_page, 3),
                        "safesearch": "true",
                    },
                )
                if resp.status_code in (401, 403, 429):
                    self._mark_exhausted(index, RuntimeError(f"HTTP {resp.status_code}"))
                    continue
                resp.raise_for_status()
                data = resp.json()
                results = []
                for hit in data.get("hits", []):
                    results.append(
                        MediaSearchResult(
                            source_id=str(hit["id"]),
                            url=hit["largeImageURL"],
                            asset_type="photo",
                            width=hit.get("imageWidth") or 0,
                            height=hit.get("imageHeight") or 0,
                        )
                    )
                return results
            except Exception as exc:
                logger.error("Pixabay photo fallback failed for '%s' on key %d: %s", query, index + 1, exc)
                continue
        return []

    def download(self, result: MediaSearchResult, destination: Path) -> Path:
        def _do_download() -> Path:
            destination.parent.mkdir(parents=True, exist_ok=True)
            with httpx.stream("GET", result.url, timeout=60, follow_redirects=True) as resp:
                resp.raise_for_status()
                with open(destination, "wb") as f:
                    for chunk in resp.iter_bytes(chunk_size=65536):
                        f.write(chunk)
            if not destination.exists() or destination.stat().st_size == 0:
                raise RuntimeError(f"Downloaded file is empty: {destination}")
            return destination

        return retry_with_backoff(_do_download, max_attempts=3, retry_on=(httpx.HTTPError, RuntimeError, OSError))
