"""
Real local TTS provider using Kokoro (open-weight local TTS model).

Uses the official `kokoro` Python package (KPipeline), which runs
entirely on-device (CPU or CUDA via torch) -- no cloud call, no API key.

Install:
    pip install kokoro soundfile
    # Kokoro also needs espeak-ng installed on the system for
    # grapheme-to-phoneme fallback on out-of-dictionary words.

The pipeline is created lazily (on first use) and cached, because model
load is relatively expensive and jobs are processed one-at-a-time by a
single worker.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import numpy as np

from app.config import Settings
from app.providers.base import TTSProvider

logger = logging.getLogger("ytagent")

# Kokoro language code for US English.
_LANG_CODE = "a"
_SAMPLE_RATE = 24000


class KokoroProvider(TTSProvider):
    def __init__(self, settings: Settings):
        self._settings = settings
        self._voice = settings.KOKORO_VOICE
        self._speed = settings.KOKORO_SPEED
        self._pipeline = None  # lazy-loaded KPipeline

    def _get_pipeline(self):
        if self._pipeline is not None:
            return self._pipeline
        try:
            from kokoro import KPipeline
        except ImportError as exc:
            raise RuntimeError(
                "The 'kokoro' package is not installed. Run: pip install kokoro soundfile\n"
                "Kokoro also requires espeak-ng to be installed on the system "
                "(https://github.com/espeak-ng/espeak-ng/releases) for phoneme fallback."
            ) from exc

        device = "cpu"
        try:
            import torch

            if torch.cuda.is_available():
                device = "cuda"
        except ImportError:
            pass

        logger.info("Loading Kokoro TTS pipeline (lang=%s, device=%s)...", _LANG_CODE, device)
        self._pipeline = KPipeline(lang_code=_LANG_CODE, device=device)
        return self._pipeline

    def is_available(self) -> bool:
        try:
            self._get_pipeline()
            return True
        except Exception as exc:
            logger.warning("Kokoro TTS unavailable: %s", exc)
            return False

    def synthesize(self, text: str, output_path: Path, *, voice: Optional[str] = None) -> Path:
        import soundfile as sf

        pipeline = self._get_pipeline()
        voice_name = voice or self._voice

        chunks: list[np.ndarray] = []
        generator = pipeline(text, voice=voice_name, speed=self._speed)
        for _graphemes, _phonemes, audio in generator:
            chunks.append(np.asarray(audio, dtype=np.float32))

        if not chunks:
            raise RuntimeError("Kokoro TTS produced no audio output for the given script")

        full_audio = np.concatenate(chunks)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        sf.write(str(output_path), full_audio, _SAMPLE_RATE)

        if not output_path.exists() or output_path.stat().st_size == 0:
            raise RuntimeError(f"Kokoro TTS did not produce a valid audio file at {output_path}")

        return output_path
