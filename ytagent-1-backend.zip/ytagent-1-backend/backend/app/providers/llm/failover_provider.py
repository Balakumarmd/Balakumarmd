"""
LLMFailoverProvider: wraps an ORDERED LIST of concrete LLM providers and
tries them in sequence, falling through to the next one whenever the
current provider is unusable (no keys configured, or every one of its
keys is currently quota-exhausted) or raises during generation.

This is what implements "if Gemini's keys run out, automatically use
Groq": the dashboard lets the person set a priority order per job (or a
default order in Settings), and this class is the thing that actually
walks that order at generation time -- constructing each concrete
provider lazily so a provider with no configured keys doesn't even get
instantiated until its turn.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from sqlalchemy.orm import Session

from app.config import Settings
from app.providers.base import LLMProvider

logger = logging.getLogger("ytagent")

# Canonical construction order. Each entry maps a provider name to a
# zero-arg-from-here factory; new providers register here and nowhere else.
def _build_provider(name: str, settings: Settings, db: Optional[Session]) -> LLMProvider:
    name = name.lower().strip()
    if name == "gemini":
        from app.providers.llm.gemini_provider import GeminiProvider

        return GeminiProvider(settings, db)
    if name == "groq":
        from app.providers.llm.groq_provider import GroqProvider

        return GroqProvider(settings, db)
    if name == "ollama":
        from app.providers.llm.ollama_provider import OllamaProvider

        return OllamaProvider(settings)
    raise ValueError(f"Unknown LLM provider '{name}'")


class LLMFailoverProvider(LLMProvider):
    def __init__(self, settings: Settings, db: Optional[Session], provider_order: List[str]):
        if not provider_order:
            raise ValueError("LLMFailoverProvider requires at least one provider in provider_order")
        self._settings = settings
        self._db = db
        self._provider_order = provider_order
        self._last_used_provider: Optional[str] = None

    @property
    def last_used_provider(self) -> Optional[str]:
        return self._last_used_provider

    def is_available(self) -> bool:
        for name in self._provider_order:
            try:
                provider = _build_provider(name, self._settings, self._db)
                if provider.is_available():
                    return True
            except Exception:
                continue
        return False

    def generate(self, prompt: str, *, system: Optional[str] = None, temperature: float = 0.7) -> str:
        last_error: Exception | None = None
        for i, name in enumerate(self._provider_order):
            try:
                provider = _build_provider(name, self._settings, self._db)
            except Exception as exc:
                logger.warning("LLM provider '%s' unusable (%s); trying next in priority order.", name, exc)
                last_error = exc
                continue

            try:
                result = provider.generate(prompt, system=system, temperature=temperature)
                self._last_used_provider = name
                return result
            except Exception as exc:
                last_error = exc
                is_last = i == len(self._provider_order) - 1
                if is_last:
                    logger.error("LLM provider '%s' failed and no further providers to fall back to: %s", name, exc)
                    raise
                logger.warning(
                    "LLM provider '%s' failed (%s). Falling back to next provider: %s",
                    name,
                    exc,
                    self._provider_order[i + 1],
                )
                continue

        raise RuntimeError(f"All configured LLM providers failed. Last error: {last_error}")
