from __future__ import annotations

import logging
import time

from google import genai
from google.genai import errors
from google.genai import types

from app.config import Settings
from app.providers.base import LLMProvider
from app.schemas.schemas import GeneratedScript
from sqlalchemy.orm import Session

from app.providers.llm.errors import AllKeysExhaustedError
from app.repositories.provider_credential_repository import (
    ProviderCredentialRepository,
)
from app.utils.secret_crypto import SecretCrypto

GEMINI_SCRIPT_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "title": {"type": "STRING"},
        "hook": {"type": "STRING"},
        "scenes": {
            "type": "ARRAY",
            "items": {
                "type": "OBJECT",
                "properties": {
                    "scene_number": {"type": "INTEGER"},
                    "narration": {"type": "STRING"},
                    "visual_query": {"type": "STRING"},
                    "duration": {"type": "NUMBER"},
                },
                "required": [
                    "scene_number",
                    "narration",
                    "visual_query",
                    "duration",
                ],
            },
        },
        "outro": {"type": "STRING"},
        "cta": {"type": "STRING"},
        "estimated_duration": {"type": "NUMBER"},
    },
    "required": [
        "title",
        "hook",
        "scenes",
        "outro",
        "cta",
        "estimated_duration",
    ],
}

logger = logging.getLogger("ytagent")


class GeminiProvider(LLMProvider):
    """Gemini API provider with multi-key rotation and retry handling."""

    def __init__(
        self,
        settings: Settings,
        db: Session | None = None,
    ):
        self._model = settings.gemini_model
        self._db = db

        keys: list[str] = []
        # Parallel list: credential row for keys[i], or None if the key
        # came from .env (in which case exhaustion can't be persisted to
        # the DB and only lasts for this process's lifetime).
        credential_rows: list = []

        # Prefer credentials stored in the dashboard/database.
        if db is not None:
            credentials = ProviderCredentialRepository.get_active(
                db,
                category="llm",
                provider_name="gemini",
            )

            if credentials:
                crypto = SecretCrypto()

                for credential in credentials:
                    try:
                        key = crypto.decrypt(
                            credential.encrypted_value
                        ).strip()

                        if key and key not in keys:
                            keys.append(key)
                            credential_rows.append(credential)

                    except Exception as exc:
                        logger.error(
                            "Failed to decrypt Gemini credential %s: %s",
                            credential.id,
                            exc,
                        )

        # Temporary fallback to .env.
        if not keys:
            keys = self._build_api_keys(settings)
            credential_rows = [None] * len(keys)

        if not keys:
            raise RuntimeError(
                "No Gemini API keys are configured in the dashboard "
                "or backend/.env"
            )

        self._api_keys = keys
        self._credential_rows = credential_rows

        self._clients = [
            genai.Client(api_key=api_key)
            for api_key in self._api_keys
        ]

        # Keys that have exhausted quota during the current worker process.
        # DB-backed keys ALSO get persisted via mark_exhausted so exhaustion
        # survives across jobs/restarts, not just within this instance.
        self._exhausted_keys: set[int] = set()

    @staticmethod
    def _build_api_keys(settings: Settings) -> list[str]:
        keys: list[str] = []

        # Preferred multi-key configuration.
        if settings.gemini_api_keys:
            for key in settings.gemini_api_keys.split(","):
                key = key.strip()
                if key:
                    keys.append(key)

        # Backward compatibility with the existing single-key configuration.
        if settings.gemini_api_key:
            single_key = settings.gemini_api_key.strip()

            if single_key and single_key not in keys:
                keys.append(single_key)

        # Remove duplicates while preserving order.
        return list(dict.fromkeys(keys))

    def is_available(self) -> bool:
        return bool(self._api_keys)

    @staticmethod
    def _is_quota_error(exc: Exception) -> bool:
        """Return True for Gemini quota/rate-limit failures."""

        status_code = getattr(exc, "status_code", None)

        if status_code is None:
            status_code = getattr(exc, "code", None)

        if status_code == 429:
            return True

        message = str(exc).lower()

        quota_markers = (
            "429",
            "resource exhausted",
            "quota",
            "rate limit",
            "rate-limit",
            "too many requests",
            "exceeded your current quota",
        )

        return any(marker in message for marker in quota_markers)

    @staticmethod
    def _is_503_error(exc: Exception) -> bool:
        """Return True for temporary Gemini server overload."""

        status_code = getattr(exc, "status_code", None)

        if status_code is None:
            status_code = getattr(exc, "code", None)

        if status_code == 503:
            return True

        message = str(exc).lower()

        return (
            "503" in message
            or "service unavailable" in message
            or "temporarily unavailable" in message
            or "overloaded" in message
        )

    def _available_key_indexes(self) -> list[int]:
        return [
            index
            for index in range(len(self._api_keys))
            if index not in self._exhausted_keys
        ]

    def _mark_key_exhausted(self, key_index: int, error: Exception | None = None) -> None:
        self._exhausted_keys.add(key_index)

        logger.warning(
            "Gemini API key %s/%s exhausted. Rotating to the next key.",
            key_index + 1,
            len(self._api_keys),
        )

        credential = self._credential_rows[key_index]
        if credential is not None and self._db is not None:
            try:
                ProviderCredentialRepository.mark_exhausted(
                    self._db, credential, True, error_message=str(error) if error else None
                )
            except Exception as exc:
                logger.error("Failed to persist Gemini key exhaustion to DB: %s", exc)

    def _mark_key_healthy(self, key_index: int) -> None:
        credential = self._credential_rows[key_index]
        if credential is not None and self._db is not None and credential.is_exhausted:
            try:
                ProviderCredentialRepository.clear_exhausted(self._db, credential)
            except Exception as exc:
                logger.error("Failed to clear Gemini key exhaustion flag in DB: %s", exc)

    def _generate_with_key(
        self,
        key_index: int,
        contents: str,
        temperature: float,
    ):
        client = self._clients[key_index]

        # Retry temporary 503 errors on the SAME key.
        for attempt in range(3):
            try:
                return client.models.generate_content(
                    model=self._model,
                    contents=contents,
                    config=types.GenerateContentConfig(
                        temperature=temperature,
                    ),
                )

            except Exception as exc:
                if self._is_quota_error(exc):
                    raise

                if not self._is_503_error(exc):
                    raise

                if attempt == 2:
                    logger.warning(
                        "Gemini key %s/%s still unavailable after 3 "
                        "attempts because of 503.",
                        key_index + 1,
                        len(self._api_keys),
                    )
                    raise

                wait_seconds = 2 ** attempt

                logger.warning(
                    "Gemini key %s/%s returned 503. "
                    "Retrying in %s seconds...",
                    key_index + 1,
                    len(self._api_keys),
                    wait_seconds,
                )

                time.sleep(wait_seconds)

        raise RuntimeError("Gemini request failed unexpectedly.")

    def _generate(
        self,
        contents: str,
        temperature: float,
    ):
        last_error: Exception | None = None

        for key_index in self._available_key_indexes():
            try:
                logger.info(
                    "Using Gemini key %s/%s for model %s",
                    key_index + 1,
                    len(self._api_keys),
                    self._model,
                )

                response = self._generate_with_key(
                    key_index,
                    contents,
                    temperature,
                )

                if not response.text:
                    raise RuntimeError(
                        "Gemini returned an empty response."
                    )

                self._mark_key_healthy(key_index)
                return response

            except Exception as exc:
                last_error = exc

                if self._is_quota_error(exc):
                    self._mark_key_exhausted(key_index, exc)
                    continue

                # 503 was already retried 3 times by _generate_with_key.
                # Try the next configured key after those retries.
                if self._is_503_error(exc):
                    logger.warning(
                        "Gemini key %s/%s failed after 503 retries. "
                        "Trying the next key.",
                        key_index + 1,
                        len(self._api_keys),
                    )
                    continue

                raise

        raise AllKeysExhaustedError(
            "gemini",
            "All configured Gemini API keys are currently exhausted "
            f"or unavailable. Last error: {last_error}",
        )

    def generate(
        self,
        prompt: str,
        *,
        system: str | None = None,
        temperature: float = 0.7,
    ) -> str:
        contents = prompt

        if system:
            contents = f"{system}\n\n{prompt}"

        response = self._generate(
            contents,
            temperature,
        )

        return response.text

    def generate_script(
        self,
        prompt: str,
        *,
        system: str | None = None,
    ) -> GeneratedScript:
        contents = prompt

        if system:
            contents = f"{system}\n\n{prompt}"

        response = self._generate(
            contents,
            temperature=0.2,
        )

        return GeneratedScript.model_validate_json(
            response.text
        )