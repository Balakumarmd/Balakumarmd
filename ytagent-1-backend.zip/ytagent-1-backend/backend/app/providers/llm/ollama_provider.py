"""
Real LLM provider backed by a locally running Ollama server.

Talks to Ollama's HTTP API (default http://localhost:11434). Does not
hardcode the model name to qwen3:8b in the request path -- the model is
read from configuration so any pulled Ollama model can be used.
"""
from __future__ import annotations

import logging

import httpx

from app.config import Settings
from app.providers.base import LLMProvider
from app.utils.retry import PermanentError

logger = logging.getLogger("ytagent")


class OllamaProvider(LLMProvider):
    def __init__(self, settings: Settings):
        self._base_url = settings.OLLAMA_BASE_URL.rstrip("/")
        self._model = settings.OLLAMA_MODEL
        self._timeout = settings.OLLAMA_TIMEOUT_SECONDS

    def is_available(self) -> bool:
        try:
            resp = httpx.get(f"{self._base_url}/api/tags", timeout=5)
            if resp.status_code != 200:
                return False
            tags = resp.json().get("models", [])
            names = {m.get("name") for m in tags}
            # Accept exact match or a tag-less prefix match (e.g. "qwen3" vs "qwen3:8b")
            return any(self._model == n or self._model.split(":")[0] == n.split(":")[0] for n in names)
        except Exception as exc:
            logger.warning("Ollama availability check failed: %s", exc)
            return False

    def generate(self, prompt: str, *, system: str | None = None, temperature: float = 0.7) -> str:
        payload = {
            "model": self._model,
            "prompt": prompt,
            "system": system,
            "stream": False,
            "options": {"temperature": temperature},
        }
        try:
            resp = httpx.post(
                f"{self._base_url}/api/generate",
                json=payload,
                timeout=self._timeout,
            )
        except httpx.ConnectError as exc:
            raise ConnectionError(
                f"Could not reach Ollama at {self._base_url}. Is 'ollama serve' running?"
            ) from exc
        if resp.status_code == 404:
            raise PermanentError(
                f"Ollama model '{self._model}' not found. Run: ollama pull {self._model}"
            )
        if resp.status_code != 200:
            raise RuntimeError(f"Ollama request failed ({resp.status_code}): {resp.text[:500]}")
        data = resp.json()
        return data.get("response", "")
