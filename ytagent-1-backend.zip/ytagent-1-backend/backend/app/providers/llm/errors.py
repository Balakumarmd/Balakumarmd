"""
Shared LLM provider exceptions.

AllKeysExhaustedError is raised by a concrete provider (Gemini, Groq, ...)
only when every one of ITS configured keys is exhausted/unavailable. The
LLMFailoverProvider catches specifically this exception to move on to the
next provider in the configured priority order (e.g. Gemini -> Groq).
Any other exception (bad prompt, invalid schema, network outage) is NOT
treated as "try the next provider" -- it propagates as a real failure,
consistent with the rest of the app never silently masking errors.
"""
from __future__ import annotations


class AllKeysExhaustedError(RuntimeError):
    def __init__(self, provider_name: str, message: str):
        super().__init__(message)
        self.provider_name = provider_name
