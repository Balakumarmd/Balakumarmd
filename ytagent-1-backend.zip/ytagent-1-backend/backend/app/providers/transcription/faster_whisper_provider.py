"""
Real word-level transcription provider using faster-whisper (CTranslate2
backend). Runs entirely locally. Will use the NVIDIA GPU automatically when
available (WHISPER_DEVICE=auto), and falls back to CPU otherwise.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List

from app.config import Settings
from app.providers.base import TranscriptionProvider

logger = logging.getLogger("ytagent")


class FasterWhisperProvider(TranscriptionProvider):
    def __init__(self, settings: Settings):
        self._model_name = settings.WHISPER_MODEL
        self._device_setting = settings.WHISPER_DEVICE
        self._compute_type_setting = settings.WHISPER_COMPUTE_TYPE
        self._model = None  # lazy

    def _resolve_device_and_compute(self) -> tuple[str, str]:
        device = self._device_setting
        compute_type = self._compute_type_setting
        if device == "auto":
            try:
                import torch

                device = "cuda" if torch.cuda.is_available() else "cpu"
            except ImportError:
                device = "cpu"
        if compute_type == "auto":
            compute_type = "float16" if device == "cuda" else "int8"
        return device, compute_type

    def _get_model(self):
        if self._model is not None:
            return self._model
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise RuntimeError(
                "The 'faster-whisper' package is not installed. Run: pip install faster-whisper"
            ) from exc

        device, compute_type = self._resolve_device_and_compute()
        logger.info(
            "Loading faster-whisper model '%s' (device=%s, compute_type=%s)...",
            self._model_name,
            device,
            compute_type,
        )
        try:
            self._model = WhisperModel(self._model_name, device=device, compute_type=compute_type)
        except Exception as exc:
            if device == "cuda":
                logger.warning("CUDA load failed (%s); falling back to CPU int8", exc)
                self._model = WhisperModel(self._model_name, device="cpu", compute_type="int8")
            else:
                raise
        return self._model

    def is_available(self) -> bool:
        try:
            self._get_model()
            return True
        except Exception as exc:
            logger.warning("faster-whisper unavailable: %s", exc)
            return False

    def transcribe_word_level(self, audio_path: Path) -> List[dict]:
        model = self._get_model()
        segments, _info = model.transcribe(
            str(audio_path),
            word_timestamps=True,
            vad_filter=True,
        )
        words: List[dict] = []
        for segment in segments:
            if not segment.words:
                continue
            for w in segment.words:
                words.append({"word": w.word.strip(), "start": float(w.start), "end": float(w.end)})
        if not words:
            raise RuntimeError(
                "faster-whisper returned no word-level timestamps. "
                "The narration audio may be silent or corrupted."
            )
        return words
