"""
Provider interfaces (abstract base classes).

Every external capability the application depends on is defined here as an
abstract interface. Business logic (the services/ layer) NEVER imports a
concrete provider class directly except at the single "factory" point in
each service's __init__. This is what makes it possible to swap
Ollama -> OpenAI, Kokoro -> ElevenLabs, Pexels -> Pixabay, etc. later
without touching pipeline logic.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Optional


class LLMProvider(ABC):
    @abstractmethod
    def generate(self, prompt: str, *, system: Optional[str] = None, temperature: float = 0.7) -> str:
        """Return raw text completion for the given prompt."""

    @abstractmethod
    def is_available(self) -> bool:
        """Cheap health check -- must not raise."""


class TTSProvider(ABC):
    @abstractmethod
    def synthesize(self, text: str, output_path: Path, *, voice: Optional[str] = None) -> Path:
        """Render `text` to a WAV file at `output_path` and return that path."""

    @abstractmethod
    def is_available(self) -> bool:
        ...


class TranscriptionProvider(ABC):
    @abstractmethod
    def transcribe_word_level(self, audio_path: Path) -> list[dict]:
        """Return a list of {"word": str, "start": float, "end": float}."""

    @abstractmethod
    def is_available(self) -> bool:
        ...


class MediaSearchResult:
    def __init__(self, source_id: str, url: str, asset_type: str, width: int, height: int, duration: Optional[float] = None):
        self.source_id = source_id
        self.url = url
        self.asset_type = asset_type
        self.width = width
        self.height = height
        self.duration = duration


class MediaProvider(ABC):
    @abstractmethod
    def search(self, query: str, *, orientation: str = "portrait", per_page: int = 5) -> List[MediaSearchResult]:
        ...

    @abstractmethod
    def download(self, result: MediaSearchResult, destination: Path) -> Path:
        ...

    @abstractmethod
    def is_available(self) -> bool:
        ...


class YouTubeProvider(ABC):
    @abstractmethod
    def get_authorization_url(self) -> str:
        ...

    @abstractmethod
    def exchange_code_for_token(self, code: str) -> dict:
        ...

    @abstractmethod
    def is_connected(self) -> bool:
        ...

    @abstractmethod
    def upload_video(
        self,
        video_path: Path,
        title: str,
        description: str,
        tags: List[str],
        category_id: str,
        privacy_status: str,
        thumbnail_path: Optional[Path] = None,
        publish_at=None,
    ) -> dict:
        """Returns {"video_id": ..., "url": ..., "scheduled_for": ...}."""
