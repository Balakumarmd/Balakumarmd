"""
Provider factory.

This is the ONLY place in the application that instantiates a concrete
provider class. To add a new provider (e.g. OpenAIProvider, ElevenLabsProvider,
PixabayProvider), implement the relevant interface in providers/<category>/
and add one branch below. No other file needs to change.
"""
from __future__ import annotations

from typing import Optional

from app.config import Settings
from app.providers.base import LLMProvider, MediaProvider, TranscriptionProvider, TTSProvider, YouTubeProvider


_KNOWN_LLM_PROVIDERS = ("gemini", "groq", "ollama")


def get_llm_provider(settings: Settings) -> LLMProvider:
    """
    Non-DB-aware fallback: builds a single provider from settings.LLM_PROVIDER
    only (and, for gemini/groq, only .env-configured keys since there's no DB
    session to read dashboard-stored credentials from). Used only when no DB
    session is available. Prefer get_llm_provider_from_db everywhere else.
    """
    provider = settings.LLM_PROVIDER.lower().strip()

    if provider == "gemini":
        from app.providers.llm.gemini_provider import GeminiProvider
        return GeminiProvider(settings, None)

    if provider == "ollama":
        from app.providers.llm.ollama_provider import OllamaProvider
        return OllamaProvider(settings)

    if provider == "groq":
        from app.providers.llm.groq_provider import GroqProvider
        return GroqProvider(settings, None)

    raise ValueError(
        f"Unsupported LLM_PROVIDER: {settings.LLM_PROVIDER}. "
        "Supported providers: ollama, gemini, groq"
    )


def get_llm_provider_from_db(
    settings: Settings,
    db,
    requested_provider: Optional[str] = None,
) -> LLMProvider:
    """
    Builds the LLM provider the worker should use for a job, WITH automatic
    cross-provider failover.

    - requested_provider: the job's explicit choice ("gemini"/"groq"/"ollama"),
      or None/"auto" to use the dashboard's configured priority order.
    - The returned provider tries requested_provider FIRST (if given), then
      falls through the dashboard's configured priority order (skipping
      duplicates), so even an explicit choice still has a safety net if that
      provider's keys are completely exhausted.
    - If nothing is configured anywhere, falls back to Ollama (always assumed
      available locally per this project's setup).
    """
    from app.providers.llm.failover_provider import LLMFailoverProvider
    from app.repositories.provider_config_repository import ProviderConfigRepository

    configured_order = ProviderConfigRepository.list_active_ordered(db, category="llm")

    order: list[str] = []
    if requested_provider and requested_provider.lower().strip() not in ("auto", ""):
        req = requested_provider.lower().strip()
        if req not in _KNOWN_LLM_PROVIDERS:
            raise ValueError(f"Unsupported llm_provider '{requested_provider}'. Supported: {_KNOWN_LLM_PROVIDERS}")
        order.append(req)

    for name in configured_order:
        if name not in order:
            order.append(name)

    if not order:
        order = [settings.LLM_PROVIDER.lower().strip()] if settings.LLM_PROVIDER else []

    if not order:
        order = ["ollama"]

    if "ollama" not in order:
        order.append("ollama")  # always keep Ollama as the final local safety net

    return LLMFailoverProvider(settings, db, order)


def get_tts_provider(settings: Settings) -> TTSProvider:
    from app.providers.tts.kokoro_provider import KokoroProvider

    if settings.TTS_PROVIDER == "kokoro":
        return KokoroProvider(settings)
    raise ValueError(f"Unknown TTS_PROVIDER '{settings.TTS_PROVIDER}'")


def get_transcription_provider(settings: Settings) -> TranscriptionProvider:
    from app.providers.transcription.faster_whisper_provider import FasterWhisperProvider

    return FasterWhisperProvider(settings)


def get_media_provider(settings: Settings, db=None) -> MediaProvider:
    if settings.MEDIA_PROVIDER == "pexels":
        from app.providers.media.pexels_provider import PexelsProvider

        return PexelsProvider(settings, db)
    if settings.MEDIA_PROVIDER == "pixabay":
        from app.providers.media.pixabay_provider import PixabayProvider

        return PixabayProvider(settings, db)
    raise ValueError(f"Unknown MEDIA_PROVIDER '{settings.MEDIA_PROVIDER}' (expected 'pexels' or 'pixabay')")


def get_youtube_provider(settings: Settings, stored_token_json: Optional[str] = None) -> YouTubeProvider:
    from app.providers.youtube.youtube_data_api_provider import YouTubeDataAPIProvider

    return YouTubeDataAPIProvider(settings, stored_token_json=stored_token_json)
