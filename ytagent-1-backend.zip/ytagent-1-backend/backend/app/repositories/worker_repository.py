from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from sqlalchemy.orm import Session

from app.models import Worker


def upsert_worker_heartbeat(db: Session, worker_id: str, **kwargs) -> Worker:
    worker = db.get(Worker, worker_id)
    if worker is None:
        worker = Worker(id=worker_id, **kwargs)
        db.add(worker)
    else:
        for k, v in kwargs.items():
            setattr(worker, k, v)
    worker.last_heartbeat = datetime.utcnow()
    db.commit()
    db.refresh(worker)
    return worker


def list_workers(db: Session) -> List[Worker]:
    return db.query(Worker).order_by(Worker.last_heartbeat.desc()).all()


def get_worker(db: Session, worker_id: str) -> Optional[Worker]:
    return db.get(Worker, worker_id)
