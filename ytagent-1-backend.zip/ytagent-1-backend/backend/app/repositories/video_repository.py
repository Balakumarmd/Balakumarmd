from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from sqlalchemy.orm import Session

from app.models import Video


def create_video(db: Session, **kwargs) -> Video:
    video = Video(**kwargs)
    db.add(video)
    db.commit()
    db.refresh(video)
    return video


def get_video(db: Session, video_id: str) -> Optional[Video]:
    return db.get(Video, video_id)


def get_video_by_job(db: Session, job_id: str) -> Optional[Video]:
    return db.query(Video).filter(Video.job_id == job_id).first()


def list_videos(db: Session, limit: int = 100) -> List[Video]:
    return db.query(Video).order_by(Video.created_at.desc()).limit(limit).all()


def update_video(db: Session, video_id: str, **kwargs) -> Optional[Video]:
    video = db.get(Video, video_id)
    if video is None:
        return None
    for k, v in kwargs.items():
        setattr(video, k, v)
    db.commit()
    db.refresh(video)
    return video


def mark_uploaded(db: Session, video_id: str, youtube_video_id: str, youtube_url: str, privacy: str) -> Optional[Video]:
    video = db.get(Video, video_id)
    if video is None:
        return None
    video.youtube_video_id = youtube_video_id
    video.youtube_url = youtube_url
    video.uploaded_at = datetime.utcnow()
    video.upload_privacy = privacy
    db.commit()
    db.refresh(video)
    return video
