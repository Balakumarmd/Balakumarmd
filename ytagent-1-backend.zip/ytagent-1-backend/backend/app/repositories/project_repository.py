from __future__ import annotations

from typing import List, Optional

from sqlalchemy.orm import Session

from app.models import Project


def create_project(db: Session, **kwargs) -> Project:
    proj = Project(**kwargs)
    db.add(proj)
    db.commit()
    db.refresh(proj)
    return proj


def list_projects(db: Session) -> List[Project]:
    return db.query(Project).order_by(Project.created_at.desc()).all()


def get_project(db: Session, project_id: str) -> Optional[Project]:
    return db.get(Project, project_id)
