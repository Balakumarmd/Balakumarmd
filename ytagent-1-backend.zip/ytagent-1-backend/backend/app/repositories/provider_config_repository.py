from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import ProviderConfig


class ProviderConfigRepository:

    @staticmethod
    def list_by_category(
        db: Session,
        *,
        category: str,
    ) -> list[ProviderConfig]:
        stmt = (
            select(ProviderConfig)
            .where(ProviderConfig.category == category)
            .order_by(ProviderConfig.updated_at.desc())
        )
        return list(db.scalars(stmt).all())

    @staticmethod
    def get_active(
        db: Session,
        *,
        category: str,
    ) -> ProviderConfig | None:
        stmt = (
            select(ProviderConfig)
            .where(
                ProviderConfig.category == category,
                ProviderConfig.is_active.is_(True),
            )
            .order_by(ProviderConfig.updated_at.desc())
        )
        return db.scalars(stmt).first()

    @staticmethod
    def get_by_provider(
        db: Session,
        *,
        category: str,
        provider_name: str,
    ) -> ProviderConfig | None:
        stmt = select(ProviderConfig).where(
            ProviderConfig.category == category,
            ProviderConfig.provider_name == provider_name,
        )
        return db.scalars(stmt).first()

    @staticmethod
    def create(
        db: Session,
        *,
        category: str,
        provider_name: str,
        config_json: dict | None = None,
    ) -> ProviderConfig:
        config = ProviderConfig(
            category=category,
            provider_name=provider_name,
            is_active=True,
            config_json=config_json,
        )
        db.add(config)
        db.flush()
        return config

    @staticmethod
    def list_active_ordered(
        db: Session,
        *,
        category: str,
    ) -> list[str]:
        """Returns provider names for `category`, active only, ordered by
        priority ascending (lower priority number = tried first)."""
        stmt = (
            select(ProviderConfig)
            .where(
                ProviderConfig.category == category,
                ProviderConfig.is_active.is_(True),
            )
            .order_by(ProviderConfig.priority.asc())
        )
        return [c.provider_name for c in db.scalars(stmt).all()]

    @staticmethod
    def set_priority_order(
        db: Session,
        *,
        category: str,
        provider_names_in_order: list[str],
    ) -> None:
        """Replace the fallback order for `category` wholesale. Any
        provider not in the list is deactivated (removed from rotation)
        but its row (and any saved config_json) is kept, not deleted."""
        existing = {c.provider_name: c for c in ProviderConfigRepository.list_by_category(db, category=category)}

        for index, provider_name in enumerate(provider_names_in_order):
            config = existing.get(provider_name)
            if config is None:
                config = ProviderConfig(category=category, provider_name=provider_name)
                db.add(config)
            config.is_active = True
            config.priority = index

        for provider_name, config in existing.items():
            if provider_name not in provider_names_in_order:
                config.is_active = False

        db.commit()

    @staticmethod
    def deactivate_category(
        db: Session,
        *,
        category: str,
    ) -> None:
        configs = ProviderConfigRepository.list_by_category(
            db,
            category=category,
        )

        for config in configs:
            config.is_active = False

        db.flush()