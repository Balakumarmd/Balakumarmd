from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.models import ProviderCredential

# Most free-tier LLM APIs (Gemini, Groq) reset daily quotas every 24h.
# A key marked exhausted becomes eligible again after this cooldown instead
# of staying exhausted forever or being retried every single job.
DEFAULT_EXHAUSTION_COOLDOWN = timedelta(hours=24)


class ProviderCredentialRepository:

    @staticmethod
    def create(
        db: Session,
        *,
        category: str,
        provider_name: str,
        encrypted_value: str,
        credential_type: str = "api_key",
        display_name: str | None = None,
    ) -> ProviderCredential:
        credential = ProviderCredential(
            category=category,
            provider_name=provider_name,
            credential_type=credential_type,
            display_name=display_name,
            encrypted_value=encrypted_value,
            is_active=True,
            is_exhausted=False,
        )

        db.add(credential)
        db.flush()
        return credential

    @staticmethod
    def list_by_provider(
        db: Session,
        *,
        category: str,
        provider_name: str,
    ) -> list[ProviderCredential]:
        stmt = (
            select(ProviderCredential)
            .where(
                ProviderCredential.category == category,
                ProviderCredential.provider_name == provider_name,
            )
            .order_by(ProviderCredential.created_at.asc())
        )

        return list(db.scalars(stmt).all())

    @staticmethod
    def get_active(
        db: Session,
        *,
        category: str,
        provider_name: str,
    ) -> list[ProviderCredential]:
        """
        Returns usable credentials: active, and either never marked
        exhausted or past their exhaustion cooldown (auto-recovered).
        Auto-recovered rows are NOT written back as un-exhausted here --
        that happens explicitly in `generate()`'s success path via
        `clear_exhausted`, so a key that still fails after the cooldown
        gets re-marked immediately rather than flapping.
        """
        now = datetime.utcnow()
        stmt = (
            select(ProviderCredential)
            .where(
                ProviderCredential.category == category,
                ProviderCredential.provider_name == provider_name,
                ProviderCredential.is_active.is_(True),
                or_(
                    ProviderCredential.is_exhausted.is_(False),
                    ProviderCredential.exhausted_until.is_(None),
                    ProviderCredential.exhausted_until <= now,
                ),
            )
            .order_by(ProviderCredential.created_at.asc())
        )

        return list(db.scalars(stmt).all())

    @staticmethod
    def mark_exhausted(
        db: Session,
        credential: ProviderCredential,
        exhausted: bool = True,
        *,
        cooldown: timedelta = DEFAULT_EXHAUSTION_COOLDOWN,
        error_message: str | None = None,
    ) -> None:
        credential.is_exhausted = exhausted
        credential.exhausted_until = (datetime.utcnow() + cooldown) if exhausted else None
        if error_message:
            credential.last_error = error_message[:2000]
        db.commit()

    @staticmethod
    def clear_exhausted(db: Session, credential: ProviderCredential) -> None:
        credential.is_exhausted = False
        credential.exhausted_until = None
        credential.last_error = None
        db.commit()

    @staticmethod
    def set_active(
        db: Session,
        credential: ProviderCredential,
        active: bool,
    ) -> None:
        credential.is_active = active
        db.flush()

    @staticmethod
    def delete(db: Session, credential: ProviderCredential) -> None:
        db.delete(credential)
        db.commit()