from __future__ import annotations

from typing import Dict

from sqlalchemy.orm import Session

from app.models import Setting


def get_all_settings(db: Session) -> Dict[str, str]:
    rows = db.query(Setting).all()
    return {row.key: row.value for row in rows}


def set_settings(db: Session, values: Dict[str, str]) -> Dict[str, str]:
    for key, value in values.items():
        row = db.get(Setting, key)
        if row is None:
            row = Setting(key=key, value=value)
            db.add(row)
        else:
            row.value = value
    db.commit()
    return get_all_settings(db)
