"""
Aggregates health checks for every subsystem (spec section 38) so the
dashboard's System Status page and GET /api/system/status reflect the
real, current state of each dependency -- never a hardcoded "ok".
"""
from __future__ import annotations

from typing import Optional

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.config import Settings
from app.database import engine
from app.utils.ffmpeg_utils import check_ffmpeg_available
from app.utils.system_info import get_cpu_info, get_disk_info, get_gpu_info, get_memory_info


def check_database() -> str:
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return "ok"
    except Exception:
        return "error"


def check_ollama(settings: Settings) -> str:
    try:
        from app.providers.llm.ollama_provider import OllamaProvider

        return "ok" if OllamaProvider(settings).is_available() else "unavailable"
    except Exception:
        return "unavailable"


def check_ffmpeg() -> str:
    return "ok" if check_ffmpeg_available() else "unavailable"


def check_tts(settings: Settings) -> str:
    try:
        from app.providers.tts.kokoro_provider import KokoroProvider

        return "ok" if KokoroProvider(settings).is_available() else "unavailable"
    except Exception:
        return "unavailable"


def check_whisper(settings: Settings) -> str:
    try:
        from app.providers.transcription.faster_whisper_provider import FasterWhisperProvider

        return "ok" if FasterWhisperProvider(settings).is_available() else "unavailable"
    except Exception:
        return "unavailable"


def check_media_provider(settings: Settings, db: Session = None) -> str:
    """Checks whichever MediaProvider is currently active (Pexels or
    Pixabay) rather than hardcoding Pexels -- swapping MEDIA_PROVIDER in
    the dashboard is reflected here automatically."""
    try:
        from app.providers.factory import get_media_provider

        provider = get_media_provider(settings, db)
    except Exception:
        return "not_configured"
    try:
        return "configured" if provider.is_available() else "error"
    except Exception:
        return "error"


def check_youtube(settings: Settings, db: Session) -> dict:
    try:
        from app.services.youtube_service import YouTubeService

        svc = YouTubeService(settings, db)
        channels = svc.list_channels()
        connected = [c for c in channels if c.token_json]
        return {"status": "connected" if connected else "not_connected", "channel_count": len(connected)}
    except Exception:
        return {"status": "not_connected", "channel_count": 0}


def check_llm_providers(settings: Settings, db: Session) -> dict:
    """Per-provider status so the dashboard can show 'Gemini: ok (2 keys),
    Groq: exhausted, Ollama: ok' rather than one opaque flag."""
    from app.repositories.provider_config_repository import ProviderConfigRepository
    from app.repositories.provider_credential_repository import ProviderCredentialRepository

    result = {}
    for provider_name in ("gemini", "groq", "ollama"):
        if provider_name == "ollama":
            result["ollama"] = check_ollama(settings)
            continue
        try:
            active_keys = ProviderCredentialRepository.get_active(db, category="llm", provider_name=provider_name)
            all_keys = ProviderCredentialRepository.list_by_provider(db, category="llm", provider_name=provider_name)
            env_fallback = bool(
                getattr(settings, f"{provider_name}_api_key", None) or getattr(settings, f"{provider_name}_api_keys", None)
            )
            if active_keys:
                result[provider_name] = f"ok ({len(active_keys)}/{len(all_keys)} keys available)"
            elif all_keys:
                result[provider_name] = "all keys exhausted"
            elif env_fallback:
                result[provider_name] = "ok (.env key)"
            else:
                result[provider_name] = "not_configured"
        except Exception:
            result[provider_name] = "error"

    try:
        result["priority_order"] = ProviderConfigRepository.list_active_ordered(db, category="llm") or ["ollama"]
    except Exception:
        result["priority_order"] = ["ollama"]

    return result


def full_system_status(settings: Settings, db: Session) -> dict:
    youtube_status = check_youtube(settings, db)
    return {
        "api": "ok",
        "database": check_database(),
        "ollama": check_ollama(settings),
        "ollama_model": settings.OLLAMA_MODEL,
        "llm_providers": check_llm_providers(settings, db),
        "ffmpeg": check_ffmpeg(),
        "tts": check_tts(settings),
        "whisper": check_whisper(settings),
        "media_provider_name": settings.MEDIA_PROVIDER,
        "pexels": check_media_provider(settings, db),  # key name kept for dashboard compatibility
        "youtube": youtube_status["status"],
        "youtube_channel_count": youtube_status["channel_count"],
        "storage": get_disk_info(str(settings.data_dir_path)),
        "cpu": get_cpu_info(),
        "memory": get_memory_info(),
        "gpu": get_gpu_info(),
        "data_dir": str(settings.data_dir_path),
    }
