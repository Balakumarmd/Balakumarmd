"""
Live Google Sheet sync.

Lets someone maintain their content calendar (topic + schedule date/time +
etc.) in a normal Google Sheet, edit it from the Google Sheets mobile app,
and have YTAgent pick up new/changed rows automatically on a poll loop --
no re-uploading a file every time.

Setup (documented in README.md):
  1. In the SAME Google Cloud project used for YouTube OAuth, enable the
     "Google Sheets API".
  2. Create an API key (APIs & Services -> Credentials -> Create
     credentials -> API key). This key only needs read access to public
     Sheets data, so it's lower-stakes than the OAuth client secret --
     still, restrict it to the Sheets API in the Cloud Console.
  3. In the Google Sheet itself, use Share -> "Anyone with the link" ->
     Viewer. (The API key approach only works for link-shareable sheets;
     for a private sheet, a service account would be needed instead --
     not implemented in V1.)
  4. Paste the Sheet's ID (the long id in its URL, between /d/ and /edit)
     and the API key into Settings -> Bulk Import in the dashboard.

Dedup/change-detection is delegated entirely to bulk_import_service.import_rows.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import httpx
from sqlalchemy.orm import Session

from app.repositories.settings_repository import get_all_settings
from app.schemas.schemas import BulkImportResult
from app.services.bulk_import_service import import_rows
from app.utils.secret_crypto import SecretCrypto

logger = logging.getLogger("ytagent")

_SHEETS_API_BASE = "https://sheets.googleapis.com/v4/spreadsheets"


class SheetSyncDisabled(Exception):
    pass


def get_sheet_sync_config(db: Session) -> Dict[str, Any]:
    settings_values = get_all_settings(db)
    api_key = None
    try:
        from app.repositories.provider_credential_repository import ProviderCredentialRepository

        creds = ProviderCredentialRepository.get_active(db, category="sheets", provider_name="google_api_key")
        if creds:
            api_key = SecretCrypto().decrypt(creds[0].encrypted_value)
    except Exception as exc:
        logger.warning("Could not load Google Sheets API key: %s", exc)

    return {
        "enabled": settings_values.get("sheet_sync_enabled", "false").lower() == "true",
        "sheet_id": settings_values.get("sheet_sync_sheet_id") or None,
        "sheet_range": settings_values.get("sheet_sync_range") or "A:Z",
        "poll_interval_seconds": int(settings_values.get("sheet_sync_poll_interval_seconds") or 120),
        "api_key": api_key,
    }


def fetch_sheet_rows(sheet_id: str, sheet_range: str, api_key: str) -> List[Dict[str, Any]]:
    url = f"{_SHEETS_API_BASE}/{sheet_id}/values/{sheet_range}"
    try:
        resp = httpx.get(url, params={"key": api_key}, timeout=20)
    except httpx.HTTPError as exc:
        raise RuntimeError(f"Could not reach Google Sheets API: {exc}") from exc

    if resp.status_code == 403:
        raise RuntimeError(
            "Google Sheets API returned 403. Check that the Sheets API is enabled for your "
            "API key's project, and that the sheet is shared as 'Anyone with the link can view'."
        )
    if resp.status_code == 404:
        raise RuntimeError("Google Sheets API returned 404. Check the Sheet ID.")
    if resp.status_code != 200:
        raise RuntimeError(f"Google Sheets API error {resp.status_code}: {resp.text[:300]}")

    data = resp.json()
    values = data.get("values", [])
    if not values:
        return []

    headers = [str(h) for h in values[0]]
    rows: List[Dict[str, Any]] = []
    for raw_row in values[1:]:
        if not any(cell not in (None, "") for cell in raw_row):
            continue
        padded = raw_row + [None] * (len(headers) - len(raw_row))
        rows.append(dict(zip(headers, padded)))
    return rows


def run_sync_once(db: Session, force: bool = False) -> Optional[BulkImportResult]:
    config = get_sheet_sync_config(db)
    if not force and not config["enabled"]:
        return None
    if not config["sheet_id"] or not config["api_key"]:
        logger.warning("Sheet sync is enabled but sheet_id or api_key is not configured; skipping this cycle.")
        return None

    rows = fetch_sheet_rows(config["sheet_id"], config["sheet_range"], config["api_key"])
    if not rows:
        return BulkImportResult(created_jobs=0, skipped_unchanged=0, errors=[])

    result = import_rows(db, rows, source="sheet", row_key_prefix=f"sheet:{config['sheet_id']}")
    if result.created_jobs:
        logger.info(
            "Sheet sync: created %d new job(s), skipped %d unchanged row(s).",
            result.created_jobs,
            result.skipped_unchanged,
        )
    return result
