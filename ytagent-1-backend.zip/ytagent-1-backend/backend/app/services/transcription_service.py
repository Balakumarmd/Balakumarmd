"""
Produces word-level timestamps for the narration audio via the configured
TranscriptionProvider (faster-whisper) and persists them as transcript.json.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from app.providers.base import TranscriptionProvider
from app.schemas.schemas import Transcript, TranscriptWord

logger = logging.getLogger("ytagent")


class TranscriptionError(Exception):
    pass


class TranscriptionService:
    def __init__(self, provider: TranscriptionProvider):
        self._provider = provider

    def transcribe(self, audio_path: Path, output_json_path: Path) -> Transcript:
        if not audio_path.exists():
            raise TranscriptionError(f"Audio file not found: {audio_path}")

        raw_words = self._provider.transcribe_word_level(audio_path)
        words = [TranscriptWord(**w) for w in raw_words]
        if not words:
            raise TranscriptionError("Transcription produced zero words")

        full_text = " ".join(w.word for w in words)
        duration = words[-1].end if words else 0.0
        transcript = Transcript(words=words, full_text=full_text, duration=duration)

        output_json_path.write_text(transcript.model_dump_json(indent=2), encoding="utf-8")
        logger.info("Transcript saved: %s (%d words, %.2fs)", output_json_path, len(words), duration)
        return transcript
