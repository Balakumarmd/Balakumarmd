"""
Turns rows from an Excel upload OR a synced Google Sheet into Jobs.

Both paths converge here so there is exactly one place that:
  - normalizes flexible column headers
  - parses dates/times into `scheduled_at`
  - resolves a human-typed channel name to a Channel row
  - dedupes so re-importing the same (unchanged) row twice never creates a
    duplicate job -- this is what makes the "edit the sheet on my phone"
    workflow safe to poll repeatedly.

Dedup design: each row gets a `row_key` (a stable identity -- the Excel row
number, or the Sheet row number) and a `row_hash` (a hash of its actual
content). On every import pass we look up any existing SheetImportRow for
that row_key:
  - no existing record -> create the job, record the row
  - existing record, same hash -> row is unchanged, skip (this is what lets
    a sync loop poll every couple of minutes without creating duplicates)
  - existing record, different hash -> the person edited that row; if the
    job hasn't started rendering yet, we delete the old queued job and
    create a fresh one with the new details. If it already started, we
    leave it alone and report it so the person knows a mid-flight edit
    didn't take effect.
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
from datetime import datetime, date, time as dt_time
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from app.models import Job, JobStatus, SheetImportRow
from app.repositories import job_repository
from app.schemas.schemas import BulkImportResult

logger = logging.getLogger("ytagent")

# Flexible header aliases -> canonical field name.
_HEADER_ALIASES = {
    "topic": "topic",
    "title": "topic",
    "video topic": "topic",
    "content_type": "content_type",
    "type": "content_type",
    "format": "content_type",
    "niche": "niche",
    "category": "niche",
    "language": "language",
    "lang": "language",
    "duration": "target_duration_seconds",
    "target_duration_seconds": "target_duration_seconds",
    "duration_seconds": "target_duration_seconds",
    "voice": "voice",
    "music": "music_preference",
    "music_preference": "music_preference",
    "llm_provider": "llm_provider",
    "model": "llm_provider",
    "ai_model": "llm_provider",
    "channel": "channel_label",
    "channel_label": "channel_label",
    "youtube_channel": "channel_label",
    "auto_upload": "auto_upload",
    "upload": "auto_upload",
    "privacy": "upload_privacy",
    "upload_privacy": "upload_privacy",
    "scheduled_at": "scheduled_at",
    "schedule_datetime": "scheduled_at",
    "schedule_date_time": "scheduled_at",
    "scheduled_date": "schedule_date",
    "schedule_date": "schedule_date",
    "date": "schedule_date",
    "scheduled_time": "schedule_time",
    "schedule_time": "schedule_time",
    "time": "schedule_time",
}

_TEMPLATE_HEADERS = [
    "topic",
    "content_type",
    "niche",
    "language",
    "duration",
    "voice",
    "music",
    "llm_provider",
    "channel",
    "auto_upload",
    "privacy",
    "schedule_date",
    "schedule_time",
]

_TEMPLATE_EXAMPLE_ROWS = [
    [
        "5 AI tools students should know",
        "short",
        "Education",
        "en",
        45,
        "af_heart",
        "auto",
        "auto",
        "Main Channel",
        "yes",
        "private",
        "2026-10-10",
        "18:00",
    ],
    [
        "How compound interest actually works",
        "long_form",
        "Finance",
        "en",
        180,
        "af_heart",
        "auto",
        "auto",
        "Main Channel",
        "yes",
        "public",
        "2026-10-12",
        "09:00",
    ],
]


def _normalize_header(raw: str) -> Optional[str]:
    key = str(raw or "").strip().lower().replace(" ", "_").replace("-", "_")
    return _HEADER_ALIASES.get(key)


def _coerce_bool(value: Any, default: bool = True) -> bool:
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    return text in ("yes", "y", "true", "1", "auto", "x")


def _coerce_datetime(row: Dict[str, Any]) -> Optional[datetime]:
    """Accepts either a single combined `scheduled_at` value, or separate
    `schedule_date` + `schedule_time` cells (how spreadsheet apps usually
    store them, and the friendlier layout for someone editing on a phone)."""
    combined = row.get("scheduled_at")
    if isinstance(combined, datetime):
        return combined
    if isinstance(combined, str) and combined.strip():
        try:
            return datetime.fromisoformat(combined.strip())
        except ValueError:
            pass

    raw_date = row.get("schedule_date")
    raw_time = row.get("schedule_time")
    if raw_date in (None, ""):
        return None

    if isinstance(raw_date, datetime):
        parsed_date = raw_date.date()
    elif isinstance(raw_date, date):
        parsed_date = raw_date
    else:
        try:
            parsed_date = datetime.fromisoformat(str(raw_date).strip()).date()
        except ValueError:
            logger.warning("Could not parse schedule_date value: %r", raw_date)
            return None

    parsed_time = dt_time(hour=9, minute=0)  # sensible default: 9am local/UTC
    if raw_time not in (None, ""):
        if isinstance(raw_time, dt_time):
            parsed_time = raw_time
        elif isinstance(raw_time, datetime):
            parsed_time = raw_time.time()
        else:
            try:
                parsed_time = datetime.strptime(str(raw_time).strip(), "%H:%M").time()
            except ValueError:
                try:
                    parsed_time = datetime.strptime(str(raw_time).strip(), "%I:%M %p").time()
                except ValueError:
                    logger.warning("Could not parse schedule_time value: %r", raw_time)

    return datetime.combine(parsed_date, parsed_time)


def normalize_row(raw_row: Dict[str, Any]) -> Dict[str, Any]:
    """Maps a raw {header: value} dict (arbitrary header casing/spacing) to
    canonical field names, and parses the derived fields (bool, datetime)."""
    normalized: Dict[str, Any] = {}
    for raw_header, value in raw_row.items():
        canonical = _normalize_header(raw_header)
        if canonical:
            normalized[canonical] = value

    content_type_raw = str(normalized.get("content_type") or "short").strip().lower()
    content_type = "long_form" if content_type_raw in ("long", "long_form", "longform") else "short"

    duration_raw = normalized.get("target_duration_seconds")
    try:
        duration = int(duration_raw) if duration_raw not in (None, "") else None
    except (ValueError, TypeError):
        duration = None

    llm_provider = normalized.get("llm_provider")
    if llm_provider:
        llm_provider = str(llm_provider).strip().lower()
        if llm_provider in ("", "auto"):
            llm_provider = None
        elif llm_provider not in ("gemini", "groq", "ollama"):
            llm_provider = None  # unrecognized -> fall back to dashboard default rather than erroring the row

    upload_privacy = str(normalized.get("upload_privacy") or "private").strip().lower()
    if upload_privacy not in ("private", "unlisted", "public"):
        upload_privacy = "private"

    return {
        "topic": str(normalized.get("topic") or "").strip(),
        "content_type": content_type,
        "niche": (str(normalized["niche"]).strip() if normalized.get("niche") else None),
        "language": str(normalized.get("language") or "en").strip() or "en",
        "target_duration_seconds": duration,
        "voice": (str(normalized["voice"]).strip() if normalized.get("voice") else None),
        "music_preference": str(normalized.get("music_preference") or "auto").strip() or "auto",
        "llm_provider": llm_provider,
        "channel_label": (str(normalized["channel_label"]).strip() if normalized.get("channel_label") else None),
        "auto_upload": _coerce_bool(normalized.get("auto_upload"), default=True),
        "upload_privacy": upload_privacy,
        "scheduled_at": _coerce_datetime(normalized),
    }


def _row_hash(fields: Dict[str, Any]) -> str:
    payload = json.dumps(fields, sort_keys=True, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _resolve_channel_id(db: Session, channel_label: Optional[str]) -> Optional[str]:
    if not channel_label:
        return None
    from app.models import Channel

    match = (
        db.query(Channel)
        .filter(Channel.label.isnot(None))
        .all()
    )
    for channel in match:
        if channel.label and channel.label.strip().lower() == channel_label.strip().lower():
            return channel.id
    logger.warning("Bulk import: no connected channel matches label '%s'; leaving channel unset.", channel_label)
    return None


def parse_rows_from_xlsx_bytes(content: bytes) -> List[Dict[str, Any]]:
    from openpyxl import load_workbook

    wb = load_workbook(io.BytesIO(content), data_only=True, read_only=True)
    sheet = wb.active

    rows_iter = sheet.iter_rows(values_only=True)
    try:
        header_row = next(rows_iter)
    except StopIteration:
        raise ValueError("The uploaded file has no rows")

    headers = [str(h) if h is not None else "" for h in header_row]
    raw_rows: List[Dict[str, Any]] = []
    for row in rows_iter:
        if all(cell in (None, "") for cell in row):
            continue  # skip fully blank rows
        raw_rows.append(dict(zip(headers, row)))
    return raw_rows


def import_rows(
    db: Session,
    raw_rows: List[Dict[str, Any]],
    *,
    source: str,
    row_key_prefix: str,
) -> BulkImportResult:
    """
    Shared by Excel upload and Google Sheet sync.
    `row_key_prefix` namespaces row_key so an Excel import and a Sheet sync
    (or two different sheets) never collide on the same dedup identity.
    """
    created = 0
    skipped = 0
    errors: List[str] = []

    for index, raw_row in enumerate(raw_rows, start=1):
        row_key = f"{row_key_prefix}:{index}"
        try:
            fields = normalize_row(raw_row)
            if not fields["topic"]:
                errors.append(f"Row {index}: missing topic, skipped")
                continue

            content_hash = _row_hash(fields)
            existing = db.query(SheetImportRow).filter(SheetImportRow.row_key == row_key).first()

            if existing is not None and existing.row_hash == content_hash:
                skipped += 1
                continue

            if existing is not None and existing.job_id:
                old_job = db.get(Job, existing.job_id)
                if old_job is not None and old_job.status == JobStatus.QUEUED.value:
                    # Row was edited before the old job even started -- replace it cleanly.
                    db.delete(old_job)
                    db.flush()
                elif old_job is not None:
                    errors.append(
                        f"Row {index}: edited after job already started ({old_job.status}); "
                        "left the in-progress job untouched. Edit a new row instead if you need a redo."
                    )
                    continue

            target_duration = fields["target_duration_seconds"] or (45 if fields["content_type"] == "short" else 180)
            channel_id = _resolve_channel_id(db, fields["channel_label"])

            job = job_repository.create_job(
                db,
                topic=fields["topic"],
                content_type=fields["content_type"],
                niche=fields["niche"],
                language=fields["language"],
                target_duration_seconds=target_duration,
                voice=fields["voice"],
                music_preference=fields["music_preference"],
                llm_provider=fields["llm_provider"],
                channel_id=channel_id,
                auto_upload=fields["auto_upload"],
                upload_privacy=fields["upload_privacy"],
                scheduled_at=fields["scheduled_at"],
                source=source,
                external_ref=row_key,
                status=JobStatus.QUEUED.value,
                progress=0,
            )

            if existing is not None:
                existing.row_hash = content_hash
                existing.job_id = job.id
            else:
                db.add(SheetImportRow(source=source, row_key=row_key, row_hash=content_hash, job_id=job.id))
            db.commit()
            created += 1

        except Exception as exc:  # noqa: BLE001 - one bad row must not abort the whole batch
            logger.exception("Bulk import failed for row %s", index)
            errors.append(f"Row {index}: {exc}")
            db.rollback()

    return BulkImportResult(created_jobs=created, skipped_unchanged=skipped, errors=errors)


def import_jobs_from_xlsx_bytes(db: Session, content: bytes, *, source: str = "excel") -> BulkImportResult:
    raw_rows = parse_rows_from_xlsx_bytes(content)
    if not raw_rows:
        raise ValueError("No data rows found in the uploaded file (only a header row, or the file is empty)")
    return import_rows(db, raw_rows, source=source, row_key_prefix="excel")


def build_template_xlsx_bytes() -> bytes:
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "Videos"
    ws.append(_TEMPLATE_HEADERS)
    for row in _TEMPLATE_EXAMPLE_ROWS:
        ws.append(row)

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()

