"""
Research layer (spec section 12).

V1 ships with two real, working research sources:
  1. User-supplied research text (passed in on the job / project) -- always
     available, zero configuration.
  2. An optional web-search provider (Serper.dev's Google Search API),
     used ONLY if SERPER_API_KEY is set in .env.

Design note: research is explicitly a provider-abstracted, optional step.
If no research source is configured/enabled, the pipeline proceeds WITHOUT
inventing research -- the script generation prompt simply omits the
research block, and the LLM is instructed to avoid presenting invented
facts as researched facts. This is the honest behavior per spec: we do not
fabricate "researched" content to make the feature look more complete than
it is.

To add another search backend later (e.g. Bing, SerpAPI, a local search
index), implement `_fetch_via_<provider>` and select it in `gather_research`
based on configuration -- no other file needs to change.
"""
from __future__ import annotations

import logging
from typing import Optional

import httpx

from app.config import Settings

logger = logging.getLogger("ytagent")


class ResearchService:
    def __init__(self, settings: Settings):
        self._settings = settings
        self._serper_key: Optional[str] = getattr(settings, "SERPER_API_KEY", None)

    def gather_research(self, topic: str, user_notes: Optional[str] = None) -> Optional[str]:
        parts: list[str] = []
        if user_notes:
            parts.append(f"User-provided notes:\n{user_notes.strip()}")

        web_context = self._search_web(topic)
        if web_context:
            parts.append(f"Web search summary (verify before treating as fact):\n{web_context}")

        if not parts:
            return None
        return "\n\n".join(parts)

    def _search_web(self, topic: str) -> Optional[str]:
        if not self._serper_key:
            logger.info("No SERPER_API_KEY configured; skipping automated web research for topic '%s'.", topic)
            return None
        try:
            resp = httpx.post(
                "https://google.serper.dev/search",
                headers={"X-API-KEY": self._serper_key, "Content-Type": "application/json"},
                json={"q": topic, "num": 5},
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            snippets = []
            for item in data.get("organic", [])[:5]:
                title = item.get("title", "")
                snippet = item.get("snippet", "")
                if title or snippet:
                    snippets.append(f"- {title}: {snippet}")
            return "\n".join(snippets) if snippets else None
        except Exception as exc:
            logger.warning("Web research request failed for '%s': %s (continuing without it)", topic, exc)
            return None
