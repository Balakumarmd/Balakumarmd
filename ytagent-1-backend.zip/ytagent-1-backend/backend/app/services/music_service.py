"""
Resolves a background music file from the user's local music library
(spec section 21). Never downloads music automatically -- the user drops
royalty-free files into DATA_DIR/music/ themselves.
"""
from __future__ import annotations

import random
from pathlib import Path
from typing import Optional

_SUPPORTED_EXTENSIONS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}


def resolve_music_path(music_dir: Path, preference: Optional[str]) -> Optional[Path]:
    """
    preference:
      - "none"       -> no music
      - "auto" / None -> pick a random track from the music library, if any exist
      - "<filename>" -> use that specific file if it exists in the music library
    """
    if preference == "none":
        return None

    if preference and preference not in ("auto", "none"):
        candidate = music_dir / preference
        if candidate.exists() and candidate.suffix.lower() in _SUPPORTED_EXTENSIONS:
            return candidate
        return None  # explicitly requested file not found -> render without music, not an error

    tracks = [p for p in music_dir.glob("*") if p.suffix.lower() in _SUPPORTED_EXTENSIONS]
    if not tracks:
        return None
    return random.choice(tracks)
