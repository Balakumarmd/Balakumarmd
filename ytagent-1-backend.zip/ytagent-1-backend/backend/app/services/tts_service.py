"""
Generates narration audio for a job using the configured TTSProvider and
verifies the result (file exists, non-empty, has a measurable duration).
"""
from __future__ import annotations

import logging
from pathlib import Path

from app.providers.base import TTSProvider
from app.utils.ffmpeg_utils import get_media_duration

logger = logging.getLogger("ytagent")


class TTSGenerationError(Exception):
    pass


class TTSService:
    def __init__(self, provider: TTSProvider):
        self._provider = provider

    def generate_narration(self, text: str, output_path: Path, voice: str | None = None) -> tuple[Path, float]:
        if not text or not text.strip():
            raise TTSGenerationError("Cannot synthesize empty narration text")

        path = self._provider.synthesize(text, output_path, voice=voice)

        if not path.exists() or path.stat().st_size == 0:
            raise TTSGenerationError(f"TTS provider did not produce a valid audio file at {path}")

        duration = get_media_duration(path)
        if duration is None or duration <= 0:
            raise TTSGenerationError(f"Generated audio at {path} has no measurable duration")

        logger.info("Narration audio generated: %s (%.2fs)", path, duration)
        return path, duration
