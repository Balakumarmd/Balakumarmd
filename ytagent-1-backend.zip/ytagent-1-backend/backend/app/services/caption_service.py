"""
Builds a dynamic, word-level-highlighted caption track (.ass subtitle file)
from a Transcript, for burning into the final video with ffmpeg's
`subtitles` filter (which uses libass).

Uses ASS karaoke tags (\\k) so each word's highlight timing matches the
actual Whisper word timestamps -- this is what gives "TikTok-style"
current-word highlighting, not just static per-sentence subtitles.

Caption style (font, size, colors, margins, words-per-group) is fully
configurable via CaptionStyle instead of being hardcoded, per spec
section 20.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from app.schemas.schemas import TranscriptWord


@dataclass
class CaptionStyle:
    font_name: str = "Arial"
    font_size: int = 72
    primary_color_bgr: str = "&H00FFFFFF"   # white (unhighlighted word) - BGR hex
    highlight_color_bgr: str = "&H0000D7FF"  # amber/gold highlight
    outline_color_bgr: str = "&H00000000"    # black outline
    back_color_bgr: str = "&H64000000"       # semi-transparent box
    bold: bool = True
    outline_width: int = 4
    shadow: int = 0
    # alignment: ASS numpad alignment (2 = bottom-center)
    alignment: int = 2
    margin_l: int = 60
    margin_r: int = 60
    margin_v: int = 220  # distance from bottom/top edge, keeps captions in the "safe zone"
    max_words_per_group: int = 4
    max_chars_per_group: int = 26


def _sec_to_ass_time(t: float) -> str:
    if t < 0:
        t = 0
    hours = int(t // 3600)
    minutes = int((t % 3600) // 60)
    seconds = int(t % 60)
    centiseconds = int(round((t - int(t)) * 100))
    if centiseconds == 100:
        centiseconds = 0
        seconds += 1
    return f"{hours:01d}:{minutes:02d}:{seconds:02d}.{centiseconds:02d}"


def group_words(words: List[TranscriptWord], style: CaptionStyle) -> List[List[TranscriptWord]]:
    groups: List[List[TranscriptWord]] = []
    current: List[TranscriptWord] = []
    current_len = 0
    for w in words:
        word_text = w.word.strip()
        if not word_text:
            continue
        projected_len = current_len + len(word_text) + 1
        if current and (
            len(current) >= style.max_words_per_group or projected_len > style.max_chars_per_group
        ):
            groups.append(current)
            current = []
            current_len = 0
        current.append(w)
        current_len += len(word_text) + 1
    if current:
        groups.append(current)
    return groups


def _escape_ass_text(text: str) -> str:
    return text.replace("{", "(").replace("}", ")")


def build_ass_content(
    words: List[TranscriptWord],
    style: CaptionStyle,
    video_width: int,
    video_height: int,
) -> str:
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {video_width}
PlayResY: {video_height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{style.font_name},{style.font_size},{style.primary_color_bgr},{style.highlight_color_bgr},{style.outline_color_bgr},{style.back_color_bgr},{-1 if style.bold else 0},0,0,0,100,100,0,0,1,{style.outline_width},{style.shadow},{style.alignment},{style.margin_l},{style.margin_r},{style.margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = [header]
    groups = group_words(words, style)

    for group in groups:
        if not group:
            continue
        group_start = group[0].start
        group_end = group[-1].end
        karaoke_parts = []
        for w in group:
            duration_cs = max(1, int(round((w.end - w.start) * 100)))
            karaoke_parts.append(f"{{\\k{duration_cs}}}{_escape_ass_text(w.word.strip())}")
        text = " ".join(karaoke_parts)
        line = f"Dialogue: 0,{_sec_to_ass_time(group_start)},{_sec_to_ass_time(group_end)},Default,,0,0,0,,{text}\n"
        lines.append(line)

    return "".join(lines)


class CaptionService:
    def generate_caption_file(
        self,
        words: List[TranscriptWord],
        output_ass_path: Path,
        video_width: int,
        video_height: int,
        style: CaptionStyle | None = None,
    ) -> Path:
        style = style or CaptionStyle()
        content = build_ass_content(words, style, video_width, video_height)
        output_ass_path.parent.mkdir(parents=True, exist_ok=True)
        output_ass_path.write_text(content, encoding="utf-8")
        if not output_ass_path.exists() or output_ass_path.stat().st_size == 0:
            raise RuntimeError(f"Failed to write caption file at {output_ass_path}")
        return output_ass_path
