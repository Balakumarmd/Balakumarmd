"""
Turns a topic + parameters into a structured, validated GeneratedScript
using the configured LLM provider.

Reliability strategy:
  1. Ask the model for JSON only, with an explicit schema description.
  2. Try to parse/repair the JSON.
  3. Validate against the GeneratedScript Pydantic schema.
  4. For Shorts, ensure the hook is not repeated in scene narration.
  5. If invalid, re-prompt once with the validation error appended.
  6. If it still fails, raise a clear, typed error.
"""
from __future__ import annotations

import logging
import re

from pydantic import ValidationError

from app.providers.base import LLMProvider
from app.schemas.schemas import GeneratedScript
from app.utils.json_repair import safe_parse_json

logger = logging.getLogger("ytagent")

_SYSTEM_PROMPT = (
    "You are a professional video scriptwriter. You ALWAYS respond with a single "
    "valid JSON object and nothing else -- no markdown fences, no commentary, "
    "no explanations before or after the JSON."
)

_SCHEMA_DESCRIPTION = """
You MUST return a JSON object matching this schema exactly.

IMPORTANT:
- Use the EXACT field names shown below.
- Do NOT rename fields.
- Do NOT use "content" anywhere. Use "narration".
- Every scene MUST contain scene_number, narration, visual_query, and duration.
- The top-level object MUST contain title, hook, scenes, outro, cta, and estimated_duration.
- Return ONLY JSON. No markdown. No explanation.

EXACT JSON STRUCTURE:

{
  "title": "Short video title",
  "hook": "Spoken hook for the first few seconds",
  "scenes": [
    {
      "scene_number": 1,
      "narration": "What the narrator says in this scene",
      "visual_query": "Concrete visual search phrase",
      "duration": 5.0
    },
    {
      "scene_number": 2,
      "narration": "What the narrator says in this scene",
      "visual_query": "Concrete visual search phrase",
      "duration": 5.0
    }
  ],
  "outro": "Short closing line",
  "cta": "Short call to action",
  "estimated_duration": 10.0
}

RULES:
1. scenes must be a JSON array.
2. scene_number must be an integer starting at 1 and increasing by 1.
3. narration must contain the spoken narration.
4. visual_query must be a concrete stock-footage search phrase.
5. duration must be a number representing seconds.
6. Do not use "content" as a field name.
7. Do not omit any required field.
8. estimated_duration must be the approximate total video duration.
9. The scene durations should approximately match the requested target duration.
10. For Shorts, use 4-8 scenes.
11. narration must be natural spoken English.
12. Do not include stage directions, emojis, hashtags, or markdown.
13. Do not include any text before or after the JSON.

SHORTS HOOK RULE — VERY IMPORTANT:
14. The "hook" is spoken separately at the very beginning of the video.
15. Scene 1 narration MUST NOT repeat the hook.
16. Scene 1 must continue naturally from the hook with new information.
17. Never copy the hook sentence, or a near-identical version of it, into scene 1.
18. Do not begin scene 1 with phrases such as "As I said", "As mentioned", or a repeated version of the hook.
19. The hook must be spoken EXACTLY ONCE in the entire Short.
20. The scenes contain narration AFTER the hook, not narration including the hook.
"""

_SHORT_HOOK_REPEAT_THRESHOLD = 0.72


class ScriptGenerationError(Exception):
    pass


class ScriptService:
    def __init__(self, llm: LLMProvider):
        self._llm = llm

    @staticmethod
    def _normalize_text(text: str) -> str:
        """Normalize text for safe comparison."""
        text = (text or "").lower()
        text = re.sub(r"[^a-z0-9\s]", " ", text)
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    @classmethod
    def _hook_is_repeated(cls, hook: str, narration: str) -> bool:
        """
        Detect whether narration contains the hook or a near-identical
        version of the hook.

        We intentionally use token comparison instead of exact string
        matching because the model may change punctuation or capitalization.
        """
        hook_normalized = cls._normalize_text(hook)
        narration_normalized = cls._normalize_text(narration)

        if not hook_normalized or not narration_normalized:
            return False

        # Exact containment catches the common case.
        if hook_normalized in narration_normalized:
            return True

        hook_words = hook_normalized.split()

        # Very short hooks are not reliable candidates for fuzzy matching.
        if len(hook_words) < 5:
            return False

        # Compare the beginning of scene 1 against the hook.
        narration_words = narration_normalized.split()
        window_size = min(len(hook_words), len(narration_words))

        if window_size < 5:
            return False

        first_window = narration_words[:window_size]

        matching_words = sum(
            1
            for hook_word, narration_word in zip(hook_words, first_window)
            if hook_word == narration_word
        )

        similarity = matching_words / window_size

        return similarity >= _SHORT_HOOK_REPEAT_THRESHOLD

    @classmethod
    def _remove_repeated_hook(
        cls,
        script: GeneratedScript,
        content_type: str,
    ) -> GeneratedScript:
        """
        Safety cleanup for Shorts.

        If scene 1 starts by repeating the hook, remove the repeated hook
        from scene 1 narration. If the entire scene is only the hook,
        replace it with a short continuation rather than producing duplicate
        audio.
        """
        if content_type != "short":
            return script

        if not script.scenes:
            return script

        hook = script.hook.strip()
        first_scene = script.scenes[0]
        narration = first_scene.narration.strip()

        if not cls._hook_is_repeated(hook, narration):
            return script

        logger.warning(
            "Detected repeated Shorts hook in scene 1; removing duplicate."
        )

        normalized_hook = cls._normalize_text(hook)
        normalized_narration = cls._normalize_text(narration)

        # If the whole scene is essentially the hook, don't leave the
        # narrator with no useful text.
        if normalized_narration == normalized_hook:
            first_scene.narration = (
                "Let's break down what makes this so useful."
            )
            return script

        # Remove the exact hook when possible, preserving the rest of the
        # model-generated narration.
        if hook in narration:
            cleaned = narration.replace(hook, "", 1).strip()
        else:
            # For punctuation/capitalization variations, remove the matching
            # leading portion using word count.
            hook_word_count = len(normalized_hook.split())
            words = narration.split()

            if len(words) > hook_word_count:
                cleaned = " ".join(words[hook_word_count:]).strip()
            else:
                cleaned = ""

        # If cleanup accidentally removes everything, use a safe continuation.
        if not cleaned:
            cleaned = "Let's break down the key points."

        first_scene.narration = cleaned

        return script

    def _build_prompt(
        self,
        topic: str,
        content_type: str,
        niche: str | None,
        target_duration_seconds: int,
        research_context: str | None,
    ) -> str:
        pacing_guidance = (
            "This is a YouTube SHORT: prioritize a strong first-3-second hook, "
            "fast pacing, punchy short sentences, high retention, and a clear ending. "
            "Use 4-8 short scenes. "
            "The hook is spoken separately before scene 1. "
            "Therefore scene 1 MUST start with NEW information and MUST NOT repeat "
            "the hook."
            if content_type == "short"
            else "This is a LONG-FORM video: include a clear introduction, "
            "problem/context, main points with examples, and a conclusion. "
            "Use as many scenes as needed for good pacing."
        )

        niche_line = f"Niche/category: {niche}\n" if niche else ""

        research_block = (
            f"\nResearch context (use only verified facts from here; "
            f"do not invent facts):\n{research_context}\n"
            if research_context
            else ""
        )

        return (
            f"Topic: {topic}\n"
            f"{niche_line}"
            f"Target total spoken duration: approximately "
            f"{target_duration_seconds} seconds.\n"
            f"{pacing_guidance}\n"
            f"{research_block}\n"
            f"{_SCHEMA_DESCRIPTION}"
        )

    def _validate_and_cleanup(
        self,
        raw_or_data,
        *,
        content_type: str,
    ) -> GeneratedScript:
        if isinstance(raw_or_data, GeneratedScript):
            script = raw_or_data
        else:
            data = safe_parse_json(raw_or_data)
            script = GeneratedScript.model_validate(data)

        return self._remove_repeated_hook(script, content_type)

    def generate_script(
        self,
        *,
        topic: str,
        content_type: str,
        niche: str | None,
        target_duration_seconds: int,
        research_context: str | None = None,
    ) -> GeneratedScript:
        prompt = self._build_prompt(
            topic,
            content_type,
            niche,
            target_duration_seconds,
            research_context,
        )

        # Providers with native structured script generation.
        if hasattr(self._llm, "generate_script"):
            try:
                script = self._llm.generate_script(
                    prompt,
                    system=_SYSTEM_PROMPT,
                )

                return self._validate_and_cleanup(
                    script,
                    content_type=content_type,
                )

            except Exception as exc:
                logger.warning(
                    "Structured LLM script generation failed: %s",
                    exc,
                )
                raise ScriptGenerationError(
                    f"Structured script generation failed: {exc}"
                ) from exc

        # Fallback for providers without native structured output.
        last_error: Exception | None = None

        for attempt in range(1, 3):
            raw = self._llm.generate(
                prompt,
                system=_SYSTEM_PROMPT,
                temperature=0.2,
            )

            try:
                return self._validate_and_cleanup(
                    raw,
                    content_type=content_type,
                )

            except (ValueError, ValidationError) as exc:
                last_error = exc

                logger.warning(
                    "Script generation attempt %s produced invalid output: %s",
                    attempt,
                    exc,
                )

                prompt = (
                    prompt
                    + f"\n\nYour previous response was invalid JSON or did not "
                    f"match the schema (error: {exc}). "
                    f"Respond again with ONLY the corrected JSON object."
                )

        raise ScriptGenerationError(
            f"LLM failed to produce a valid script after retries. "
            f"Last error: {last_error}"
        )