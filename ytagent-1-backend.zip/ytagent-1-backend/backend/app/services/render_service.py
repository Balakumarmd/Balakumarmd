"""
The FFmpeg-based rendering engine (spec sections 17-21).

Pipeline (all real ffmpeg subprocess calls, no MoviePy):
  1. Normalize each scene's raw asset (video or photo) into a clip of the
     exact target resolution and exact scene duration -- videos are
     scaled+cropped to cover the frame and looped/trimmed to length;
     photos get a subtle Ken-Burns zoom/pan so a still image still feels
     like "video".
  2. Concatenate the normalized scene clips into one silent visual track.
  3. Compose the final video: mux narration audio (+ optional ducked,
     looped background music) under the visual track, burn the dynamic
     word-level captions (.ass) on top, encode H.264/AAC, and trim to the
     narration's real duration so audio/video/captions all end together.

Scene durations from the LLM-authored script are proportionally rescaled
to match the *actual* measured narration audio duration (TTS timing is
never identical to the script's estimate), so the visual track and the
narration always match exactly. Caption timing is NOT rescaled -- it comes
directly from real Whisper word timestamps measured on the real audio, so
it is always accurate regardless of any scene-duration adjustment.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from app.schemas.schemas import MediaAsset, Scene
from app.utils.ffmpeg_utils import FFmpegError, get_media_duration, run_ffmpeg

logger = logging.getLogger("ytagent")

_FPS = 30


@dataclass
class RenderConfig:
    width: int
    height: int
    fps: int = _FPS
    video_bitrate_crf: int = 20
    audio_bitrate: str = "192k"
    music_volume: float = 0.12
    narration_volume: float = 1.0


SHORT_RENDER_CONFIG = RenderConfig(width=1080, height=1920)
LONGFORM_RENDER_CONFIG = RenderConfig(width=1920, height=1080)


class RenderError(Exception):
    pass


def get_render_config(content_type: str) -> RenderConfig:
    return SHORT_RENDER_CONFIG if content_type == "short" else LONGFORM_RENDER_CONFIG


def rescale_scene_durations(scenes: List[Scene], actual_audio_duration: float) -> List[Scene]:
    total_planned = sum(s.duration for s in scenes) or 1.0
    factor = actual_audio_duration / total_planned
    rescaled = []
    for s in scenes:
        new_duration = max(0.5, s.duration * factor)
        rescaled.append(Scene(scene_number=s.scene_number, narration=s.narration, visual_query=s.visual_query, duration=new_duration))
    return rescaled


class RenderService:
    def __init__(self, config: RenderConfig):
        self._cfg = config

    # ------------------------------------------------------------------
    def _normalize_scene_clip(self, asset: MediaAsset, duration: float, output_path: Path) -> Path:
        w, h = self._cfg.width, self._cfg.height
        if asset.asset_type == "video":
            vf = f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},fps={self._cfg.fps},setsar=1"
            args = [
                "-stream_loop", "-1",
                "-i", asset.local_path,
                "-t", f"{duration:.3f}",
                "-vf", vf,
                "-an",
                "-c:v", "libx264",
                "-preset", "veryfast",
                "-pix_fmt", "yuv420p",
                str(output_path),
            ]
        else:  # photo: Ken Burns style slow zoom/pan so a still frame reads as motion
            oversample_w, oversample_h = w * 2, h * 2
            total_frames = max(1, int(duration * self._cfg.fps))
            zoom_expr = f"zoompan=z='min(zoom+0.0006,1.12)':d={total_frames}:s={w}x{h}:fps={self._cfg.fps}"
            vf = (
                f"scale={oversample_w}:{oversample_h}:force_original_aspect_ratio=increase,"
                f"crop={oversample_w}:{oversample_h},{zoom_expr},setsar=1"
            )
            args = [
                "-loop", "1",
                "-i", asset.local_path,
                "-t", f"{duration:.3f}",
                "-vf", vf,
                "-an",
                "-c:v", "libx264",
                "-preset", "veryfast",
                "-pix_fmt", "yuv420p",
                str(output_path),
            ]
        try:
            run_ffmpeg(args)
        except FFmpegError as exc:
            raise RenderError(f"Failed to normalize scene clip for asset {asset.local_path}: {exc}") from exc
        return output_path

    # ------------------------------------------------------------------
    def _concat_scene_clips(self, clip_paths: List[Path], concat_list_path: Path, output_path: Path) -> Path:
        lines = [f"file '{p.as_posix()}'" for p in clip_paths]
        concat_list_path.write_text("\n".join(lines), encoding="utf-8")
        args = ["-f", "concat", "-safe", "0", "-i", str(concat_list_path), "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", str(output_path)]
        try:
            run_ffmpeg(args)
        except FFmpegError as exc:
            raise RenderError(f"Failed to concatenate scene clips: {exc}") from exc
        return output_path

    # ------------------------------------------------------------------
    def _compose_final(
        self,
        visual_track_path: Path,
        narration_audio_path: Path,
        captions_ass_path: Path,
        final_output_path: Path,
        target_duration: float,
        music_path: Optional[Path] = None,
    ) -> Path:
        ass_escaped = str(captions_ass_path).replace("\\", "/").replace(":", "\\:")
        inputs = ["-i", str(visual_track_path), "-i", str(narration_audio_path)]

        if music_path is not None and music_path.exists():
            inputs += ["-stream_loop", "-1", "-i", str(music_path)]
            filter_complex = (
                f"[1:a]volume={self._cfg.narration_volume}[narr];"
                f"[2:a]atrim=0:{target_duration:.3f},volume={self._cfg.music_volume}[music];"
                f"[narr][music]amix=inputs=2:duration=first:dropout_transition=2[aout];"
                f"[0:v]subtitles='{ass_escaped}'[vout]"
            )
        else:
            filter_complex = (
                f"[1:a]volume={self._cfg.narration_volume}[aout];"
                f"[0:v]subtitles='{ass_escaped}'[vout]"
            )

        args = [
            *inputs,
            "-filter_complex", filter_complex,
            "-map", "[vout]",
            "-map", "[aout]",
            "-t", f"{target_duration:.3f}",
            "-c:v", "libx264",
            "-crf", str(self._cfg.video_bitrate_crf),
            "-preset", "medium",
            "-pix_fmt", "yuv420p",
            "-c:a", "aac",
            "-b:a", self._cfg.audio_bitrate,
            "-movflags", "+faststart",
            str(final_output_path),
        ]
        try:
            run_ffmpeg(args, timeout=3600)
        except FFmpegError as exc:
            raise RenderError(f"Final composition failed: {exc}") from exc

        if not final_output_path.exists() or final_output_path.stat().st_size == 0:
            raise RenderError("Final render produced an empty or missing file")
        return final_output_path

    # ------------------------------------------------------------------
    def render(
        self,
        scenes: List[Scene],
        assets: List[MediaAsset],
        narration_audio_path: Path,
        captions_ass_path: Path,
        output_dir: Path,
        final_output_path: Path,
        music_path: Optional[Path] = None,
    ) -> Path:
        audio_duration = get_media_duration(narration_audio_path)
        if not audio_duration or audio_duration <= 0:
            raise RenderError(f"Could not determine narration audio duration for {narration_audio_path}")

        rescaled_scenes = rescale_scene_durations(scenes, audio_duration)
        assets_by_scene = {a.scene_number: a for a in assets}

        clip_paths: List[Path] = []
        for scene in rescaled_scenes:
            asset = assets_by_scene.get(scene.scene_number)
            if asset is None:
                raise RenderError(f"No visual asset available for scene {scene.scene_number}")
            clip_path = output_dir / f"normalized_scene_{scene.scene_number}.mp4"
            self._normalize_scene_clip(asset, scene.duration, clip_path)
            clip_paths.append(clip_path)

        visual_track_path = output_dir / "visual_track.mp4"
        concat_list_path = output_dir / "concat_list.txt"
        self._concat_scene_clips(clip_paths, concat_list_path, visual_track_path)

        self._compose_final(
            visual_track_path,
            narration_audio_path,
            captions_ass_path,
            final_output_path,
            target_duration=audio_duration,
            music_path=music_path,
        )

        # Clean up intermediate per-scene clips to save disk space; keep visual_track.mp4
        # and the final output for debugging/review.
        for p in clip_paths:
            try:
                p.unlink(missing_ok=True)
            except OSError:
                pass

        return final_output_path
