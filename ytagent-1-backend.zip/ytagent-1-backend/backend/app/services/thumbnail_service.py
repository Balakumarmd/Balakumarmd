"""
Generates a real thumbnail image (spec section 22):
  1. Extract a representative frame from the rendered video via ffmpeg.
  2. Overlay the video title with a readable, high-contrast text treatment
     using Pillow (no paid image-generation API required).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Tuple

from PIL import Image, ImageDraw, ImageFont

from app.utils.ffmpeg_utils import FFmpegError, get_media_duration, run_ffmpeg

logger = logging.getLogger("ytagent")

_THUMBNAIL_WIDTH = 1280
_THUMBNAIL_HEIGHT = 720


class ThumbnailError(Exception):
    pass


def _extract_frame(video_path: Path, frame_output_path: Path) -> Path:
    duration = get_media_duration(video_path) or 1.0
    grab_time = min(1.0, duration * 0.3)
    args = ["-ss", f"{grab_time:.2f}", "-i", str(video_path), "-frames:v", "1", "-q:v", "2", str(frame_output_path)]
    try:
        run_ffmpeg(args)
    except FFmpegError as exc:
        raise ThumbnailError(f"Could not extract a frame from {video_path}: {exc}") from exc
    if not frame_output_path.exists() or frame_output_path.stat().st_size == 0:
        raise ThumbnailError("Frame extraction produced an empty file")
    return frame_output_path


def _load_font(size: int) -> ImageFont.FreeTypeFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "arialbd.ttf",
        "Arial Bold.ttf",
    ]
    for c in candidates:
        try:
            return ImageFont.truetype(c, size)
        except Exception:
            continue
    return ImageFont.load_default()


def _wrap_text(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        trial = f"{current} {word}".strip()
        bbox = draw.textbbox((0, 0), trial, font=font)
        if bbox[2] - bbox[0] <= max_width or not current:
            current = trial
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


class ThumbnailService:
    def generate(self, video_path: Path, title: str, output_path: Path) -> Path:
        frame_path = video_path.parent / "_thumb_frame.jpg"
        _extract_frame(video_path, frame_path)

        img = Image.open(frame_path).convert("RGB")
        img = img.resize((_THUMBNAIL_WIDTH, _THUMBNAIL_HEIGHT), Image.LANCZOS)

        # Darken the lower third so white title text stays legible regardless
        # of the underlying frame's brightness.
        overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
        draw_overlay = ImageDraw.Draw(overlay)
        band_top = int(_THUMBNAIL_HEIGHT * 0.58)
        draw_overlay.rectangle([0, band_top, _THUMBNAIL_WIDTH, _THUMBNAIL_HEIGHT], fill=(0, 0, 0, 150))
        img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")

        draw = ImageDraw.Draw(img)
        font = _load_font(72)
        max_text_width = int(_THUMBNAIL_WIDTH * 0.92)
        lines = _wrap_text(draw, title.upper(), font, max_text_width)[:3]

        line_height = font.size + 14
        total_text_height = line_height * len(lines)
        y = _THUMBNAIL_HEIGHT - total_text_height - 40

        for line in lines:
            bbox = draw.textbbox((0, 0), line, font=font)
            x = (_THUMBNAIL_WIDTH - (bbox[2] - bbox[0])) // 2
            # Outline for readability against any background.
            for dx, dy in [(-3, -3), (3, -3), (-3, 3), (3, 3), (0, 0)]:
                fill = (0, 0, 0) if (dx, dy) != (0, 0) else (255, 255, 255)
                draw.text((x + dx, y + dy), line, font=font, fill=fill)
            y += line_height

        output_path.parent.mkdir(parents=True, exist_ok=True)
        img.save(output_path, "PNG")

        try:
            frame_path.unlink(missing_ok=True)
        except OSError:
            pass

        if not output_path.exists() or output_path.stat().st_size == 0:
            raise ThumbnailError("Thumbnail generation produced an empty file")
        return output_path
