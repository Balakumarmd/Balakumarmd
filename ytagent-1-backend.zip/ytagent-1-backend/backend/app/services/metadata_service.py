"""
Generates YouTube title/description/tags via the LLM, validated against a
strict schema (spec section 23). Makes no SEO/virality guarantees.
"""
from __future__ import annotations

import logging

from pydantic import ValidationError

from app.providers.base import LLMProvider
from app.schemas.schemas import GeneratedScript, YouTubeMetadata
from app.utils.json_repair import safe_parse_json

logger = logging.getLogger("ytagent")

_SYSTEM_PROMPT = (
    "You write accurate, non-clickbait YouTube metadata. You ALWAYS respond with a "
    "single valid JSON object and nothing else."
)


class MetadataGenerationError(Exception):
    pass


class MetadataService:
    def __init__(self, llm: LLMProvider):
        self._llm = llm

    def generate_metadata(self, script: GeneratedScript, content_type: str, niche: str | None) -> YouTubeMetadata:
        prompt = f"""
Video topic/title idea: {script.title}
Content type: {"YouTube Short" if content_type == "short" else "Long-form YouTube video"}
Niche: {niche or "general"}
Script summary (hook): {script.hook}

Respond with a single JSON object with EXACTLY this shape:
{{
  "title": "<accurate, compelling YouTube title, under 100 characters, no clickbait false claims>",
  "description": "<2-4 sentence accurate description of the video content, under 1000 characters>",
  "tags": ["<5 to 12 relevant lowercase keyword tags>"],
  "category_id": "27",
  "hashtags": ["<2-4 relevant hashtags including the # symbol>"]
}}
Do not include any text outside the JSON object. Do not claim the video will go viral or guarantee views/subscribers.
"""
        last_error: Exception | None = None
        for attempt in range(1, 3):
            raw = self._llm.generate(prompt, system=_SYSTEM_PROMPT, temperature=0.6)
            try:
                data = safe_parse_json(raw)
                return YouTubeMetadata.model_validate(data)
            except (ValueError, ValidationError) as exc:
                last_error = exc
                logger.warning("Metadata generation attempt %s invalid: %s", attempt, exc)
                prompt += f"\n\nYour previous response was invalid (error: {exc}). Respond again with ONLY corrected JSON."
        raise MetadataGenerationError(f"LLM failed to produce valid metadata after retries: {last_error}")
