"""
Manages the on-disk workspace for a single job:

data/jobs/<job_id>/
    script.json
    narration.txt
    audio.wav
    transcript.json
    media/
    captions/
    thumbnail.png
    metadata.json
    final.mp4
    logs/
"""
from __future__ import annotations

from pathlib import Path

from app.config import Settings
from app.utils.security import safe_join


class JobWorkspace:
    def __init__(self, settings: Settings, job_id: str):
        self.job_id = job_id
        self.root = safe_join(settings.jobs_dir, job_id)
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "media").mkdir(exist_ok=True)
        (self.root / "captions").mkdir(exist_ok=True)
        (self.root / "logs").mkdir(exist_ok=True)

    @property
    def script_path(self) -> Path:
        return self.root / "script.json"

    @property
    def narration_text_path(self) -> Path:
        return self.root / "narration.txt"

    @property
    def audio_path(self) -> Path:
        return self.root / "audio.wav"

    @property
    def transcript_path(self) -> Path:
        return self.root / "transcript.json"

    @property
    def media_dir(self) -> Path:
        return self.root / "media"

    @property
    def captions_dir(self) -> Path:
        return self.root / "captions"

    @property
    def captions_ass_path(self) -> Path:
        return self.captions_dir / "captions.ass"

    @property
    def thumbnail_path(self) -> Path:
        return self.root / "thumbnail.png"

    @property
    def metadata_path(self) -> Path:
        return self.root / "metadata.json"

    @property
    def final_video_path(self) -> Path:
        return self.root / "final.mp4"

    @property
    def concat_list_path(self) -> Path:
        return self.root / "concat_list.txt"

    @property
    def logs_dir(self) -> Path:
        return self.root / "logs"
