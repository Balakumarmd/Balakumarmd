"""
Finds, downloads, and validates visual assets for each scene in a script,
using the configured MediaProvider (Pexels by default).

Failure handling (spec section 15/16):
  - if a search for a scene's query returns nothing, we retry with a
    simplified/broadened query (drop adjectives, use the first few words)
  - if a specific asset fails to download or fails validation, we try the
    next candidate result for that scene
  - only if ALL candidates for a scene fail do we raise, and we raise a
    clear, scene-specific error rather than silently skipping the scene
    (a silently-skipped scene would produce a broken/short video without
    the user ever knowing why)
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List

from app.providers.base import MediaProvider, MediaSearchResult
from app.schemas.schemas import MediaAsset, Scene
from app.utils.ffmpeg_utils import FFmpegError, ffprobe_json, get_media_duration
from app.utils.security import safe_filename

logger = logging.getLogger("ytagent")


class MediaAcquisitionError(Exception):
    pass


class MediaService:
    def __init__(self, provider: MediaProvider):
        self._provider = provider

    def _validate_file(self, path: Path) -> bool:
        if not path.exists() or path.stat().st_size == 0:
            return False
        try:
            info = ffprobe_json(path)
            streams = info.get("streams", [])
            return len(streams) > 0
        except FFmpegError as exc:
            logger.warning("Media validation failed for %s: %s", path, exc)
            return False

    def _broaden_query(self, query: str) -> str:
        words = query.split()
        return " ".join(words[:2]) if len(words) > 2 else query

    def acquire_assets_for_scenes(
        self, scenes: List[Scene], media_dir: Path, orientation: str = "portrait"
    ) -> List[MediaAsset]:
        assets: List[MediaAsset] = []
        for scene in scenes:
            asset = self._acquire_for_scene(scene, media_dir, orientation)
            assets.append(asset)
        return assets

    def _acquire_for_scene(self, scene: Scene, media_dir: Path, orientation: str) -> MediaAsset:
        queries_to_try = [scene.visual_query, self._broaden_query(scene.visual_query), "abstract background"]
        last_error: Exception | None = None

        for query in queries_to_try:
            try:
                results: List[MediaSearchResult] = self._provider.search(query, orientation=orientation, per_page=5)
            except Exception as exc:
                last_error = exc
                logger.warning("Media search failed for scene %s query '%s': %s", scene.scene_number, query, exc)
                continue

            for result in results:
                ext = "mp4" if result.asset_type == "video" else "jpg"
                filename = safe_filename(f"scene_{scene.scene_number}_{result.source_id}") + f".{ext}"
                dest = media_dir / filename
                try:
                    self._provider.download(result, dest)
                except Exception as exc:
                    last_error = exc
                    logger.warning("Download failed for scene %s asset %s: %s", scene.scene_number, result.source_id, exc)
                    continue

                if not self._validate_file(dest):
                    logger.warning("Downloaded asset failed validation for scene %s: %s", scene.scene_number, dest)
                    try:
                        dest.unlink(missing_ok=True)
                    except OSError:
                        pass
                    continue

                duration = get_media_duration(dest) if result.asset_type == "video" else None
                return MediaAsset(
                    scene_number=scene.scene_number,
                    source="pexels",
                    asset_type=result.asset_type,
                    source_id=result.source_id,
                    source_url=result.url,
                    local_path=str(dest),
                    width=result.width,
                    height=result.height,
                    duration=duration,
                )

        raise MediaAcquisitionError(
            f"Could not find any usable visual asset for scene {scene.scene_number} "
            f"(query: '{scene.visual_query}'). Last error: {last_error}"
        )
