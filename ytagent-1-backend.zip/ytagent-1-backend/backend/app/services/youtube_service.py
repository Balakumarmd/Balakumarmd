"""
Thin orchestration around the YouTubeProvider: persists OAuth tokens to the
`channels` table and exposes connect/status/upload operations to the API
and worker layers.

Multi-channel: each OAuth connection creates its OWN Channel row (rather
than overwriting a single "the" channel), so a person running several
channels can connect all of them and pick which one a given job uploads
to. `is_default` marks which channel pre-fills in the Create Video form;
every job can still override it via `channel_id`.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from sqlalchemy.orm import Session

from app.config import Settings
from app.models import Channel
from app.providers.factory import get_youtube_provider

logger = logging.getLogger("ytagent")


class YouTubeService:
    def __init__(self, settings: Settings, db: Session):
        self._settings = settings
        self._db = db

    # ------------------------------------------------------------------
    def list_channels(self) -> List[Channel]:
        return self._db.query(Channel).order_by(Channel.connected_at.desc()).all()

    def get_channel(self, channel_id: Optional[str]) -> Optional[Channel]:
        if channel_id:
            return self._db.get(Channel, channel_id)
        return self._db.query(Channel).filter(Channel.is_default == True).first()  # noqa: E712

    def _resolve_channel(self, channel_id: Optional[str]) -> Optional[Channel]:
        channel = self.get_channel(channel_id)
        if channel is None:
            # Fall back to the first connected channel if no default is set
            # and none was explicitly requested -- better than refusing to
            # upload just because "default" was never flagged.
            channel = self._db.query(Channel).filter(Channel.token_json.isnot(None)).first()
        return channel

    def set_default_channel(self, channel_id: str) -> Channel:
        self._db.query(Channel).update({Channel.is_default: False})
        channel = self._db.get(Channel, channel_id)
        if channel is None:
            raise ValueError(f"Channel {channel_id} not found")
        channel.is_default = True
        self._db.commit()
        self._db.refresh(channel)
        return channel

    def rename_channel(self, channel_id: str, label: str) -> Channel:
        channel = self._db.get(Channel, channel_id)
        if channel is None:
            raise ValueError(f"Channel {channel_id} not found")
        channel.label = label
        self._db.commit()
        self._db.refresh(channel)
        return channel

    def disconnect_channel(self, channel_id: str) -> None:
        channel = self._db.get(Channel, channel_id)
        if channel is None:
            return
        self._db.delete(channel)
        self._db.commit()

    # ------------------------------------------------------------------
    def get_authorization_url(self) -> str:
        provider = get_youtube_provider(self._settings)
        return provider.get_authorization_url()

    def handle_oauth_callback(self, code: str, label: Optional[str] = None) -> Channel:
        """Always creates a NEW channel row, so connecting a second (third,
        fourth...) channel never overwrites a previously connected one."""
        provider = get_youtube_provider(self._settings)
        token_dict = provider.exchange_code_for_token(code)

        channel_title = None
        youtube_channel_id = None
        try:
            from app.providers.youtube.youtube_data_api_provider import YouTubeDataAPIProvider

            temp_provider = YouTubeDataAPIProvider(self._settings, stored_token_json=json.dumps(token_dict))
            info = temp_provider.fetch_channel_info()
            channel_title = info.get("title")
            youtube_channel_id = info.get("channel_id")
        except Exception as exc:
            logger.warning("Could not fetch YouTube channel title/id after connecting: %s", exc)

        existing_count = self._db.query(Channel).count()
        channel = Channel(
            label=label or channel_title or f"Channel {existing_count + 1}",
            channel_title=channel_title,
            youtube_channel_id=youtube_channel_id,
            token_json=json.dumps(token_dict),
            connected_at=datetime.utcnow(),
            is_active=True,
            is_default=(existing_count == 0),  # first connected channel becomes the default
        )
        self._db.add(channel)
        self._db.commit()
        self._db.refresh(channel)
        return channel

    def is_connected(self, channel_id: Optional[str] = None) -> bool:
        channel = self._resolve_channel(channel_id)
        return channel is not None and channel.token_json is not None

    def upload_video(
        self,
        video_path: Path,
        title: str,
        description: str,
        tags: List[str],
        category_id: str,
        privacy_status: str,
        thumbnail_path: Optional[Path] = None,
        channel_id: Optional[str] = None,
        publish_at: Optional[datetime] = None,
    ) -> dict:
        channel = self._resolve_channel(channel_id)
        stored_token = channel.token_json if channel else None
        provider = get_youtube_provider(self._settings, stored_token_json=stored_token)
        result = provider.upload_video(
            video_path,
            title,
            description,
            tags,
            category_id,
            privacy_status,
            thumbnail_path,
            publish_at=publish_at,
        )

        # Persist any refreshed token back to the DB.
        if channel is not None:
            try:
                refreshed = provider.get_refreshed_token_json()  # type: ignore[attr-defined]
                channel.token_json = refreshed
                self._db.commit()
            except Exception:
                pass

        result["channel_id"] = channel.id if channel else None
        return result
