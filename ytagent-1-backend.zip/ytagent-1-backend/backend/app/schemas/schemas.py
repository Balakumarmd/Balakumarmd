"""
Pydantic models.

Two families live here:
1. API request/response models (used by FastAPI routes).
2. Pipeline data models (script structure, scenes, transcripts, metadata)
   that are produced/consumed internally and persisted to disk as JSON
   inside each job's workspace.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, List, Optional

from pydantic import BaseModel, Field, field_validator


# =====================================================================
# API: Jobs
# =====================================================================
class JobCreateRequest(BaseModel):
    topic: str = Field(..., min_length=3, max_length=300)
    content_type: str = Field(..., description="'short' or 'long_form'")
    project_id: Optional[str] = None
    niche: Optional[str] = None
    language: str = Field(default="en")
    target_duration_seconds: Optional[int] = None
    voice: Optional[str] = None
    visual_style: Optional[str] = None
    music_preference: Optional[str] = Field(default="auto")
    research_enabled: bool = False
    generate_thumbnail: bool = True
    generate_metadata: bool = True
    auto_upload: bool = False
    upload_privacy: str = Field(default="private")
    llm_provider: Optional[str] = Field(default=None, description="'gemini'|'groq'|'ollama'|'auto'/None")
    channel_id: Optional[str] = Field(default=None, description="Which connected YouTube channel to upload to")
    scheduled_at: Optional[datetime] = Field(
        default=None, description="If set and auto_upload is True, the video is uploaded immediately but published on YouTube at this UTC time."
    )

    @field_validator("llm_provider")
    @classmethod
    def _validate_llm_provider(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        v = v.lower().strip()
        if v in ("", "auto"):
            return None
        if v not in ("gemini", "groq", "ollama"):
            raise ValueError("llm_provider must be one of: gemini, groq, ollama, auto")
        return v

    @field_validator("content_type")
    @classmethod
    def _validate_content_type(cls, v: str) -> str:
        if v not in ("short", "long_form"):
            raise ValueError("content_type must be 'short' or 'long_form'")
        return v

    @field_validator("upload_privacy")
    @classmethod
    def _validate_privacy(cls, v: str) -> str:
        if v not in ("private", "unlisted", "public"):
            raise ValueError("upload_privacy must be private, unlisted, or public")
        return v

    @field_validator("target_duration_seconds")
    @classmethod
    def _validate_duration(cls, v: Optional[int], info) -> Optional[int]:  # noqa: ANN001
        if v is None:
            return v
        if v < 10 or v > 1800:
            raise ValueError("target_duration_seconds must be between 10 and 1800")
        return v


class JobResponse(BaseModel):
    id: str
    project_id: Optional[str]
    topic: str
    content_type: str
    niche: Optional[str]
    language: str
    target_duration_seconds: int
    voice: Optional[str]
    status: str
    progress: int
    current_step: Optional[str]
    error_code: Optional[str]
    error_message: Optional[str]
    output_video_path: Optional[str]
    retry_count: int
    max_retries: int
    llm_provider: Optional[str] = None
    channel_id: Optional[str] = None
    scheduled_at: Optional[datetime] = None
    source: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# =====================================================================
# API: Bulk import (Excel / Google Sheet)
# =====================================================================
class BulkImportRow(BaseModel):
    topic: str
    content_type: str = "short"
    niche: Optional[str] = None
    language: str = "en"
    target_duration_seconds: Optional[int] = None
    voice: Optional[str] = None
    music_preference: Optional[str] = "auto"
    llm_provider: Optional[str] = None
    channel_label: Optional[str] = None  # resolved to channel_id by label at import time
    auto_upload: bool = True
    upload_privacy: str = "private"
    scheduled_at: Optional[datetime] = None
    row_key: str  # stable identity for dedup, e.g. "row-12" or a sheet row id

    @field_validator("content_type")
    @classmethod
    def _validate_content_type(cls, v: str) -> str:
        v = (v or "short").lower().strip()
        if v in ("long", "long_form", "longform"):
            return "long_form"
        return "short"


class BulkImportResult(BaseModel):
    created_jobs: int
    skipped_unchanged: int
    errors: List[str] = Field(default_factory=list)


class SheetSyncConfig(BaseModel):
    sheet_id: str
    sheet_range: str = "A:Z"
    api_key: Optional[str] = None
    poll_interval_seconds: int = Field(default=120, ge=30)
    enabled: bool = True


class ChannelResponse(BaseModel):
    id: str
    label: Optional[str]
    channel_title: Optional[str]
    youtube_channel_id: Optional[str]
    is_default: bool
    connected_at: Optional[datetime]

    class Config:
        from_attributes = True


# =====================================================================
# API: Projects
# =====================================================================
class ProjectCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    niche: Optional[str] = None
    default_language: str = "en"


class ProjectResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    niche: Optional[str]
    default_language: str
    created_at: datetime

    class Config:
        from_attributes = True


# =====================================================================
# API: Videos
# =====================================================================
class VideoResponse(BaseModel):
    id: str
    job_id: str
    title: Optional[str]
    description: Optional[str]
    tags: Optional[List[str]]
    file_path: Optional[str]
    thumbnail_path: Optional[str]
    duration_seconds: Optional[float]
    content_type: Optional[str]
    youtube_video_id: Optional[str]
    youtube_url: Optional[str]
    upload_privacy: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# =====================================================================
# API: Settings
# =====================================================================
class SettingsUpdateRequest(BaseModel):
    values: dict[str, str]


# =====================================================================
# API: Providers
# =====================================================================
class ProviderCredentialCreateRequest(BaseModel):
    category: str = Field(..., min_length=1, max_length=50)
    provider_name: str = Field(..., min_length=1, max_length=100)
    credential_type: str = Field(default="api_key", max_length=50)
    display_name: Optional[str] = Field(default=None, max_length=200)
    secret: str = Field(..., min_length=1)


class ProviderCredentialResponse(BaseModel):
    id: str
    category: str
    provider_name: str
    credential_type: str
    display_name: Optional[str]
    is_active: bool
    is_exhausted: bool
    exhausted_until: Optional[datetime] = None
    last_error: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ProviderCredentialListResponse(BaseModel):
    credentials: List[ProviderCredentialResponse]
    

# =====================================================================
# Pipeline: Script structure produced by the LLM
# =====================================================================
class Scene(BaseModel):
    scene_number: int
    narration: str = Field(..., min_length=1)
    visual_query: str = Field(..., min_length=1)
    duration: float = Field(..., gt=0)


class GeneratedScript(BaseModel):
    title: str
    hook: str
    scenes: List[Scene]
    outro: str
    cta: Optional[str] = None
    estimated_duration: float

    @field_validator("scenes")
    @classmethod
    def _must_have_scenes(cls, v: List[Scene]) -> List[Scene]:
        if not v:
            raise ValueError("script must contain at least one scene")
        return v

    def full_narration_text(self) -> str:
        parts = [self.hook.strip()]
        parts.extend(s.narration.strip() for s in self.scenes)
        if self.outro:
            parts.append(self.outro.strip())
        if self.cta:
            parts.append(self.cta.strip())
        return " ".join(p for p in parts if p)


# =====================================================================
# Pipeline: word-level transcript
# =====================================================================
class TranscriptWord(BaseModel):
    word: str
    start: float
    end: float


class Transcript(BaseModel):
    words: List[TranscriptWord]
    full_text: str
    duration: float


# =====================================================================
# Pipeline: media asset
# =====================================================================
class MediaAsset(BaseModel):
    scene_number: int
    source: str  # "pexels"
    asset_type: str  # "video" | "photo"
    source_id: str
    source_url: str
    local_path: str
    width: Optional[int] = None
    height: Optional[int] = None
    duration: Optional[float] = None


# =====================================================================
# Pipeline: YouTube metadata
# =====================================================================
class YouTubeMetadata(BaseModel):
    title: str = Field(..., max_length=100)
    description: str = Field(..., max_length=5000)
    tags: List[str] = Field(default_factory=list)
    category_id: str = Field(default="27")  # Education
    hashtags: List[str] = Field(default_factory=list)

    @field_validator("tags")
    @classmethod
    def _limit_tags(cls, v: List[str]) -> List[str]:
        return v[:15]
