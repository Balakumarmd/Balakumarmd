"""
The job pipeline: orchestrates a single Job through every stage of real
video generation (spec sections 6, 10-25), updating progress in SQLite as
it goes, and mapping any failure to a clear error code + message rather
than letting a raw traceback reach the user.

The pipeline supports stage-level resume using Job.last_completed_stage.
Completed artifacts are loaded from the job workspace instead of being
regenerated on retry.
"""
from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path
from typing import List, Optional

from app.config import Settings
from app.models import Job, JobStatus
from app.providers.factory import (
    get_llm_provider_from_db,
    get_media_provider,
    get_tts_provider,
    get_transcription_provider,
)
from app.repositories import job_repository, video_repository
from app.schemas.schemas import (
    GeneratedScript,
    MediaAsset,
    Transcript,
    YouTubeMetadata,
)
from app.services.caption_service import CaptionService, CaptionStyle
from app.services.media_service import MediaAcquisitionError, MediaService
from app.services.metadata_service import MetadataGenerationError, MetadataService
from app.services.music_service import resolve_music_path
from app.services.render_service import RenderError, RenderService, get_render_config
from app.services.research_service import ResearchService
from app.services.script_service import ScriptGenerationError, ScriptService
from app.services.thumbnail_service import ThumbnailError, ThumbnailService
from app.services.transcription_service import TranscriptionError, TranscriptionService
from app.services.tts_service import TTSGenerationError, TTSService
from app.services.workspace_service import JobWorkspace
from app.services.youtube_service import YouTubeService
from app.utils import error_codes
from app.utils.ffmpeg_utils import FFmpegError, get_media_duration
from app.utils.logging_config import get_job_logger
from app.utils.retry import PermanentError

logger = logging.getLogger("ytagent")

# Minimum free disk space required before starting a render.
_MIN_FREE_DISK_BYTES = 2 * 1024 * 1024 * 1024  # 2 GB


class JobFailedError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def _progress(
    db,
    job_id: str,
    status: JobStatus,
    pct: int,
    step: str,
) -> None:
    job_repository.update_job_progress(
        db,
        job_id,
        status=status.value,
        progress=pct,
        current_step=step,
    )


def _checkpoint(
    db_session_factory,
    job_id: str,
    stage: str,
) -> None:
    """
    Persist the last successfully completed pipeline stage.
    """
    with db_session_factory() as db:
        job_repository.update_job_progress(
            db,
            job_id,
            last_completed_stage=stage,
        )


def _stage_completed(
    last_completed_stage: Optional[str],
    stage: str,
) -> bool:
    """
    Return True when the requested stage is already completed.

    Stage order:
        script
        audio
        transcription
        media
        render
        thumbnail
        metadata
    """
    order = {
        "script": 1,
        "audio": 2,
        "transcription": 3,
        "media": 4,
        "render": 5,
        "thumbnail": 6,
        "metadata": 7,
    }

    if not last_completed_stage:
        return False

    completed_value = order.get(last_completed_stage)
    stage_value = order.get(stage)

    if completed_value is None or stage_value is None:
        return False

    return completed_value >= stage_value


def run_job(db_session_factory, job_id: str, settings: Settings) -> None:
    """
    Executes the full pipeline for one job using its own short-lived DB
    sessions per step.

    If the job is retried, completed stages are skipped and their artifacts
    are loaded from the existing job workspace.
    """
    with db_session_factory() as db:
        from app.config_resolver import get_effective_settings

        # Dashboard-stored settings (storage path, FFmpeg path, TTS/whisper
        # config, LLM provider defaults, etc.) override .env on every job,
        # so changing them in the dashboard takes effect on the next job
        # without needing to restart the worker process.
        settings = get_effective_settings(db)

        job = job_repository.get_job(db, job_id)

        if job is None:
            logger.error("Job %s not found when worker tried to run it", job_id)
            return

        topic = job.topic
        content_type = job.content_type
        niche = job.niche
        target_duration = job.target_duration_seconds
        voice = job.voice
        music_preference = job.music_preference
        research_enabled = job.research_enabled
        auto_upload = job.auto_upload
        upload_privacy = job.upload_privacy or "private"
        last_completed_stage = job.last_completed_stage
        llm_provider = job.llm_provider
        channel_id = job.channel_id
        scheduled_at = job.scheduled_at

    workspace = JobWorkspace(settings, job_id)
    job_logger = get_job_logger(job_id, workspace.root)

    job_logger.info(
        "Starting pipeline for job %s | topic='%s' | type=%s | "
        "last_completed_stage=%s",
        job_id,
        topic,
        content_type,
        last_completed_stage,
    )

    try:
        _check_disk_space(settings, job_logger)

        # ------------------------------------------------------------------
        # 1. RESEARCH
        #
        # Research has no checkpoint because the script checkpoint represents
        # the first reusable artifact. If script already exists, research is
        # no longer needed for this retry.
        # ------------------------------------------------------------------
        research_context = None

        if not _stage_completed(last_completed_stage, "script"):
            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.RESEARCHING,
                    5,
                    "Gathering research context",
                )

            if research_enabled:
                research_context = ResearchService(settings).gather_research(topic)
                job_logger.info(
                    "Research context gathered: %s chars",
                    len(research_context or ""),
                )

        # ------------------------------------------------------------------
        # 2. SCRIPT + SCENE PLANNING
        # ------------------------------------------------------------------
        script: GeneratedScript

        if _stage_completed(last_completed_stage, "script"):
            script = _load_script(workspace)

            job_logger.info(
                "Resuming from script checkpoint; loaded script '%s' with %d scenes",
                script.title,
                len(script.scenes),
            )
        else:
            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.SCRIPTING,
                    15,
                    "Generating script",
                )

            script = _generate_script(
                settings,
                db_session_factory,
                topic,
                content_type,
                niche,
                target_duration,
                research_context,
                job_logger,
                llm_provider,
            )

            workspace.script_path.write_text(
                script.model_dump_json(indent=2),
                encoding="utf-8",
            )

            workspace.narration_text_path.write_text(
                script.full_narration_text(),
                encoding="utf-8",
            )

            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.SCENE_PLANNING,
                    25,
                    f"Planned {len(script.scenes)} scenes",
                )

            job_logger.info(
                "Script generated: '%s' with %d scenes",
                script.title,
                len(script.scenes),
            )

            _checkpoint(
                db_session_factory,
                job_id,
                "script",
            )

        # ------------------------------------------------------------------
        # 3. TTS
        # ------------------------------------------------------------------
        audio_path: Path
        audio_duration: float

        if _stage_completed(last_completed_stage, "audio"):
            audio_path = workspace.audio_path

            if not audio_path.exists():
                raise JobFailedError(
                    error_codes.TTS_FAILED,
                    f"Audio checkpoint exists but audio file is missing: {audio_path}",
                )

            audio_duration = get_media_duration(audio_path) or 0.0

            if audio_duration <= 0:
                raise JobFailedError(
                    error_codes.TTS_FAILED,
                    f"Existing audio file has no measurable duration: {audio_path}",
                )

            job_logger.info(
                "Resuming from audio checkpoint; using existing audio %.2fs",
                audio_duration,
            )
        else:
            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.GENERATING_AUDIO,
                    35,
                    "Generating narration audio",
                )

            audio_path, audio_duration = _generate_audio(
                settings,
                script,
                workspace,
                voice,
                job_logger,
            )

            _checkpoint(
                db_session_factory,
                job_id,
                "audio",
            )

            job_logger.info(
                "Narration audio ready: %.2fs",
                audio_duration,
            )

        # ------------------------------------------------------------------
        # 4. TRANSCRIPTION / WORD TIMESTAMPS
        # ------------------------------------------------------------------
        transcript: Transcript

        if _stage_completed(last_completed_stage, "transcription"):
            transcript = _load_transcript(workspace)

            job_logger.info(
                "Resuming from transcription checkpoint; loaded %d words",
                len(transcript.words),
            )
        else:
            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.TRANSCRIBING,
                    45,
                    "Generating word-level captions timing",
                )

            transcript = _transcribe(
                settings,
                audio_path,
                workspace,
                job_logger,
            )

            _checkpoint(
                db_session_factory,
                job_id,
                "transcription",
            )

        # ------------------------------------------------------------------
        # 5. MEDIA ACQUISITION
        # ------------------------------------------------------------------
        orientation = "portrait" if content_type == "short" else "landscape"

        assets: List[MediaAsset]

        if _stage_completed(last_completed_stage, "media"):
            assets = _load_media_assets(
                script,
                workspace.media_dir,
            )

            job_logger.info(
                "Resuming from media checkpoint; loaded %d media assets",
                len(assets),
            )
        else:
            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.FETCHING_MEDIA,
                    60,
                    "Finding and downloading visual footage",
                )

            assets = _acquire_media(
                settings,
                db_session_factory,
                script,
                workspace,
                orientation,
                job_logger,
            )

            _checkpoint(
                db_session_factory,
                job_id,
                "media",
            )

        # ------------------------------------------------------------------
        # 6. CAPTIONS + RENDER
        # ------------------------------------------------------------------
        if _stage_completed(last_completed_stage, "render"):
            if not workspace.final_video_path.exists():
                raise JobFailedError(
                    error_codes.FFMPEG_FAILED,
                    f"Render checkpoint exists but final video is missing: "
                    f"{workspace.final_video_path}",
                )

            job_logger.info(
                "Resuming from render checkpoint; using existing final video"
            )
        else:
            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.RENDERING,
                    70,
                    "Rendering video",
                )

            render_cfg = get_render_config(content_type)

            CaptionService().generate_caption_file(
                transcript.words,
                workspace.captions_ass_path,
                render_cfg.width,
                render_cfg.height,
                CaptionStyle(),
            )

            music_path = resolve_music_path(
                settings.music_dir,
                music_preference,
            )

            _render(
                render_cfg,
                script,
                assets,
                audio_path,
                workspace,
                music_path,
                job_logger,
            )

            _checkpoint(
                db_session_factory,
                job_id,
                "render",
            )

            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.RENDERING,
                    85,
                    "Finalizing render",
                )

        # ------------------------------------------------------------------
        # 7. THUMBNAIL
        # ------------------------------------------------------------------
        if _stage_completed(last_completed_stage, "thumbnail"):
            if not workspace.thumbnail_path.exists():
                raise JobFailedError(
                    error_codes.THUMBNAIL_FAILED,
                    f"Thumbnail checkpoint exists but thumbnail is missing: "
                    f"{workspace.thumbnail_path}",
                )

            job_logger.info(
                "Resuming from thumbnail checkpoint; using existing thumbnail"
            )
        else:
            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.GENERATING_THUMBNAIL,
                    90,
                    "Generating thumbnail",
                )

            _generate_thumbnail(
                script,
                workspace,
                job_logger,
            )

            _checkpoint(
                db_session_factory,
                job_id,
                "thumbnail",
            )

        # ------------------------------------------------------------------
        # 8. METADATA
        # ------------------------------------------------------------------
        metadata: YouTubeMetadata

        if _stage_completed(last_completed_stage, "metadata"):
            metadata = _load_metadata(workspace)

            job_logger.info(
                "Resuming from metadata checkpoint; using existing metadata"
            )
        else:
            with db_session_factory() as db:
                _progress(
                    db,
                    job_id,
                    JobStatus.GENERATING_METADATA,
                    95,
                    "Generating title, description, tags",
                )

            metadata = _generate_metadata(
                settings,
                db_session_factory,
                script,
                content_type,
                niche,
                workspace,
                job_logger,
                llm_provider,
            )

            _checkpoint(
                db_session_factory,
                job_id,
                "metadata",
            )

        # ------------------------------------------------------------------
        # ---- 9. PERSIST VIDEO RECORD ----------------------------------------------------
        duration_seconds = audio_duration
        with db_session_factory() as db:
            existing = video_repository.get_video_by_job(db, job_id)
            job = job_repository.get_job(db, job_id)

            video_kwargs = dict(
                job_id=job_id,
                project_id=job.project_id if job else None,
                title=metadata.title,
                description=metadata.description,
                tags=metadata.tags,
                category=metadata.category_id,
                file_path=str(workspace.final_video_path),
                thumbnail_path=str(workspace.thumbnail_path),
                duration_seconds=duration_seconds,
                content_type=content_type,
            )

            if existing:
                video = video_repository.update_video(db, existing.id, **video_kwargs)
            else:
                video = video_repository.create_video(db, **video_kwargs)

            # Capture this before the SQLAlchemy session closes.
            video_id = video.id

            job_repository.update_job_progress(
                db,
                job_id,
                status=JobStatus.READY.value,
                progress=97,
                current_step="Video ready",
            )

        # ---- 10. OPTIONAL UPLOAD --------------------------------------------------------
        if auto_upload:
            with db_session_factory() as db:
                _progress(db, job_id, JobStatus.UPLOADING, 98, "Uploading to YouTube")

            try:
                _upload_to_youtube(
                    settings,
                    workspace,
                    metadata,
                    upload_privacy,
                    job_id,
                    video_id,
                    job_logger,
                    channel_id,
                    scheduled_at,
                )
            except JobFailedError as exc:
                with db_session_factory() as db:
                    job_repository.mark_job_failed(db, job_id, exc.code, exc.message)

                job_logger.error(
                    "Upload failed but local video is complete: %s",
                    exc.message,
                )
                return

        with db_session_factory() as db:
            job_repository.mark_job_completed(
                db,
                job_id,
                str(workspace.final_video_path),
            )

        job_logger.info(
            "Job %s completed successfully",
            job_id,
        )

    except JobFailedError as exc:
        job_logger.error(
            "Job failed [%s]: %s",
            exc.code,
            exc.message,
        )
        _handle_failure(
            db_session_factory,
            job_id,
            exc.code,
            exc.message,
        )

    except Exception as exc:  # noqa: BLE001
        job_logger.exception(
            "Unexpected error in pipeline"
        )

        _handle_failure(
            db_session_factory,
            job_id,
            error_codes.UNKNOWN_ERROR,
            str(exc),
        )


# ============================================================================
# Resume artifact loaders
# ============================================================================

def _load_script(workspace: JobWorkspace) -> GeneratedScript:
    """
    Load the previously generated script from script.json.
    """
    if not workspace.script_path.exists():
        raise JobFailedError(
            error_codes.SCRIPT_GENERATION_FAILED,
            f"Script checkpoint exists but script.json is missing: "
            f"{workspace.script_path}",
        )

    try:
        return GeneratedScript.model_validate_json(
            workspace.script_path.read_text(
                encoding="utf-8",
            )
        )
    except Exception as exc:
        raise JobFailedError(
            error_codes.SCRIPT_GENERATION_FAILED,
            f"Could not load saved script: {exc}",
        ) from exc


def _load_transcript(workspace: JobWorkspace) -> Transcript:
    """
    Load the previously generated Whisper transcript.
    """
    if not workspace.transcript_path.exists():
        raise JobFailedError(
            error_codes.WHISPER_FAILED,
            f"Transcription checkpoint exists but transcript.json is missing: "
            f"{workspace.transcript_path}",
        )

    try:
        return Transcript.model_validate_json(
            workspace.transcript_path.read_text(
                encoding="utf-8",
            )
        )
    except Exception as exc:
        raise JobFailedError(
            error_codes.WHISPER_FAILED,
            f"Could not load saved transcript: {exc}",
        ) from exc


def _load_metadata(workspace: JobWorkspace) -> YouTubeMetadata:
    """
    Load previously generated YouTube metadata.
    """
    if not workspace.metadata_path.exists():
        raise JobFailedError(
            error_codes.METADATA_FAILED,
            f"Metadata checkpoint exists but metadata.json is missing: "
            f"{workspace.metadata_path}",
        )

    try:
        return YouTubeMetadata.model_validate_json(
            workspace.metadata_path.read_text(
                encoding="utf-8",
            )
        )
    except Exception as exc:
        raise JobFailedError(
            error_codes.METADATA_FAILED,
            f"Could not load saved metadata: {exc}",
        ) from exc


def _load_media_assets(
    script: GeneratedScript,
    media_dir: Path,
) -> List[MediaAsset]:
    """
    Reconstruct MediaAsset objects from the files already downloaded into
    the job's media directory.

    MediaService names successful assets as:

        scene_<scene_number>_<source_id>.<extension>

    Only the local file is required by RenderService, so source_url and
    other provider metadata are left empty/default when resuming.
    """
    if not media_dir.exists():
        raise JobFailedError(
            error_codes.MEDIA_PROVIDER_FAILED,
            f"Media checkpoint exists but media directory is missing: "
            f"{media_dir}",
        )

    assets: List[MediaAsset] = []

    for scene in script.scenes:
        matching_files = sorted(
            list(media_dir.glob(f"scene_{scene.scene_number}_*.mp4"))
            + list(media_dir.glob(f"scene_{scene.scene_number}_*.jpg"))
            + list(media_dir.glob(f"scene_{scene.scene_number}_*.jpeg"))
            + list(media_dir.glob(f"scene_{scene.scene_number}_*.png"))
        )

        if not matching_files:
            raise JobFailedError(
                error_codes.MEDIA_PROVIDER_FAILED,
                f"Media checkpoint exists but no asset was found for "
                f"scene {scene.scene_number}",
            )

        local_path = matching_files[0]

        if local_path.suffix.lower() == ".mp4":
            asset_type = "video"
            duration = get_media_duration(local_path)
        else:
            asset_type = "photo"
            duration = None

        source_id = local_path.stem

        assets.append(
            MediaAsset(
                scene_number=scene.scene_number,
                source="pixabay",
                asset_type=asset_type,
                source_id=source_id,
                source_url="",
                local_path=str(local_path),
                width=None,
                height=None,
                duration=duration,
            )
        )

    return assets


# ============================================================================
# Failure / retry handling
# ============================================================================

def _handle_failure(
    db_session_factory,
    job_id: str,
    code: str,
    message: str,
) -> None:
    with db_session_factory() as db:
        job = job_repository.get_job(
            db,
            job_id,
        )

        if job is None:
            return

        if (job.retry_count or 0) < (job.max_retries or 0):
            job_repository.requeue_job_for_retry(
                db,
                job_id,
            )

            logger.info(
                "Job %s requeued for retry (%s/%s): %s",
                job_id,
                job.retry_count,
                job.max_retries,
                message,
            )
        else:
            job_repository.mark_job_failed(
                db,
                job_id,
                code,
                message,
            )


# ============================================================================
# General helpers
# ============================================================================

def _check_disk_space(
    settings: Settings,
    job_logger: logging.Logger,
) -> None:
    total, used, free = shutil.disk_usage(
        str(settings.data_dir_path)
    )

    if free < _MIN_FREE_DISK_BYTES:
        raise JobFailedError(
            error_codes.INSUFFICIENT_STORAGE,
            f"Only {free / (1024**3):.2f} GB free at "
            f"{settings.data_dir_path}; at least 2 GB is required.",
        )

    job_logger.info(
        "Disk space check passed: %.2f GB free",
        free / (1024**3),
    )


# ============================================================================
# Stage implementations
# ============================================================================

def _generate_script(
    settings,
    db_session_factory,
    topic,
    content_type,
    niche,
    target_duration,
    research_context,
    job_logger,
    llm_provider=None,
) -> GeneratedScript:
    try:
        # The DB session must stay open for the entire call: the LLM
        # failover provider lazily constructs concrete providers (and
        # persists key-exhaustion state) DURING generate(), not just at
        # construction time, so closing the session right after building
        # the provider object would leave it trying to use a dead session.
        with db_session_factory() as db:
            llm = get_llm_provider_from_db(settings, db, llm_provider)

            if not llm.is_available():
                raise JobFailedError(
                    error_codes.OLLAMA_UNAVAILABLE,
                    error_codes.USER_FACING_MESSAGES[
                        error_codes.OLLAMA_UNAVAILABLE
                    ],
                )

            return ScriptService(llm).generate_script(
                topic=topic,
                content_type=content_type,
                niche=niche,
                target_duration_seconds=target_duration,
                research_context=research_context,
            )

    except JobFailedError:
        raise

    except (ScriptGenerationError, ConnectionError) as exc:
        job_logger.error(
            "Script generation failed: %s",
            exc,
        )

        raise JobFailedError(
            error_codes.SCRIPT_GENERATION_FAILED,
            str(exc),
        ) from exc


def _generate_audio(
    settings,
    script,
    workspace,
    voice,
    job_logger,
):
    try:
        from app.providers.factory import get_tts_provider

        tts = get_tts_provider(settings)

        return TTSService(tts).generate_narration(
            script.full_narration_text(),
            workspace.audio_path,
            voice=voice,
        )

    except (TTSGenerationError, RuntimeError, PermanentError) as exc:
        job_logger.error(
            "TTS failed: %s",
            exc,
        )

        raise JobFailedError(
            error_codes.TTS_FAILED,
            str(exc),
        ) from exc


def _transcribe(
    settings,
    audio_path,
    workspace,
    job_logger,
):
    try:
        transcription = get_transcription_provider(settings)

        return TranscriptionService(transcription).transcribe(
            audio_path,
            workspace.transcript_path,
        )

    except (TranscriptionError, RuntimeError) as exc:
        job_logger.error(
            "Transcription failed: %s",
            exc,
        )

        raise JobFailedError(
            error_codes.WHISPER_FAILED,
            str(exc),
        ) from exc


def _acquire_media(
    settings,
    db_session_factory,
    script,
    workspace,
    orientation,
    job_logger,
):
    try:
        # Kept open for the whole acquisition pass (one search/download per
        # scene) so key-exhaustion persistence (mark_exhausted) has a live
        # session to commit through, same reasoning as the LLM provider.
        with db_session_factory() as db:
            media_provider = get_media_provider(settings, db)

            return MediaService(
                media_provider
            ).acquire_assets_for_scenes(
                script.scenes,
                workspace.media_dir,
                orientation,
            )

    except (MediaAcquisitionError, PermanentError) as exc:
        job_logger.error(
            "Media acquisition failed: %s",
            exc,
        )

        raise JobFailedError(
            error_codes.MEDIA_PROVIDER_FAILED,
            str(exc),
        ) from exc


def _render(
    render_cfg,
    script,
    assets,
    audio_path,
    workspace,
    music_path,
    job_logger,
):
    try:
        RenderService(render_cfg).render(
            script.scenes,
            assets,
            audio_path,
            workspace.captions_ass_path,
            workspace.root,
            workspace.final_video_path,
            music_path=music_path,
        )

    except RenderError as exc:
        job_logger.error(
            "Render failed: %s",
            exc,
        )

        raise JobFailedError(
            error_codes.FFMPEG_FAILED,
            str(exc),
        ) from exc


def _generate_thumbnail(
    script,
    workspace,
    job_logger,
):
    try:
        ThumbnailService().generate(
            workspace.final_video_path,
            script.title,
            workspace.thumbnail_path,
        )

    except ThumbnailError as exc:
        job_logger.error(
            "Thumbnail generation failed: %s",
            exc,
        )

        raise JobFailedError(
            error_codes.THUMBNAIL_FAILED,
            str(exc),
        ) from exc


def _generate_metadata(
    settings,
    db_session_factory,
    script,
    content_type,
    niche,
    workspace,
    job_logger,
    llm_provider=None,
):
    try:
        with db_session_factory() as db:
            llm = get_llm_provider_from_db(settings, db, llm_provider)

            metadata = MetadataService(llm).generate_metadata(
                script,
                content_type,
                niche,
            )

        workspace.metadata_path.write_text(
            metadata.model_dump_json(indent=2),
            encoding="utf-8",
        )

        return metadata

    except MetadataGenerationError as exc:
        job_logger.error(
            "Metadata generation failed: %s",
            exc,
        )

        raise JobFailedError(
            error_codes.METADATA_FAILED,
            str(exc),
        ) from exc


def _upload_to_youtube(
    settings,
    workspace,
    metadata,
    privacy,
    job_id,
    video_id,
    job_logger,
    channel_id=None,
    scheduled_at=None,
):
    from app.database import session_scope

    try:
        with session_scope() as db:
            svc = YouTubeService(
                settings,
                db,
            )

            if not svc.is_connected(channel_id):
                raise JobFailedError(
                    error_codes.YOUTUBE_AUTH_FAILED,
                    error_codes.USER_FACING_MESSAGES[
                        error_codes.YOUTUBE_AUTH_FAILED
                    ],
                )

            result = svc.upload_video(
                workspace.final_video_path,
                metadata.title,
                metadata.description,
                metadata.tags,
                metadata.category_id,
                privacy,
                thumbnail_path=workspace.thumbnail_path,
                channel_id=channel_id,
                publish_at=scheduled_at,
            )

            from app.repositories import video_repository as vrepo

            vrepo.mark_uploaded(
                db,
                video_id,
                result["video_id"],
                result["url"],
                privacy,
            )

        job_logger.info(
            "Uploaded to YouTube: %s",
            result["url"],
        )

    except JobFailedError:
        raise

    except PermanentError as exc:
        raise JobFailedError(
            error_codes.YOUTUBE_AUTH_FAILED,
            str(exc),
        ) from exc

    except Exception as exc:
        job_logger.error(
            "YouTube upload failed: %s",
            exc,
        )

        raise JobFailedError(
            error_codes.YOUTUBE_UPLOAD_FAILED,
            str(exc),
        ) from exc