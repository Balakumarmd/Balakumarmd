"""
Structured logging setup.

Produces:
  - a rotating application log   (logs/app.log)
  - a rotating worker log        (logs/worker.log)
  - per-job logs under jobs/<job_id>/logs/job.log, attached dynamically by
    the pipeline via `get_job_logger`.
"""
from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

from app.config import get_settings

_CONFIGURED = False


def configure_logging(component: str = "app") -> logging.Logger:
    global _CONFIGURED
    settings = get_settings()
    logs_dir = settings.logs_dir
    logger = logging.getLogger("ytagent")
    logger.setLevel(settings.LOG_LEVEL.upper())

    if not _CONFIGURED:
        fmt = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
        )

        console = logging.StreamHandler()
        console.setFormatter(fmt)
        logger.addHandler(console)

        file_handler = logging.handlers.RotatingFileHandler(
            logs_dir / f"{component}.log", maxBytes=5_000_000, backupCount=3, encoding="utf-8"
        )
        file_handler.setFormatter(fmt)
        logger.addHandler(file_handler)
        _CONFIGURED = True

    return logger


def get_job_logger(job_id: str, job_dir: Path) -> logging.Logger:
    """Returns a logger that ALSO writes into the job's own workspace so a
    user can inspect exactly what happened to their video, independent of
    the global application log."""
    logger = logging.getLogger(f"ytagent.job.{job_id}")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        job_logs_dir = job_dir / "logs"
        job_logs_dir.mkdir(parents=True, exist_ok=True)
        fmt = logging.Formatter(f"%(asctime)s | %(levelname)-8s | [JOB {job_id[:8]}] | %(message)s")
        fh = logging.FileHandler(job_logs_dir / "job.log", encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
        # Also bubble up to the main worker logger/console.
        parent = logging.getLogger("ytagent")
        for h in parent.handlers:
            logger.addHandler(h)
    return logger
