"""
Best-effort hardware detection. GPU is never required -- everything here
degrades gracefully to CPU if detection fails or no GPU driver is present.
"""
from __future__ import annotations

import shutil
from typing import Optional

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None


def get_cpu_info() -> str:
    if psutil is None:
        return "unknown"
    try:
        return f"{psutil.cpu_count(logical=True)} logical cores"
    except Exception:
        return "unknown"


def get_memory_info() -> str:
    if psutil is None:
        return "unknown"
    try:
        vm = psutil.virtual_memory()
        return f"{vm.total / (1024 ** 3):.1f} GB total, {vm.available / (1024 ** 3):.1f} GB available"
    except Exception:
        return "unknown"


def get_disk_info(path: str = ".") -> str:
    try:
        total, used, free = shutil.disk_usage(path)
        return f"{free / (1024 ** 3):.1f} GB free of {total / (1024 ** 3):.1f} GB"
    except Exception:
        return "unknown"


def get_gpu_info() -> Optional[str]:
    """Detect an NVIDIA GPU via torch if available; otherwise report
    'not detected' rather than failing. GPU is a performance optimization
    only (used for faster-whisper), never a hard requirement."""
    try:
        import torch  # type: ignore

        if torch.cuda.is_available():
            name = torch.cuda.get_device_name(0)
            return f"{name} (CUDA available)"
        return "No CUDA GPU detected (CPU mode)"
    except Exception:
        return "GPU detection unavailable (torch not installed) - CPU mode"


def gpu_available() -> bool:
    try:
        import torch  # type: ignore

        return bool(torch.cuda.is_available())
    except Exception:
        return False
