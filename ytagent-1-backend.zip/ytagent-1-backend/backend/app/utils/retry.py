"""
Small, explicit retry helper used for transient provider failures
(network timeouts, temporary 5xx, etc). Deliberately NOT a generic
decorator-magic library: every call site chooses its own max_attempts so
permanent errors (bad API key, invalid input) are never retried blindly.
"""
from __future__ import annotations

import logging
import time
from typing import Callable, Iterable, Type, TypeVar

T = TypeVar("T")

logger = logging.getLogger("ytagent")


class PermanentError(Exception):
    """Raised by provider code to signal 'do not retry this'."""


def retry_with_backoff(
    fn: Callable[[], T],
    *,
    max_attempts: int = 3,
    base_delay_seconds: float = 1.5,
    retry_on: Iterable[Type[Exception]] = (Exception,),
    on_retry: Callable[[int, Exception], None] | None = None,
) -> T:
    last_exc: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except PermanentError:
            raise
        except tuple(retry_on) as exc:  # type: ignore[misc]
            last_exc = exc
            if attempt == max_attempts:
                break
            delay = base_delay_seconds * (2 ** (attempt - 1))
            logger.warning("Attempt %s/%s failed: %s. Retrying in %.1fs", attempt, max_attempts, exc, delay)
            if on_retry:
                on_retry(attempt, exc)
            time.sleep(delay)
    assert last_exc is not None
    raise last_exc
