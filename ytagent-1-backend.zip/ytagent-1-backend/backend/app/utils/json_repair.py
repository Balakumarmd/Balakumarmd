"""
Safe extraction/repair of JSON that an LLM may have wrapped in markdown
fences, prefixed with commentary, or otherwise slightly malformed. This is
intentionally conservative: it never invents fields, it only extracts and
lightly repairs syntax so a strict schema validator downstream can do the
real validation.
"""
from __future__ import annotations

import json
import re
from typing import Any, Optional


def extract_json_block(text: str) -> Optional[str]:
    """Pull the most likely JSON object/array out of arbitrary LLM output."""
    text = text.strip()

    # Prefer fenced code blocks (```json ... ``` or ``` ... ```)
    fence_match = re.search(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```", text, re.DOTALL)
    if fence_match:
        return fence_match.group(1)

    # Fall back to the first top-level {...} or [...] found via brace matching.
    for open_char, close_char in (("{", "}"), ("[", "]")):
        start = text.find(open_char)
        if start == -1:
            continue
        depth = 0
        for i in range(start, len(text)):
            if text[i] == open_char:
                depth += 1
            elif text[i] == close_char:
                depth -= 1
                if depth == 0:
                    return text[start : i + 1]
    return None


def _strip_trailing_commas(s: str) -> str:
    return re.sub(r",\s*([\]}])", r"\1", s)


def safe_parse_json(text: str) -> Any:
    """
    Attempt to parse `text` as JSON, applying a series of increasingly
    forgiving repairs. Raises ValueError if nothing works -- callers must
    treat that as a hard failure (re-prompt the LLM or fail the job), never
    silently substitute fabricated data.
    """
    candidates = [text, extract_json_block(text)]
    for candidate in candidates:
        if candidate is None:
            continue
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            pass
        try:
            return json.loads(_strip_trailing_commas(candidate))
        except json.JSONDecodeError:
            pass
    raise ValueError("Could not parse valid JSON from model output")
