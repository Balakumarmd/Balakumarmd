"""
Defensive helpers: filename sanitization and path-traversal prevention.
Every place the application writes a file derived from user input (topic,
scene text, uploaded filenames) must go through `safe_filename`, and every
place it resolves a path that is supposed to live inside the data
directory must go through `safe_join`.
"""
from __future__ import annotations

import re
from pathlib import Path

_UNSAFE_CHARS = re.compile(r"[^A-Za-z0-9_.\-]")


def safe_filename(name: str, max_length: int = 80) -> str:
    name = name.strip().replace(" ", "_")
    name = _UNSAFE_CHARS.sub("", name)
    if not name:
        name = "file"
    return name[:max_length]


def safe_join(base_dir: Path, *parts: str) -> Path:
    """Join path parts under base_dir, raising if the result would escape
    base_dir (path traversal protection)."""
    base_dir = base_dir.resolve()
    candidate = (base_dir / Path(*parts)).resolve()
    if base_dir != candidate and base_dir not in candidate.parents:
        raise ValueError(f"Unsafe path detected: {candidate}")
    return candidate
