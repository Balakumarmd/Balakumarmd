"""Canonical, user-facing error codes (spec section 32). Raw Python
tracebacks are never shown to the user as the primary error -- they are
always logged (see logging_config.py / job workspace logs/job.log) and
summarized into one of these codes + a short human-readable message."""

OLLAMA_UNAVAILABLE = "OLLAMA_UNAVAILABLE"
SCRIPT_GENERATION_FAILED = "SCRIPT_GENERATION_FAILED"
TTS_FAILED = "TTS_FAILED"
WHISPER_FAILED = "WHISPER_FAILED"
MEDIA_PROVIDER_FAILED = "MEDIA_PROVIDER_FAILED"
FFMPEG_FAILED = "FFMPEG_FAILED"
THUMBNAIL_FAILED = "THUMBNAIL_FAILED"
METADATA_FAILED = "METADATA_FAILED"
YOUTUBE_AUTH_FAILED = "YOUTUBE_AUTH_FAILED"
YOUTUBE_UPLOAD_FAILED = "YOUTUBE_UPLOAD_FAILED"
INSUFFICIENT_STORAGE = "INSUFFICIENT_STORAGE"
UNKNOWN_ERROR = "UNKNOWN_ERROR"

USER_FACING_MESSAGES = {
    OLLAMA_UNAVAILABLE: "The local AI model (Ollama) is unavailable. Make sure 'ollama serve' is running and the configured model is pulled.",
    SCRIPT_GENERATION_FAILED: "The AI could not generate a valid script for this topic. Try rephrasing the topic or try again.",
    TTS_FAILED: "Text-to-speech generation failed. Check that Kokoro TTS is installed correctly.",
    WHISPER_FAILED: "Caption timing generation failed. Check that faster-whisper is installed correctly.",
    MEDIA_PROVIDER_FAILED: "Could not find or download visual footage for this topic. Check your Pexels API key and internet connection.",
    FFMPEG_FAILED: "Video rendering failed. Check that FFmpeg is installed and on your PATH (or FFMPEG_PATH is set correctly).",
    THUMBNAIL_FAILED: "Thumbnail generation failed.",
    METADATA_FAILED: "YouTube title/description generation failed.",
    YOUTUBE_AUTH_FAILED: "YouTube account is not connected or the connection has expired. Reconnect it from Settings.",
    YOUTUBE_UPLOAD_FAILED: "Uploading the finished video to YouTube failed.",
    INSUFFICIENT_STORAGE: "Not enough free disk space to safely generate this video.",
    UNKNOWN_ERROR: "An unexpected error occurred. See the job's log file for details.",
}
