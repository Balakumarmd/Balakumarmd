"""
Thin, safe wrapper around ffmpeg/ffprobe. All commands are built as
argument lists (never shell strings), so there is no shell-injection
surface even though scene text / topics ultimately influence filenames.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import List, Optional

from app.config import get_settings


class FFmpegError(Exception):
    pass


def run_ffmpeg(args: List[str], timeout: int = 1800) -> str:
    settings = get_settings()
    cmd = [settings.FFMPEG_PATH, "-y", "-hide_banner", "-loglevel", "error", *args]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError as exc:
        raise FFmpegError(
            f"ffmpeg executable not found at '{settings.FFMPEG_PATH}'. "
            "Install FFmpeg and/or set FFMPEG_PATH in .env."
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise FFmpegError(f"ffmpeg timed out after {timeout}s") from exc
    if proc.returncode != 0:
        raise FFmpegError(f"ffmpeg failed (code {proc.returncode}): {proc.stderr.strip()[-4000:]}")
    return proc.stdout


def ffprobe_json(path: Path) -> dict:
    settings = get_settings()
    cmd = [
        settings.FFPROBE_PATH,
        "-v",
        "error",
        "-print_format",
        "json",
        "-show_format",
        "-show_streams",
        str(path),
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except FileNotFoundError as exc:
        raise FFmpegError(
            f"ffprobe executable not found at '{settings.FFPROBE_PATH}'. Install FFmpeg."
        ) from exc
    if proc.returncode != 0:
        raise FFmpegError(f"ffprobe failed: {proc.stderr.strip()[-2000:]}")
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise FFmpegError("ffprobe returned invalid JSON") from exc


def get_media_duration(path: Path) -> Optional[float]:
    try:
        info = ffprobe_json(path)
        return float(info["format"]["duration"])
    except (FFmpegError, KeyError, ValueError):
        return None


def check_ffmpeg_available() -> bool:
    settings = get_settings()
    try:
        subprocess.run(
            [settings.FFMPEG_PATH, "-version"], capture_output=True, timeout=10, check=True
        )
        return True
    except Exception:
        return False
