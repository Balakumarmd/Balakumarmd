from __future__ import annotations

import os

from cryptography.fernet import Fernet, InvalidToken


class SecretCrypto:
    """Encrypt and decrypt application secrets stored in the database."""

    def __init__(self, key: str | None = None):
        if key is None:
            from app.config import get_settings
            key = get_settings().yt_agent_encryption_key

        if not key:
            raise RuntimeError(
                "YT_AGENT_ENCRYPTION_KEY is not configured. "
                "Generate a Fernet key and add it to the environment."
            )

        try:
            self._fernet = Fernet(key.encode())
        except Exception as exc:
            raise RuntimeError(
                "YT_AGENT_ENCRYPTION_KEY is not a valid Fernet key."
            ) from exc

    def encrypt(self, value: str) -> str:
        if not value:
            raise ValueError("Cannot encrypt an empty secret.")

        return self._fernet.encrypt(value.encode()).decode()

    def decrypt(self, value: str) -> str:
        if not value:
            raise ValueError("Cannot decrypt an empty secret.")

        try:
            return self._fernet.decrypt(value.encode()).decode()
        except InvalidToken as exc:
            raise RuntimeError(
                "Unable to decrypt the stored secret. "
                "The encryption key may be incorrect or the data may be corrupted."
            ) from exc