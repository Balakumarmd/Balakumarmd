"""Entrypoint script: starts the FastAPI dashboard/control-plane API.

Usage:
    python run_backend.py
"""
import uvicorn

from app.config import get_settings

if __name__ == "__main__":
    settings = get_settings()
    uvicorn.run("app.main:app", host=settings.API_HOST, port=settings.API_PORT, reload=False)
