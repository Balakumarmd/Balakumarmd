Drop royalty-free background music files here (.mp3, .wav, .m4a, .aac, .flac, .ogg).

NOTE: the application actually reads its music library from DATA_DIR/music
(e.g. D:\YTAgentData\music), not from this folder -- this folder is just a
convenient starting point. Copy any tracks you add here into DATA_DIR/music
as well, or simply add them directly there.

When a job's "music preference" is set to "auto", the renderer picks a
random track from that folder, loops it if needed, and automatically
lowers its volume under the narration. Set music preference to "none" for
silence, or to an exact filename to pin a specific track.

The application does NOT download copyrighted music automatically. Only
use tracks you have the rights to use.

Good free sources: YouTube Audio Library, Pixabay Music, Free Music Archive
(check each track's specific license).
