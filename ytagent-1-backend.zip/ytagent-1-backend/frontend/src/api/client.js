const BASE = "/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || JSON.stringify(body);
    } catch (_) {
      /* ignore */
    }
    throw new Error(detail);
  }
  const contentType = res.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return res.json();
  }
  return res;
}

async function requestForm(path, formData, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    body: formData,
    ...options,
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || JSON.stringify(body);
    } catch (_) {
      /* ignore */
    }
    throw new Error(detail);
  }
  return res.json();
}

export const api = {
  health: () => request("/health"),
  systemStatus: () => request("/system/status"),
  workers: () => request("/system/workers"),

  createJob: (payload) => request("/jobs", { method: "POST", body: JSON.stringify(payload) }),
  listJobs: (status) => request(`/jobs${status ? `?status=${status}` : ""}`),
  getJob: (id) => request(`/jobs/${id}`),
  cancelJob: (id) => request(`/jobs/${id}/cancel`, { method: "POST" }),
  retryJob: (id) => request(`/jobs/${id}/retry`, { method: "POST" }),

  listVideos: () => request("/videos"),
  getVideo: (id) => request(`/videos/${id}`),
  videoFileUrl: (id) => `${BASE}/videos/${id}/file`,
  videoThumbUrl: (id) => `${BASE}/videos/${id}/thumbnail`,

  listProjects: () => request("/projects"),
  createProject: (payload) => request("/projects", { method: "POST", body: JSON.stringify(payload) }),

  getSettings: () => request("/settings"),
  updateSettings: (values) => request("/settings", { method: "PUT", body: JSON.stringify({ values }) }),

  // ---- Provider credentials (API keys) -----------------------------------
  listProviderCredentials: (category, provider) => request(`/providers/credentials/${category}/${provider}`),
  addProviderCredential: (payload) =>
    request("/providers/credentials", { method: "POST", body: JSON.stringify(payload) }),
  deleteProviderCredential: (id) => request(`/providers/credentials/${id}`, { method: "DELETE" }),
  resetCredentialExhaustion: (id) => request(`/providers/credentials/${id}/reset-exhausted`, { method: "POST" }),

  listProviderConfigs: (category) => request(`/providers/config/${category}`),
  setProviderConfig: (category, provider) => request(`/providers/config/${category}/${provider}`, { method: "PUT" }),
  setPriorityOrder: (category, order) =>
    request(`/providers/priority/${category}`, { method: "PUT", body: JSON.stringify(order) }),

  // ---- YouTube (multi-channel) --------------------------------------------
  youtubeConnect: () => request("/youtube/connect", { method: "POST" }),
  youtubeStatus: (channelId) => request(`/youtube/status${channelId ? `?channel_id=${channelId}` : ""}`),
  youtubeUpload: (videoId, channelId) =>
    request(`/youtube/upload/${videoId}${channelId ? `?channel_id=${channelId}` : ""}`, { method: "POST" }),
  listChannels: () => request("/youtube/channels"),
  setDefaultChannel: (channelId) => request(`/youtube/channels/${channelId}/set-default`, { method: "POST" }),
  renameChannel: (channelId, label) =>
    request(`/youtube/channels/${channelId}/label?label=${encodeURIComponent(label)}`, { method: "PUT" }),
  disconnectChannel: (channelId) => request(`/youtube/channels/${channelId}`, { method: "DELETE" }),
  setYoutubeOAuthApp: (clientId, clientSecret) =>
    request(
      `/youtube/oauth-app-credentials?client_id=${encodeURIComponent(clientId)}&client_secret=${encodeURIComponent(clientSecret)}`,
      { method: "PUT" }
    ),
  youtubeOAuthAppStatus: () => request("/youtube/oauth-app-credentials/status"),

  // ---- Bulk import (Excel) -------------------------------------------------
  bulkImportTemplateUrl: () => `${BASE}/jobs/bulk-import/template`,
  bulkImportExcel: (file) => {
    const form = new FormData();
    form.append("file", file);
    return requestForm("/jobs/bulk-import", form);
  },

  // ---- Google Sheet live sync -----------------------------------------------
  getSheetSyncConfig: () => request("/sheet-sync/config"),
  updateSheetSyncConfig: (payload) => request("/sheet-sync/config", { method: "PUT", body: JSON.stringify(payload) }),
  runSheetSyncNow: () => request("/sheet-sync/run-now", { method: "POST" }),
};
