import React from "react";
import { NavLink, Route, Routes } from "react-router-dom";

import Dashboard from "./pages/Dashboard.jsx";
import CreateVideo from "./pages/CreateVideo.jsx";
import Jobs from "./pages/Jobs.jsx";
import VideoLibrary from "./pages/VideoLibrary.jsx";
import Projects from "./pages/Projects.jsx";
import YouTube from "./pages/YouTube.jsx";
import Settings from "./pages/Settings.jsx";
import SystemStatus from "./pages/SystemStatus.jsx";
import BulkImport from "./pages/BulkImport.jsx";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard" },
  { to: "/create", label: "Create video" },
  { to: "/jobs", label: "Jobs" },
  { to: "/library", label: "Video library" },
  { to: "/projects", label: "Projects" },
  { to: "/bulk-import", label: "Bulk import" },
  { to: "/youtube", label: "YouTube" },
  { to: "/settings", label: "Settings" },
  { to: "/status", label: "System status" },
];

export default function App() {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <div className="mark">
            <span className="dot" />
            YTAgent
          </div>
          <div className="sub">local video studio</div>
        </div>
        <nav>
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          v1.0.0 · runs entirely on this PC
        </div>
      </aside>
      <main className="main">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/create" element={<CreateVideo />} />
          <Route path="/jobs" element={<Jobs />} />
          <Route path="/library" element={<VideoLibrary />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/bulk-import" element={<BulkImport />} />
          <Route path="/youtube" element={<YouTube />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/status" element={<SystemStatus />} />
        </Routes>
      </main>
    </div>
  );
}
