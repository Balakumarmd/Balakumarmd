import React from "react";
import StatusTag from "./StatusTag.jsx";

export default function JobProgress({ job }) {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
        <StatusTag status={job.status} />
        <span className="mono" style={{ fontSize: 12, color: "var(--text-dim)" }}>{job.progress}%</span>
      </div>
      <div className="progress-track">
        <div className="progress-fill" style={{ width: `${job.progress}%` }} />
      </div>
      {job.current_step && <div className="progress-step">{job.current_step}</div>}
      {job.error_message && (
        <div className="error-box" style={{ marginTop: 10 }}>
          <strong>{job.error_code}</strong> — {job.error_message}
        </div>
      )}
    </div>
  );
}
