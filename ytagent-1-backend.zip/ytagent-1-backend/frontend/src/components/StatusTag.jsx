import React from "react";

const GROUPS = {
  QUEUED: "queued",
  CLAIMED: "running",
  RESEARCHING: "running",
  SCRIPTING: "running",
  SCENE_PLANNING: "running",
  GENERATING_AUDIO: "running",
  TRANSCRIBING: "running",
  FETCHING_MEDIA: "running",
  RENDERING: "running",
  GENERATING_THUMBNAIL: "running",
  GENERATING_METADATA: "running",
  READY: "completed",
  UPLOADING: "running",
  COMPLETED: "completed",
  FAILED: "failed",
  CANCELLED: "cancelled",
};

export default function StatusTag({ status }) {
  const group = GROUPS[status] || "queued";
  return <span className={`tag tag-${group}`}>{status?.replace(/_/g, " ").toLowerCase()}</span>;
}
