import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client.js";
import JobProgress from "../components/JobProgress.jsx";

const NICHES = ["General", "Education", "Technology", "Finance", "Health & Fitness", "Productivity", "Entertainment", "Other"];

export default function CreateVideo() {
  const navigate = useNavigate();
  const [contentType, setContentType] = useState("short");
  const [topic, setTopic] = useState("");
  const [niche, setNiche] = useState("Education");
  const [language, setLanguage] = useState("en");
  const [duration, setDuration] = useState(45);
  const [voice, setVoice] = useState("af_heart");
  const [music, setMusic] = useState("auto");
  const [research, setResearch] = useState(false);
  const [autoUpload, setAutoUpload] = useState(false);
  const [privacy, setPrivacy] = useState("private");
  const [projects, setProjects] = useState([]);
  const [projectId, setProjectId] = useState("");
  const [llmProvider, setLlmProvider] = useState("auto");
  const [channels, setChannels] = useState([]);
  const [channelId, setChannelId] = useState("");
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [job, setJob] = useState(null);

  useEffect(() => {
    api.listProjects().then(setProjects).catch(() => {});
    api
      .listChannels()
      .then((list) => {
        setChannels(list);
        const def = list.find((c) => c.is_default);
        if (def) setChannelId(def.id);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    setDuration(contentType === "short" ? 45 : 180);
  }, [contentType]);

  useEffect(() => {
    if (!job || ["COMPLETED", "FAILED", "CANCELLED"].includes(job.status)) return;
    const id = setInterval(async () => {
      try {
        const updated = await api.getJob(job.id);
        setJob(updated);
      } catch (_) {
        /* ignore transient errors while polling */
      }
    }, 2000);
    return () => clearInterval(id);
  }, [job]);

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      let scheduledAt = null;
      if (scheduleDate) {
        scheduledAt = new Date(`${scheduleDate}T${scheduleTime || "09:00"}:00`).toISOString();
      }
      const created = await api.createJob({
        topic,
        content_type: contentType,
        project_id: projectId || null,
        niche,
        language,
        target_duration_seconds: Number(duration),
        voice,
        music_preference: music,
        research_enabled: research,
        auto_upload: autoUpload,
        upload_privacy: privacy,
        llm_provider: llmProvider === "auto" ? null : llmProvider,
        channel_id: channelId || null,
        scheduled_at: scheduledAt,
      });
      setJob(created);
    } catch (e) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  const isRunning = job && !["COMPLETED", "FAILED", "CANCELLED"].includes(job.status);

  return (
    <div>
      <div className="page-header">
        <h1>Create video</h1>
        <p>Describe a topic. The pipeline writes the script, voices it, sources footage, and renders a finished MP4.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      {job ? (
        <div className="panel">
          <div className="panel-title">
            {job.topic}
            {!isRunning && (
              <button className="btn btn-sm" onClick={() => setJob(null)}>Start another</button>
            )}
          </div>
          <JobProgress job={job} />
          {job.status === "COMPLETED" && (
            <button className="btn btn-primary btn-sm" style={{ marginTop: 14 }} onClick={() => navigate("/library")}>
              View in library
            </button>
          )}
          {job.status === "FAILED" && (
            <button
              className="btn btn-sm"
              style={{ marginTop: 14 }}
              onClick={async () => setJob(await api.retryJob(job.id))}
            >
              Retry job
            </button>
          )}
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="panel">
            <div className="panel-title">Format</div>
            <div className="segmented" style={{ marginBottom: 18 }}>
              <button type="button" className={contentType === "short" ? "active" : ""} onClick={() => setContentType("short")}>
                YouTube Short (9:16)
              </button>
              <button type="button" className={contentType === "long_form" ? "active" : ""} onClick={() => setContentType("long_form")}>
                Long-form (16:9)
              </button>
            </div>

            <div className="field">
              <label>Topic</label>
              <input
                type="text"
                required
                placeholder="e.g. 5 AI tools students should know"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
              />
              <div className="field-hint">This drives the script, the visuals, and the title.</div>
            </div>

            <div className="grid-2">
              <div className="field">
                <label>Niche</label>
                <select value={niche} onChange={(e) => setNiche(e.target.value)}>
                  {NICHES.map((n) => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Language</label>
                <select value={language} onChange={(e) => setLanguage(e.target.value)}>
                  <option value="en">English</option>
                </select>
                <div className="field-hint">Additional languages depend on the TTS voice model installed.</div>
              </div>
            </div>

            <div className="grid-2">
              <div className="field">
                <label>Target duration (seconds)</label>
                <input type="number" min={10} max={1800} value={duration} onChange={(e) => setDuration(e.target.value)} />
              </div>
              <div className="field">
                <label>Voice</label>
                <select value={voice} onChange={(e) => setVoice(e.target.value)}>
                  <option value="af_heart">af_heart (US, warm)</option>
                  <option value="af_bella">af_bella (US, upbeat)</option>
                  <option value="am_michael">am_michael (US, male)</option>
                  <option value="bf_emma">bf_emma (UK, female)</option>
                </select>
              </div>
            </div>

            <div className="grid-2">
              <div className="field">
                <label>Project (optional)</label>
                <select value={projectId} onChange={(e) => setProjectId(e.target.value)}>
                  <option value="">No project</option>
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>AI model</label>
                <select value={llmProvider} onChange={(e) => setLlmProvider(e.target.value)}>
                  <option value="auto">Auto (dashboard priority order)</option>
                  <option value="gemini">Gemini</option>
                  <option value="groq">Groq</option>
                  <option value="ollama">Ollama (local)</option>
                </select>
                <div className="field-hint">If the chosen model's keys run out, it still falls back automatically.</div>
              </div>
            </div>
          </div>

          <div className="panel">
            <div className="panel-title">Audio & extras</div>
            <div className="field">
              <label>Background music</label>
              <select value={music} onChange={(e) => setMusic(e.target.value)}>
                <option value="auto">Auto (pick from music library)</option>
                <option value="none">No music</option>
              </select>
              <div className="field-hint">Drop royalty-free tracks into your music folder to enable this.</div>
            </div>

            <div className="checkbox-row">
              <input type="checkbox" checked={research} onChange={(e) => setResearch(e.target.checked)} id="research" />
              <label htmlFor="research" style={{ margin: 0 }}>Enable research pass before scripting</label>
            </div>
          </div>

          <div className="panel">
            <div className="panel-title">YouTube upload</div>
            <div className="checkbox-row">
              <input type="checkbox" checked={autoUpload} onChange={(e) => setAutoUpload(e.target.checked)} id="upload" />
              <label htmlFor="upload" style={{ margin: 0 }}>Upload to YouTube automatically when finished</label>
            </div>
            {autoUpload && (
              <>
                <div className="grid-2">
                  <div className="field">
                    <label>Channel</label>
                    <select value={channelId} onChange={(e) => setChannelId(e.target.value)}>
                      <option value="">Default channel</option>
                      {channels.map((c) => (
                        <option key={c.id} value={c.id}>{c.label || c.channel_title || c.id.slice(0, 8)}</option>
                      ))}
                    </select>
                    {channels.length === 0 && (
                      <div className="field-hint">No channels connected yet — connect one from the YouTube page first.</div>
                    )}
                  </div>
                  <div className="field">
                    <label>Privacy</label>
                    <select value={privacy} onChange={(e) => setPrivacy(e.target.value)}>
                      <option value="private">Private (recommended)</option>
                      <option value="unlisted">Unlisted</option>
                      <option value="public">Public</option>
                    </select>
                  </div>
                </div>
                <div className="grid-2">
                  <div className="field">
                    <label>Schedule publish date (optional)</label>
                    <input type="date" value={scheduleDate} onChange={(e) => setScheduleDate(e.target.value)} />
                  </div>
                  <div className="field">
                    <label>Schedule publish time</label>
                    <input type="time" value={scheduleTime} onChange={(e) => setScheduleTime(e.target.value)} disabled={!scheduleDate} />
                  </div>
                </div>
                {scheduleDate && (
                  <div className="field-hint" style={{ marginTop: -8, marginBottom: 14 }}>
                    The video renders and uploads right away as private, then YouTube automatically makes it {privacy} at the scheduled time.
                  </div>
                )}
              </>
            )}
          </div>

          <button className="btn btn-primary" type="submit" disabled={submitting || !topic}>
            {submitting ? "Starting…" : "Generate video"}
          </button>
        </form>
      )}
    </div>
  );
}
