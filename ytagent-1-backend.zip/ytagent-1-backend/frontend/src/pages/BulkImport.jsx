import React, { useEffect, useRef, useState } from "react";
import { api } from "../api/client.js";

export default function BulkImport() {
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState(null);
  const [error, setError] = useState(null);

  const [sheetConfig, setSheetConfig] = useState(null);
  const [sheetId, setSheetId] = useState("");
  const [sheetRange, setSheetRange] = useState("A:Z");
  const [apiKey, setApiKey] = useState("");
  const [pollInterval, setPollInterval] = useState(120);
  const [enabled, setEnabled] = useState(false);
  const [savingSheet, setSavingSheet] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState(null);

  async function loadSheetConfig() {
    try {
      const cfg = await api.getSheetSyncConfig();
      setSheetConfig(cfg);
      setSheetId(cfg.sheet_id || "");
      setSheetRange(cfg.sheet_range || "A:Z");
      setPollInterval(cfg.poll_interval_seconds || 120);
      setEnabled(!!cfg.enabled);
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    loadSheetConfig();
  }, []);

  async function handleExcelUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(null);
    setUploadResult(null);
    try {
      const result = await api.bulkImportExcel(file);
      setUploadResult(result);
    } catch (e) {
      setError(e.message);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleSaveSheetConfig() {
    setSavingSheet(true);
    setError(null);
    try {
      const payload = {
        sheet_id: sheetId || null,
        sheet_range: sheetRange || null,
        poll_interval_seconds: Number(pollInterval) || 120,
        enabled,
      };
      if (apiKey.trim()) payload.api_key = apiKey.trim();
      const cfg = await api.updateSheetSyncConfig(payload);
      setSheetConfig(cfg);
      setApiKey("");
    } catch (e) {
      setError(e.message);
    } finally {
      setSavingSheet(false);
    }
  }

  async function handleSyncNow() {
    setSyncing(true);
    setSyncResult(null);
    setError(null);
    try {
      const result = await api.runSheetSyncNow();
      setSyncResult(result);
      await loadSheetConfig();
    } catch (e) {
      setError(e.message);
    } finally {
      setSyncing(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Bulk import</h1>
        <p>Load a whole content calendar at once instead of creating jobs one by one — from a spreadsheet upload or a live-synced Google Sheet.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="panel">
        <div className="panel-title">Upload a spreadsheet (one-time)</div>
        <p className="field-hint" style={{ marginBottom: 12 }}>
          Each row becomes a job. Columns: topic, content_type, niche, language, duration, voice, music, llm_provider,
          channel, auto_upload, privacy, schedule_date, schedule_time.
        </p>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <input ref={fileInputRef} type="file" accept=".xlsx,.xlsm" onChange={handleExcelUpload} disabled={uploading} />
          <a className="btn btn-sm" href={api.bulkImportTemplateUrl()}>Download template</a>
        </div>
        {uploading && <div className="progress-step" style={{ marginTop: 10 }}>Importing…</div>}
        {uploadResult && (
          <div className="panel" style={{ marginTop: 14, background: "var(--bg)" }}>
            <div>Created <strong>{uploadResult.created_jobs}</strong> job(s), skipped {uploadResult.skipped_unchanged} unchanged row(s).</div>
            {uploadResult.errors.length > 0 && (
              <ul style={{ marginTop: 8, color: "var(--signal)", fontSize: 13 }}>
                {uploadResult.errors.map((err, i) => <li key={i}>{err}</li>)}
              </ul>
            )}
          </div>
        )}
      </div>

      <div className="panel">
        <div className="panel-title">Live Google Sheet sync</div>
        <p className="field-hint" style={{ marginBottom: 12 }}>
          Keep editing the sheet from your phone — YTAgent polls it automatically and only creates jobs for rows that
          are new or changed. Share the sheet as "Anyone with the link can view", and use the same columns as the
          template above.
        </p>

        <div className="grid-2">
          <div className="field">
            <label>Sheet ID</label>
            <input type="text" value={sheetId} onChange={(e) => setSheetId(e.target.value)} placeholder="the long id in the sheet's URL" />
          </div>
          <div className="field">
            <label>Range</label>
            <input type="text" value={sheetRange} onChange={(e) => setSheetRange(e.target.value)} placeholder="A:Z" />
          </div>
        </div>
        <div className="grid-2">
          <div className="field">
            <label>Google Sheets API key</label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={sheetConfig?.api_key_configured ? "Already set — leave blank to keep it" : "AIza..."}
            />
          </div>
          <div className="field">
            <label>Poll interval (seconds)</label>
            <input type="number" min={30} value={pollInterval} onChange={(e) => setPollInterval(e.target.value)} />
          </div>
        </div>
        <div className="checkbox-row">
          <input type="checkbox" id="sheet-enabled" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
          <label htmlFor="sheet-enabled" style={{ margin: 0 }}>Enable automatic syncing</label>
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-primary btn-sm" onClick={handleSaveSheetConfig} disabled={savingSheet}>
            {savingSheet ? "Saving…" : "Save sheet config"}
          </button>
          <button className="btn btn-sm" onClick={handleSyncNow} disabled={syncing || !sheetId}>
            {syncing ? "Syncing…" : "Sync now"}
          </button>
        </div>

        {syncResult && (
          <div className="panel" style={{ marginTop: 14, background: "var(--bg)" }}>
            <div>Created <strong>{syncResult.created_jobs}</strong> job(s), skipped {syncResult.skipped_unchanged} unchanged row(s).</div>
            {syncResult.errors.length > 0 && (
              <ul style={{ marginTop: 8, color: "var(--signal)", fontSize: 13 }}>
                {syncResult.errors.map((err, i) => <li key={i}>{err}</li>)}
              </ul>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
