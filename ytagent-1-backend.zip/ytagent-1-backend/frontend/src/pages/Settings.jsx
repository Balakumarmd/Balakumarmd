import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";

const LLM_PROVIDERS = ["gemini", "groq", "ollama"];

function CredentialManager({ category, provider, title, keyPlaceholder, helpUrl }) {
  const [credentials, setCredentials] = useState([]);
  const [secret, setSecret] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const data = await api.listProviderCredentials(category, provider);
      setCredentials(data.credentials || []);
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category, provider]);

  async function handleAdd() {
    if (!secret.trim()) {
      setError("API key is required.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await api.addProviderCredential({
        category,
        provider_name: provider,
        credential_type: "api_key",
        display_name: name.trim() || null,
        secret: secret.trim(),
      });
      setSecret("");
      setName("");
      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete(id) {
    try {
      await api.deleteProviderCredential(id);
      await load();
    } catch (e) {
      setError(e.message);
    }
  }

  async function handleResetExhaustion(id) {
    try {
      await api.resetCredentialExhaustion(id);
      await load();
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div style={{ marginBottom: 22, paddingBottom: 18, borderBottom: "1px solid var(--border)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 }}>
        <div style={{ fontWeight: 600, fontSize: 13.5 }}>{title}</div>
        {helpUrl && (
          <a href={helpUrl} target="_blank" rel="noreferrer" style={{ fontSize: 11.5, color: "var(--text-faint)" }}>
            Get a key &rarr;
          </a>
        )}
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="grid-2" style={{ marginBottom: 10 }}>
        <div className="field" style={{ marginBottom: 0 }}>
          <input type="text" placeholder="Label (optional, e.g. 'Key 2')" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="field" style={{ marginBottom: 0 }}>
          <input
            type="password"
            placeholder={keyPlaceholder}
            value={secret}
            onChange={(e) => setSecret(e.target.value)}
          />
        </div>
      </div>
      <button className="btn btn-sm" onClick={handleAdd} disabled={busy}>
        {busy ? "Adding…" : "+ Add key"}
      </button>

      <div style={{ marginTop: 12 }}>
        {credentials.length === 0 ? (
          <div className="field-hint">No keys added yet — add at least one above, or set it in .env as a fallback.</div>
        ) : (
          credentials.map((c) => (
            <div key={c.id} className="job-row" style={{ gridTemplateColumns: "1fr 140px 160px", padding: "8px 0" }}>
              <div className="mono" style={{ fontSize: 12.5 }}>{c.display_name || c.id.slice(0, 8)}</div>
              <span className={`tag ${c.is_exhausted ? "tag-failed" : "tag-completed"}`}>
                {c.is_exhausted ? "exhausted" : "active"}
              </span>
              <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                {c.is_exhausted && (
                  <button className="btn btn-sm" onClick={() => handleResetExhaustion(c.id)}>Reset</button>
                )}
                <button className="btn btn-sm" onClick={() => handleDelete(c.id)}>Remove</button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function PriorityOrder() {
  const [order, setOrder] = useState(["gemini", "groq", "ollama"]);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    api
      .listProviderConfigs("llm")
      .then((data) => {
        const active = (data.configs || [])
          .filter((c) => c.is_active)
          .sort((a, b) => (a.priority ?? 0) - (b.priority ?? 0))
          .map((c) => c.provider_name);
        if (active.length) {
          const rest = LLM_PROVIDERS.filter((p) => !active.includes(p));
          setOrder([...active, ...rest]);
        }
      })
      .catch(() => {});
  }, []);

  function move(index, direction) {
    const next = [...order];
    const target = index + direction;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    setOrder(next);
    setSaved(false);
  }

  async function handleSave() {
    try {
      await api.setPriorityOrder("llm", order);
      setSaved(true);
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div style={{ marginBottom: 22, paddingBottom: 18, borderBottom: "1px solid var(--border)" }}>
      <div style={{ fontWeight: 600, fontSize: 13.5, marginBottom: 8 }}>LLM fallback order</div>
      <p className="field-hint" style={{ marginBottom: 10 }}>
        When a job doesn't pin a specific model, or when its chosen provider's keys run out, YTAgent tries these in order.
      </p>
      {error && <div className="error-box">{error}</div>}
      {order.map((p, i) => (
        <div key={p} className="job-row" style={{ gridTemplateColumns: "28px 1fr 80px", padding: "6px 0" }}>
          <span className="mono" style={{ color: "var(--text-faint)" }}>{i + 1}</span>
          <span style={{ textTransform: "capitalize" }}>{p}</span>
          <div style={{ display: "flex", gap: 4 }}>
            <button className="btn btn-sm" onClick={() => move(i, -1)} disabled={i === 0}>↑</button>
            <button className="btn btn-sm" onClick={() => move(i, 1)} disabled={i === order.length - 1}>↓</button>
          </div>
        </div>
      ))}
      <button className="btn btn-primary btn-sm" style={{ marginTop: 10 }} onClick={handleSave}>Save order</button>
      {saved && <span style={{ marginLeft: 10, color: "var(--success)", fontSize: 12.5 }}>Saved.</span>}
    </div>
  );
}

export default function Settings() {
  const [values, setValues] = useState({});
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.getSettings().then(setValues).catch((e) => setError(e.message));
  }, []);

  function update(key, value) {
    setValues((v) => ({ ...v, [key]: value }));
    setSaved(false);
  }

  async function handleSave() {
    try {
      await api.updateSettings(values);
      setSaved(true);
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Settings</h1>
        <p>Everything here is stored in the database — no more editing .env by hand. Changes take effect on the next job the worker picks up.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="panel">
        <div className="panel-title">Storage &amp; local tools</div>
        <div className="grid-2">
          <div className="field">
            <label>Data directory</label>
            <input type="text" value={values.data_dir || ""} onChange={(e) => update("data_dir", e.target.value)} placeholder="D:\YTAgentData" />
            <div className="field-hint">Where jobs, rendered videos, logs, and the music library live.</div>
          </div>
          <div className="field">
            <label>FFmpeg path</label>
            <input type="text" value={values.ffmpeg_path || ""} onChange={(e) => update("ffmpeg_path", e.target.value)} placeholder="ffmpeg" />
          </div>
        </div>
        <div className="grid-2">
          <div className="field">
            <label>Whisper model</label>
            <select value={values.whisper_model || "base.en"} onChange={(e) => update("whisper_model", e.target.value)}>
              <option value="tiny.en">tiny.en (fastest)</option>
              <option value="base.en">base.en (balanced)</option>
              <option value="small.en">small.en</option>
              <option value="medium.en">medium.en</option>
              <option value="large-v3">large-v3 (most accurate)</option>
            </select>
          </div>
          <div className="field">
            <label>Whisper device</label>
            <select value={values.whisper_device || "auto"} onChange={(e) => update("whisper_device", e.target.value)}>
              <option value="auto">Auto (use GPU if available)</option>
              <option value="cpu">CPU only</option>
              <option value="cuda">Force GPU (CUDA)</option>
            </select>
          </div>
        </div>
        <div className="grid-2">
          <div className="field">
            <label>Default niche</label>
            <input type="text" value={values.default_niche || ""} onChange={(e) => update("default_niche", e.target.value)} placeholder="Education" />
          </div>
          <div className="field">
            <label>Default voice</label>
            <input type="text" value={values.default_voice || ""} onChange={(e) => update("default_voice", e.target.value)} placeholder="af_heart" />
          </div>
        </div>
        <button className="btn btn-primary" onClick={handleSave}>Save settings</button>
        {saved && <span style={{ marginLeft: 12, color: "var(--success)", fontSize: 13 }}>Saved.</span>}
      </div>

      <div className="panel">
        <div className="panel-title">AI script/metadata models</div>
        <PriorityOrder />
        <CredentialManager
          category="llm"
          provider="gemini"
          title="Gemini API keys"
          keyPlaceholder="AIza..."
          helpUrl="https://aistudio.google.com/app/apikey"
        />
        <CredentialManager
          category="llm"
          provider="groq"
          title="Groq API keys"
          keyPlaceholder="gsk_..."
          helpUrl="https://console.groq.com/keys"
        />
        <p className="field-hint">
          Ollama needs no API key — it runs locally. It's always kept as the final fallback even if not listed above.
        </p>
      </div>

      <div className="panel">
        <div className="panel-title">Stock footage</div>
        <div className="field">
          <label>Active provider</label>
          <select value={values.media_provider || "pexels"} onChange={(e) => update("media_provider", e.target.value)}>
            <option value="pexels">Pexels</option>
            <option value="pixabay">Pixabay</option>
          </select>
          <div className="field-hint">Keys for both can be stored at once — only the active provider's keys are used.</div>
        </div>
        <button className="btn btn-sm" onClick={handleSave} style={{ marginBottom: 16 }}>Save active provider</button>
        <CredentialManager
          category="media"
          provider="pexels"
          title="Pexels API keys"
          keyPlaceholder="563492..."
          helpUrl="https://www.pexels.com/api/"
        />
        <CredentialManager
          category="media"
          provider="pixabay"
          title="Pixabay API keys"
          keyPlaceholder="12345678-abcdef..."
          helpUrl="https://pixabay.com/api/docs/"
        />
      </div>
    </div>
  );
}
