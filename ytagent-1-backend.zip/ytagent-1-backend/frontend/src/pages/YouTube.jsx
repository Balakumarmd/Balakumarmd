import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";

export default function YouTube() {
  const [channels, setChannels] = useState([]);
  const [appStatus, setAppStatus] = useState(null);
  const [clientId, setClientId] = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [error, setError] = useState(null);
  const [connecting, setConnecting] = useState(false);
  const [savingApp, setSavingApp] = useState(false);

  async function load() {
    try {
      const [ch, app] = await Promise.all([api.listChannels(), api.youtubeOAuthAppStatus()]);
      setChannels(ch);
      setAppStatus(app);
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleSaveApp() {
    if (!clientId.trim() || !clientSecret.trim()) {
      setError("Both Client ID and Client Secret are required.");
      return;
    }
    setSavingApp(true);
    setError(null);
    try {
      await api.setYoutubeOAuthApp(clientId.trim(), clientSecret.trim());
      setClientId("");
      setClientSecret("");
      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setSavingApp(false);
    }
  }

  async function handleConnect() {
    setConnecting(true);
    setError(null);
    try {
      const { authorization_url } = await api.youtubeConnect();
      window.open(authorization_url, "_blank");
    } catch (e) {
      setError(e.message);
    } finally {
      setConnecting(false);
    }
  }

  async function handleSetDefault(id) {
    try {
      await api.setDefaultChannel(id);
      await load();
    } catch (e) {
      setError(e.message);
    }
  }

  async function handleRename(id, currentLabel) {
    const label = window.prompt("Rename channel", currentLabel || "");
    if (!label) return;
    try {
      await api.renameChannel(id, label);
      await load();
    } catch (e) {
      setError(e.message);
    }
  }

  async function handleDisconnect(id) {
    if (!window.confirm("Disconnect this channel? Jobs already pointed at it will fail to upload until reconnected.")) return;
    try {
      await api.disconnectChannel(id);
      await load();
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>YouTube</h1>
        <p>Connect as many channels as you run. Each video-generation job picks which channel to publish to.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="panel">
        <div className="panel-title">OAuth app credentials</div>
        <p className="field-hint" style={{ marginBottom: 12 }}>
          One-time setup: create an OAuth client in Google Cloud Console (see README "YouTube OAuth setup") and paste
          it here instead of editing .env. Current status:{" "}
          <strong>
            {appStatus?.client_id_configured && appStatus?.client_secret_configured ? "configured" : "not configured"}
          </strong>
        </p>
        <div className="grid-2">
          <div className="field">
            <label>Client ID</label>
            <input type="text" value={clientId} onChange={(e) => setClientId(e.target.value)} placeholder="xxxx.apps.googleusercontent.com" />
          </div>
          <div className="field">
            <label>Client secret</label>
            <input type="password" value={clientSecret} onChange={(e) => setClientSecret(e.target.value)} placeholder="GOCSPX-..." />
          </div>
        </div>
        <button className="btn btn-sm" onClick={handleSaveApp} disabled={savingApp}>
          {savingApp ? "Saving…" : "Save OAuth app credentials"}
        </button>
      </div>

      <div className="panel">
        <div className="panel-title">
          Connected channels
          <button className="btn btn-primary btn-sm" onClick={handleConnect} disabled={connecting}>
            {connecting ? "Opening…" : "+ Connect a channel"}
          </button>
        </div>

        {channels.length === 0 ? (
          <div className="empty-state">
            <div className="headline">No channels connected yet</div>
            <p>Click "Connect a channel" — a Google sign-in tab opens. Approve access, then come back here.</p>
          </div>
        ) : (
          channels.map((c) => (
            <div key={c.id} className="job-row" style={{ gridTemplateColumns: "1fr 110px 220px" }}>
              <div>
                <div className="job-topic">{c.label || c.channel_title || "Untitled channel"}</div>
                <div className="job-meta">{c.channel_title && c.label !== c.channel_title ? c.channel_title : c.youtube_channel_id || ""}</div>
              </div>
              {c.is_default ? <span className="tag tag-completed">default</span> : <span />}
              <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                {!c.is_default && (
                  <button className="btn btn-sm" onClick={() => handleSetDefault(c.id)}>Set default</button>
                )}
                <button className="btn btn-sm" onClick={() => handleRename(c.id, c.label)}>Rename</button>
                <button className="btn btn-sm" onClick={() => handleDisconnect(c.id)}>Disconnect</button>
              </div>
            </div>
          ))
        )}

        {channels.length > 0 && (
          <p className="field-hint" style={{ marginTop: 14 }}>
            To connect another channel (a second YouTube account), click "Connect a channel" again and sign in with
            that other Google account when the tab opens.
          </p>
        )}
      </div>
    </div>
  );
}
