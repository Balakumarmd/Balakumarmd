import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";
import StatusTag from "../components/StatusTag.jsx";
import JobProgress from "../components/JobProgress.jsx";

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [expanded, setExpanded] = useState(null);
  const [error, setError] = useState(null);

  async function load() {
    try {
      setJobs(await api.listJobs());
      setError(null);
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
    const id = setInterval(load, 3000);
    return () => clearInterval(id);
  }, []);

  async function handleCancel(id) {
    await api.cancelJob(id);
    load();
  }

  async function handleRetry(id) {
    await api.retryJob(id);
    load();
  }

  return (
    <div>
      <div className="page-header">
        <h1>Jobs</h1>
        <p>Every video generation request, its live status, and its history. Jobs survive an application restart.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="panel">
        {jobs.length === 0 ? (
          <div className="empty-state">
            <div className="headline">No jobs yet</div>
            <p>Jobs you create will show up here, oldest state changes at the top.</p>
          </div>
        ) : (
          jobs.map((job) => (
            <div key={job.id} style={{ borderBottom: "1px solid var(--border)", padding: "14px 0" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }}
                   onClick={() => setExpanded(expanded === job.id ? null : job.id)}>
                <div>
                  <div className="job-topic">{job.topic}</div>
                  <div className="job-meta">
                    {job.content_type.toUpperCase()} · {job.id.slice(0, 8)} · retries {job.retry_count}/{job.max_retries}
                  </div>
                </div>
                <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <StatusTag status={job.status} />
                  {job.status === "FAILED" && (
                    <button className="btn btn-sm" onClick={(e) => { e.stopPropagation(); handleRetry(job.id); }}>Retry</button>
                  )}
                  {!["COMPLETED", "FAILED", "CANCELLED"].includes(job.status) && (
                    <button className="btn btn-sm" onClick={(e) => { e.stopPropagation(); handleCancel(job.id); }}>Cancel</button>
                  )}
                </div>
              </div>
              {expanded === job.id && (
                <div style={{ marginTop: 14 }}>
                  <JobProgress job={job} />
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
