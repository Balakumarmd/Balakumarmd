import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [name, setName] = useState("");
  const [niche, setNiche] = useState("");
  const [error, setError] = useState(null);

  async function load() {
    try {
      setProjects(await api.listProjects());
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleCreate(e) {
    e.preventDefault();
    try {
      await api.createProject({ name, niche, default_language: "en" });
      setName("");
      setNiche("");
      load();
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Projects</h1>
        <p>Group jobs and videos by channel or content calendar.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="panel">
        <div className="panel-title">New project</div>
        <form onSubmit={handleCreate} className="grid-2">
          <div className="field">
            <label>Name</label>
            <input type="text" required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Study Tips Channel" />
          </div>
          <div className="field">
            <label>Niche</label>
            <input type="text" value={niche} onChange={(e) => setNiche(e.target.value)} placeholder="e.g. Education" />
          </div>
          <button className="btn btn-primary" type="submit" style={{ gridColumn: "1 / -1", width: "fit-content" }}>Create project</button>
        </form>
      </div>

      <div className="panel">
        <div className="panel-title">Your projects</div>
        {projects.length === 0 ? (
          <div className="empty-state">
            <div className="headline">No projects yet</div>
            <p>Projects are optional — you can also create videos without one.</p>
          </div>
        ) : (
          projects.map((p) => (
            <div key={p.id} className="job-row" style={{ gridTemplateColumns: "1fr 1fr 120px" }}>
              <div className="job-topic">{p.name}</div>
              <div className="job-meta">{p.niche || "general"}</div>
              <div className="job-meta">{new Date(p.created_at).toLocaleDateString()}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
