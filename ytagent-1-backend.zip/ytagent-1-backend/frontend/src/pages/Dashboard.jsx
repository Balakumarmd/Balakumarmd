import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client.js";
import StatusTag from "../components/StatusTag.jsx";

export default function Dashboard() {
  const [status, setStatus] = useState(null);
  const [workers, setWorkers] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [error, setError] = useState(null);

  async function load() {
    try {
      const [s, w, j] = await Promise.all([api.systemStatus(), api.workers(), api.listJobs()]);
      setStatus(s);
      setWorkers(w);
      setJobs(j);
      setError(null);
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    load();
    const id = setInterval(load, 4000);
    return () => clearInterval(id);
  }, []);

  const activeJobs = jobs.filter((j) => !["COMPLETED", "FAILED", "CANCELLED"].includes(j.status));
  const completedCount = jobs.filter((j) => j.status === "COMPLETED").length;
  const failedCount = jobs.filter((j) => j.status === "FAILED").length;
  const onlineWorker = workers.find((w) => w.status !== "offline");

  return (
    <div>
      <div className="page-header">
        <h1>Dashboard</h1>
        <p>A live view of your worker, your local AI stack, and everything currently rendering.</p>
      </div>

      {error && <div className="error-box">Could not reach the backend: {error}</div>}

      <div className="grid-3" style={{ marginBottom: 20 }}>
        <div className="stat-card">
          <div className="stat-label">WORKER</div>
          <div className={`stat-value ${onlineWorker ? "ok" : "bad"}`}>
            {onlineWorker ? "Online" : "Offline"}
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">OLLAMA ({status?.ollama_model || "…"})</div>
          <div className={`stat-value ${status?.ollama === "ok" ? "ok" : "bad"}`}>
            {status ? status.ollama : "…"}
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">DISK SPACE</div>
          <div className="stat-value">{status ? status.storage : "…"}</div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">
          Active jobs
          <Link to="/create" className="btn btn-primary btn-sm">+ New video</Link>
        </div>
        {activeJobs.length === 0 ? (
          <div className="empty-state">
            <div className="headline">Nothing rendering right now</div>
            <p>Start a new video and it will appear here with live progress.</p>
          </div>
        ) : (
          activeJobs.map((job) => (
            <div className="job-row" key={job.id}>
              <div>
                <div className="job-topic">{job.topic}</div>
                <div className="job-meta">{job.content_type.toUpperCase()} · {job.id.slice(0, 8)}</div>
              </div>
              <StatusTag status={job.status} />
              <div>
                <div className="progress-track">
                  <div className="progress-fill" style={{ width: `${job.progress}%` }} />
                </div>
                <div className="progress-step">{job.current_step || "Queued"}</div>
              </div>
              <Link to="/jobs" className="btn btn-sm">View</Link>
            </div>
          ))
        )}
      </div>

      <div className="grid-2">
        <div className="panel">
          <div className="panel-title">Completed videos</div>
          <div className="stat-value ok" style={{ fontSize: 32 }}>{completedCount}</div>
        </div>
        <div className="panel">
          <div className="panel-title">Failed jobs</div>
          <div className="stat-value bad" style={{ fontSize: 32 }}>{failedCount}</div>
        </div>
      </div>
    </div>
  );
}
